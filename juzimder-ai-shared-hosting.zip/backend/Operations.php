<?php
declare(strict_types=1);
namespace Juzimder;
require_once __DIR__ . '/ComponentStylePolicy.php';
require_once __DIR__ . '/ComponentTypePolicy.php';
require_once __DIR__ . '/ComponentAttributePolicy.php';

final class ProjectOperations {
    private const MAX_OPERATIONS = 20;
    private const COMPONENT_FIELDS = ['type','tagName','name','content','attributes','classes','style','components','zeroData'];
    private static function validateAttributeValue(string $name, mixed $value): void {
        if (ComponentAttributePolicy::isBoolean($name)) {
            if (!is_bool($value)) throw new Problem(422, 'Логический атрибут должен иметь значение true или false.');
            return;
        }
        $maxLength = ComponentAttributePolicy::stringMaxLength($name);
        if (!is_string($value) || ($maxLength !== null && mb_strlen($value, 'UTF-8') > $maxLength) || preg_match('/[\\x00-\\x1F\\x7F]/u', $value)) {
            throw new Problem(422, 'Значение атрибута должно быть допустимой строкой.');
        }
        if ($name === 'id' && !preg_match('/^[A-Za-z][A-Za-z0-9_:-]{0,127}$/D', $value)) throw new Problem(422, 'ID должен быть безопасным HTML-идентификатором длиной до 128 символов.');
        if ($name === 'class' && !preg_match('/^[A-Za-z0-9_-]+(?:\\s+[A-Za-z0-9_-]+)*$/D', $value)) throw new Problem(422, 'Класс должен содержать только безопасные CSS-имена.');
        if ($name === 'target' && !in_array($value, ['_blank','_self'], true)) throw new Problem(422, 'Недопустимое значение target.');
        if ($name === 'rel' && !preg_match('/^(?:noopener|noreferrer|nofollow|ugc|sponsored)(?:\\s+(?:noopener|noreferrer|nofollow|ugc|sponsored))*$/D', $value)) throw new Problem(422, 'Недопустимое значение rel.');
        if (!ComponentAttributePolicy::isValidEnumValue($name, $value)) throw new Problem(422, 'Недопустимое значение ARIA-атрибута.');
    }
    public static function styleFields(): array { return ComponentStylePolicy::properties(); }
    public static function nodeIdentifier(\stdClass $node): ?string { return self::nodeId($node); }

    public static function componentSubtree(mixed $document, string $pageId, string $componentId): \stdClass {
        if (!$document instanceof \stdClass) throw new Problem(422, 'Некорректный документ проекта.');
        Document::validate($document);
        $pageId = self::identifier($pageId);
        $componentId = self::identifier($componentId);
        $pages = $document->data->pages ?? [];
        $pageIndex = null;
        foreach ($pages as $index => $page) {
            if (($page->id ?? null) === $pageId) { $pageIndex = $index; break; }
        }
        if ($pageIndex === null) throw new Problem(404, 'Страница не найдена.');
        $rootPath = ['data','pages',$pageIndex,'frames',0,'component'];
        $location = self::findComponent($document, $componentId);
        if (!self::isPathPrefix($rootPath, $location['path'])) throw new Problem(404, 'Компонент не найден на выбранной странице.');
        $component =& self::atPath($document, $location['path']);
        if (($component->type ?? null) === 'wrapper') throw new Problem(422, 'Выберите компонент внутри страницы.');
        return json_decode(json_encode($component, JSON_THROW_ON_ERROR), false, 64, JSON_THROW_ON_ERROR);
    }

    public static function componentForAiEdit(mixed $document, string $pageId, mixed $componentPath, string $componentId): array {
        if (!$document instanceof \stdClass) throw new Problem(422, 'Некорректный документ проекта.');
        Document::validate($document);
        $pageId = self::identifier($pageId);
        if (!is_array($componentPath) || !array_is_list($componentPath) || $componentPath === [] || count($componentPath) > 35) throw new Problem(422, 'Некорректный путь выбранного компонента.');
        foreach ($componentPath as $index) if (!is_int($index) || $index < 0) throw new Problem(422, 'Некорректный путь выбранного компонента.');
        if ($componentId !== '') $componentId = self::identifier($componentId);
        $pages = $document->data->pages ?? [];
        $pageIndex = null;
        foreach ($pages as $index => $page) if (($page->id ?? null) === $pageId) { $pageIndex = $index; break; }
        if ($pageIndex === null) throw new Problem(404, 'Страница не найдена.');
        $draft = json_decode(json_encode($document, JSON_THROW_ON_ERROR), false, 64, JSON_THROW_ON_ERROR);
        $path = ['data','pages',$pageIndex,'frames',0,'component'];
        foreach ($componentPath as $index) {
            $parent =& self::atPath($draft, $path);
            if (!is_array($parent->components ?? null) || !array_is_list($parent->components) || !array_key_exists($index, $parent->components)) throw new Problem(404, 'Компонент не найден по выбранному пути.');
            $path[] = 'components';
            $path[] = $index;
            unset($parent);
        }
        $component =& self::atPath($draft, $path);
        if (!$component instanceof \stdClass || ($component->type ?? null) === 'wrapper') throw new Problem(422, 'Выберите компонент внутри страницы.');
        $actualId = self::nodeId($component);
        if ($actualId === '') $actualId = null;
        if ($componentId !== '' && $actualId !== $componentId) throw new Problem(409, 'Выбранный стабильный ID больше не совпадает с компонентом. Выберите его заново.');
        if ($actualId !== null) {
            $location = self::findComponent($draft, $actualId);
            if ($location['path'] !== $path) throw new Problem(409, 'ID компонента неоднозначен. Обновите страницу перед AI-правкой.');
        }
        $needsId = !(($component->attributes ?? null) instanceof \stdClass && is_string($component->attributes->id ?? null) && $component->attributes->id !== '');
        $stableId = $actualId;
        if ($stableId === null) {
            $ids = [];
            self::collectIds($draft, $ids);
            do { $stableId = 'cmp-' . bin2hex(random_bytes(12)); } while (isset($ids[$stableId]));
        }
        if ($needsId) {
            if (!($component->attributes ?? null) instanceof \stdClass) $component->attributes = new \stdClass();
            $component->attributes->id = $stableId;
        }
        $target = json_decode(json_encode($component, JSON_THROW_ON_ERROR), false, 64, JSON_THROW_ON_ERROR);
        return ['document'=>$draft,'component'=>$target,'componentId'=>$stableId,'needsId'=>$needsId];
    }
    private const LAYOUT_FIELDS = [
        'display'=>'display','flexDirection'=>'flex-direction','justifyContent'=>'justify-content','alignItems'=>'align-items',
        'flexWrap'=>'flex-wrap','gridTemplateColumns'=>'grid-template-columns','gap'=>'gap','width'=>'width','height'=>'height',
        'minWidth'=>'min-width','maxWidth'=>'max-width','minHeight'=>'min-height','maxHeight'=>'max-height'
    ];

    public static function apply(mixed $document, mixed $operations): \stdClass {
        if (!$document instanceof \stdClass) throw new Problem(422, 'Некорректный документ проекта.');
        Document::validate($document);
        if (!is_array($operations) || !array_is_list($operations) || count($operations) < 1 || count($operations) > self::MAX_OPERATIONS) throw new Problem(422, 'Передайте от 1 до ' . self::MAX_OPERATIONS . ' операций.');
        try {
            $draft = json_decode(json_encode($document, JSON_THROW_ON_ERROR), false, 64, JSON_THROW_ON_ERROR);
            $batch = json_decode(json_encode($operations, JSON_THROW_ON_ERROR), false, 64, JSON_THROW_ON_ERROR);
        } catch (\JsonException) {
            throw new Problem(422, 'Операции должны быть корректным JSON.');
        }
        if (!$draft instanceof \stdClass || !is_array($batch)) throw new Problem(422, 'Некорректный документ или список операций.');
        foreach ($batch as $operation) {
            self::applyOne($draft, $operation);
            Document::validate($draft);
        }
        return $draft;
    }

    private static function applyOne(\stdClass $document, mixed $operation): void {
        if (!$operation instanceof \stdClass || !is_string($operation->operation ?? null)) throw new Problem(422, 'Некорректная typed operation.');
        switch ($operation->operation) {
            case 'create_component':
                self::fields($operation, ['operation','parentId','component','index'], ['operation','parentId','component']);
                self::create($document, self::identifier($operation->parentId), $operation->component, $operation->index ?? null);
                return;
            case 'update_zero_block':
                self::fields($operation,['operation','pageId','componentId','zeroData'],['operation','pageId','componentId','zeroData']);
                $draft = ZeroBlock::updated($document,self::identifier($operation->pageId),self::identifier($operation->componentId),$operation->zeroData);
                $document->data = $draft->data;
                return;
            case 'update_content':
                self::fields($operation, ['operation','componentId','content'], ['operation','componentId','content']);
                if (!is_string($operation->content) || mb_strlen($operation->content, 'UTF-8') > 10000) throw new Problem(422, 'Текст компонента не должен превышать 10000 символов.');
                $location = self::findComponent($document, self::identifier($operation->componentId));
                $component =& self::atPath($document, $location['path']);
                $type = $component->type ?? null;
                if (!in_array($type, ['text','textnode','link'], true)) throw new Problem(422, 'Этот компонент не поддерживает изменение текста.');
                $component->content = $operation->content;
                return;
            case 'rename_component':
                self::fields($operation, ['operation','componentId','name'], ['operation','componentId','name']);
                if (!is_string($operation->name) || trim($operation->name) === '' || mb_strlen($operation->name, 'UTF-8') > 100 || preg_match('/[\x00-\x1F\x7F]/u', $operation->name)) throw new Problem(422, 'Название компонента должно содержать от 1 до 100 символов без управляющих символов.');
                $location = self::findComponent($document, self::identifier($operation->componentId));
                $component =& self::atPath($document, $location['path']);
                $component->name = trim($operation->name);
                return;
            case 'update_tag_name':
                self::fields($operation, ['operation','componentId','tagName'], ['operation','componentId','tagName']);
                $location = self::findComponent($document, self::identifier($operation->componentId));
                $component =& self::atPath($document, $location['path']);
                $type = is_string($component->type ?? null) ? $component->type : '';
                $allowedTags = ComponentTypePolicy::semanticTags($type);
                if (!is_string($operation->tagName) || !in_array($operation->tagName, $allowedTags, true)) throw new Problem(422, 'Для этого типа компонента недопустим HTML-тег.');
                $component->tagName = $operation->tagName;
                return;
            case 'update_classes':
                self::fields($operation, ['operation','componentId','classes'], ['operation','componentId','classes']);
                if (!is_array($operation->classes) || !array_is_list($operation->classes) || count($operation->classes) > 32) throw new Problem(422, 'Передайте до 32 CSS-классов списком.');
                $classes = [];
                foreach ($operation->classes as $class) {
                    if (!is_string($class) || !preg_match('/^[A-Za-z0-9_-]{1,128}$/D', $class) || isset($classes[$class])) throw new Problem(422, 'CSS-класс должен быть уникальным безопасным именем длиной от 1 до 128 символов.');
                    $classes[$class] = (object)['name'=>$class];
                }
                $location = self::findComponent($document, self::identifier($operation->componentId));
                $component =& self::atPath($document, $location['path']);
                $component->classes = array_values($classes);
                return;
            case 'update_attributes':
                self::fields($operation, ['operation','componentId','attributes'], ['operation','componentId','attributes']);
                if (!$operation->attributes instanceof \stdClass || get_object_vars($operation->attributes) === []) throw new Problem(422, 'Укажите атрибуты объектом.');
                foreach (get_object_vars($operation->attributes) as $attribute => $value) {
                    if (!ComponentAttributePolicy::isSafeName($attribute) || $attribute === 'id') throw new Problem(422, 'Атрибут не входит в разрешённый список или является стабильным ID.');
                    if ($value === null) continue;
                    self::validateAttributeValue($attribute, $value);
                }
                $location = self::findComponent($document, self::identifier($operation->componentId));
                $component =& self::atPath($document, $location['path']);
                if (!($component->attributes ?? null) instanceof \stdClass) $component->attributes = new \stdClass();
                foreach (get_object_vars($operation->attributes) as $attribute => $value) {
                    if ($value === null || ($value === false && ComponentAttributePolicy::isBoolean($attribute))) unset($component->attributes->{$attribute});
                    else $component->attributes->{$attribute} = $value;
                }
                return;
            case 'replace_text':
                self::fields($operation, ['operation','componentId','content'], ['operation','componentId','content']);
                if (!is_string($operation->content) || mb_strlen($operation->content, 'UTF-8') > 1000 || preg_match('/[<>\x00-\x08\x0B\x0C\x0E-\x1F\x7F]|https?:\/\/|www\./iu', $operation->content)) throw new Problem(422, 'Текст должен быть обычным текстом без разметки и URL.');
                $location = self::findComponent($document, self::identifier($operation->componentId));
                $component =& self::atPath($document, $location['path']);
                $type = $component->type ?? null;
                if (!in_array($type, ['text','textnode','link'], true)) throw new Problem(422, 'Этот компонент не поддерживает замену текста.');
                if ($type === 'textnode') $component->content = $operation->content;
                else {
                    unset($component->content);
                    $component->components = [(object)['type'=>'textnode','content'=>$operation->content]];
                }
                return;
            case 'update_styles':
                self::fields($operation, ['operation','componentId','styles'], ['operation','componentId','styles']);
                $location = self::findComponent($document, self::identifier($operation->componentId));
                $component =& self::atPath($document, $location['path']);
                self::applyStyles($component, $operation->styles);
                return;
            case 'update_layout':
                self::fields($operation, ['operation','componentId','layout'], ['operation','componentId','layout']);
                $layout = $operation->layout;
                if (!$layout instanceof \stdClass || get_object_vars($layout) === []) throw new Problem(422, 'Укажите параметры компоновки.');
                $styles = new \stdClass();
                foreach (get_object_vars($layout) as $field => $value) {
                    if (!isset(self::LAYOUT_FIELDS[$field])) throw new Problem(422, 'Неизвестное свойство компоновки.');
                    if ($value !== null) {
                        if (!is_string($value)) throw new Problem(422, 'Значение компоновки должно быть строкой или null для сброса.');
                        if ($field === 'display' && !in_array($value, ['block','flex','grid','inline','inline-block'], true)) throw new Problem(422, 'Недопустимое значение display.');
                        if ($field === 'flexDirection' && !in_array($value, ['row','row-reverse','column','column-reverse'], true)) throw new Problem(422, 'Недопустимое направление Flex.');
                        if ($field === 'justifyContent' && !in_array($value, ['flex-start','flex-end','center','space-between','space-around','space-evenly'], true)) throw new Problem(422, 'Недопустимое выравнивание.');
                        if ($field === 'alignItems' && !in_array($value, ['stretch','flex-start','flex-end','center','baseline'], true)) throw new Problem(422, 'Недопустимое выравнивание.');
                        if ($field === 'flexWrap' && !in_array($value, ['nowrap','wrap','wrap-reverse'], true)) throw new Problem(422, 'Недопустимое значение flex-wrap.');
                    }
                    $styles->{self::LAYOUT_FIELDS[$field]} = $value;
                }
                $location = self::findComponent($document, self::identifier($operation->componentId));
                $component =& self::atPath($document, $location['path']);
                self::applyStyles($component, $styles);
                return;
            case 'delete_component':
                self::fields($operation, ['operation','componentId','confirm'], ['operation','componentId','confirm']);
                if ($operation->confirm !== true) throw new Problem(422, 'Удаление требует явного confirm: true.');
                $location = self::findComponent($document, self::identifier($operation->componentId));
                if ($location['parentPath'] === null || $location['index'] === null) throw new Problem(422, 'Корневой компонент страницы нельзя удалить.');
                $parent =& self::atPath($document, $location['parentPath']);
                array_splice($parent->components, $location['index'], 1);
                return;
            case 'duplicate_component':
                self::fields($operation, ['operation','componentId','index'], ['operation','componentId']);
                self::duplicate($document, self::identifier($operation->componentId), $operation->index ?? null);
                return;
            case 'move_component':
                self::fields($operation, ['operation','componentId','parentId','index'], ['operation','componentId','parentId']);
                self::move($document, self::identifier($operation->componentId), self::identifier($operation->parentId), $operation->index ?? null);
                return;
            case 'reorder_component':
                self::fields($operation, ['operation','componentId','index'], ['operation','componentId','index']);
                $id = self::identifier($operation->componentId);
                $location = self::findComponent($document, $id);
                if ($location['parentPath'] === null || $location['index'] === null) throw new Problem(422, 'Корневой компонент страницы нельзя переставить.');
                $parent =& self::atPath($document, $location['parentPath']);
                self::relocate($location, $parent, $parent, self::index($operation->index, count($parent->components) - 1));
                return;
            default:
                throw new Problem(422, 'Неподдерживаемый тип операции.');
        }
    }

    private static function duplicate(\stdClass $document, string $componentId, mixed $index): void {
        $location = self::findComponent($document, $componentId);
        if ($location['parentPath'] === null || $location['index'] === null) throw new Problem(422, 'Корневой компонент страницы нельзя дублировать.');
        $parent =& self::atPath($document, $location['parentPath']);
        $source =& self::atPath($document, $location['path']);
        $copy = json_decode(json_encode($source, JSON_THROW_ON_ERROR), false, 64, JSON_THROW_ON_ERROR);
        $ids = [];
        self::collectIds($document, $ids);
        $idMap = [];
        $assignIds = static function (mixed $node) use (&$assignIds, &$idMap, &$ids): void {
            if (!$node instanceof \stdClass) return;
            if (!($node->attributes ?? null) instanceof \stdClass) $node->attributes = new \stdClass();
            $old = $node->attributes->id ?? null;
            do { $new = 'cmp-' . bin2hex(random_bytes(12)); } while (isset($ids[$new]));
            $ids[$new] = true;
            if (is_string($old) && $old !== '') $idMap[$old] = $new;
            $node->attributes->id = $new;
            foreach ($node->components ?? [] as $child) $assignIds($child);
        };
        $assignIds($copy);
        $idRefs = ['aria-activedescendant','aria-controls','aria-describedby','aria-details','aria-errormessage','aria-flowto','aria-labelledby','aria-owns','for','form','headers','itemref','list'];
        $replaceUrls = static function (string $value) use (&$idMap): string {
            return preg_replace_callback("/url\\(\\s*([\"']?)#([^\"'()\\s]+)\\1\\s*\\)/i", static fn($m) => isset($idMap[$m[2]]) ? 'url(' . $m[1] . '#' . $idMap[$m[2]] . $m[1] . ')' : $m[0], $value) ?? $value;
        };
        $rewrite = static function (mixed $node) use (&$rewrite, &$idMap, $idRefs, $replaceUrls): void {
            if (!$node instanceof \stdClass) return;
            foreach (get_object_vars($node->attributes ?? new \stdClass()) as $key => $value) {
                if (!is_string($value) || $key === 'id') continue;
                if (in_array($key, ['href','xlink:href','usemap'], true) && str_starts_with($value, '#')) $value = '#' . ($idMap[substr($value, 1)] ?? substr($value, 1));
                elseif (in_array($key, $idRefs, true)) $value = implode(' ', array_map(static fn($token) => $idMap[$token] ?? $token, preg_split('/\\s+/', trim($value), -1, PREG_SPLIT_NO_EMPTY)));
                $node->attributes->{$key} = $replaceUrls($value);
            }
            if (($node->style ?? null) instanceof \stdClass) foreach (get_object_vars($node->style) as $key => $value) if (is_string($value)) $node->style->{$key} = $replaceUrls($value);
            foreach ($node->components ?? [] as $child) $rewrite($child);
        };
        $rewrite($copy);

        $styleCopies = [];
        foreach ($document->data->styles ?? [] as $rule) {
            if (!$rule instanceof \stdClass) continue;
            $clone = json_decode(json_encode($rule, JSON_THROW_ON_ERROR), false, 32, JSON_THROW_ON_ERROR);
            $matched = false;
            foreach ($clone->selectors ?? [] as $selectorIndex => $selector) {
                if (is_string($selector)) {
                    $rewritten = preg_replace_callback('/#([A-Za-z0-9_-]+)/', static fn($m) => isset($idMap[$m[1]]) ? '#' . $idMap[$m[1]] : $m[0], $selector) ?? $selector;
                    if ($rewritten !== $selector) { $clone->selectors[$selectorIndex] = $rewritten; $matched = true; }
                } elseif ($selector instanceof \stdClass && (int)($selector->type ?? 1) === 2 && isset($idMap[$selector->name ?? ''])) {
                    $selector->name = $idMap[$selector->name];
                    $matched = true;
                }
            }
            if (is_string($clone->selectorsAdd ?? null)) {
                $rewritten = preg_replace_callback('/#([A-Za-z0-9_-]+)/', static fn($m) => isset($idMap[$m[1]]) ? '#' . $idMap[$m[1]] : $m[0], $clone->selectorsAdd) ?? $clone->selectorsAdd;
                if ($rewritten !== $clone->selectorsAdd) { $clone->selectorsAdd = $rewritten; $matched = true; }
            }
            if ($matched) $styleCopies[] = $clone;
        }
        if ($styleCopies) $document->data->styles = array_merge($document->data->styles ?? [], $styleCopies);
        $children = $parent->components ?? [];
        $insertAt = $index === null ? $location['index'] + 1 : self::index($index, count($children));
        array_splice($children, $insertAt, 0, [$copy]);
        $parent->components = $children;
    }

    private static function create(\stdClass $document, string $parentId, mixed $componentData, mixed $index): void {
        $parentPath = self::findParentPath($document, $parentId);
        $parent =& self::atPath($document, $parentPath);
        self::canContain($parent);
        if (isset($parent->components) && (!is_array($parent->components) || !array_is_list($parent->components))) throw new Problem(422, 'Некорректный список дочерних компонентов.');
        $children = $parent->components ?? [];
        $insertAt = $index === null ? count($children) : self::index($index, count($children));
        $ids = [];
        self::collectIds($document, $ids);
        $count = 0;
        $component = self::normalizeComponent($componentData, $ids, 0, $count);
        array_splice($children, $insertAt, 0, [$component]);
        $parent->components = $children;
    }

    private static function normalizeComponent(mixed $node, array &$ids, int $depth, int &$count): \stdClass {
        if (!$node instanceof \stdClass || $depth > 20 || ++$count > 500) throw new Problem(422, 'Некорректное дерево нового компонента.');
        self::fields($node, self::COMPONENT_FIELDS, []);
        if (isset($node->type) && (!is_string($node->type) || !in_array($node->type, Document::COMPONENT_TYPES, true))) throw new Problem(422, 'Недопустимый тип компонента.');
        if (isset($node->tagName) && !is_string($node->tagName)) throw new Problem(422, 'Некорректный HTML-тег.');
        if (!isset($node->type) && !isset($node->tagName)) throw new Problem(422, 'Укажите разрешённый тип или HTML-тег компонента.');
        $componentType = isset($node->type) ? $node->type : null;
        $tagName = isset($node->tagName) ? $node->tagName : null;
        if (!ComponentTypePolicy::allowsTypedCreation($componentType, $tagName)) throw new Problem(422, 'Тип компонента не соответствует HTML-тегу поддерживаемого renderer.');
        if (isset($node->name) && (!is_string($node->name) || mb_strlen($node->name, 'UTF-8') > 120)) throw new Problem(422, 'Некорректное название компонента.');
        if (isset($node->content) && (!is_string($node->content) || mb_strlen($node->content, 'UTF-8') > 10000)) throw new Problem(422, 'Текст компонента слишком длинный.');
        $attributes = $node->attributes ?? new \stdClass();
        if (!$attributes instanceof \stdClass) throw new Problem(422, 'Атрибуты компонента должны быть объектом.');
        foreach (get_object_vars($attributes) as $attribute => $_) if (!ComponentAttributePolicy::isSafeName($attribute)) throw new Problem(422, 'Атрибут не входит в разрешённый список.');
        foreach (get_object_vars($attributes) as $name => $value) {
            self::validateAttributeValue($name, $value);
            if (ComponentAttributePolicy::isBoolean($name) && $value === false) unset($attributes->{$name});
        }
        $id = $attributes->id ?? ('cmp-' . bin2hex(random_bytes(12)));
        if (!is_string($id) || $id === '' || mb_strlen($id, 'UTF-8') > 128 || preg_match('/[\x00-\x1F\x7F]/', $id)) throw new Problem(422, 'Некорректный стабильный ID компонента.');
        if (isset($ids[$id])) throw new Problem(422, 'ID нового компонента уже используется.');
        $attributes->id = $id;
        $ids[$id] = true;
        $node->attributes = $attributes;

        if (isset($node->style)) self::validateStyles($node->style);
        if (isset($node->components)) {
            if (!is_array($node->components) || !array_is_list($node->components) || count($node->components) > 500) throw new Problem(422, 'Некорректный список дочерних компонентов.');
            $children = [];
            foreach ($node->components as $child) $children[] = self::normalizeComponent($child, $ids, $depth + 1, $count);
            $node->components = $children;
        }
        return $node;
    }

    private static function applyStyles(\stdClass $component, mixed $styles): void {
        self::validateStyles($styles);
        if (isset($component->style) && !$component->style instanceof \stdClass) throw new Problem(422, 'Стили компонента должны быть объектом.');
        foreach (get_object_vars($styles) as $property => $value) {
            if ($value === null) {
                if (isset($component->style)) unset($component->style->{$property});
                continue;
            }
            if (!isset($component->style)) $component->style = new \stdClass();
            $component->style->{$property} = $value;
        }
        if (isset($component->style) && get_object_vars($component->style) === []) unset($component->style);
    }

    private static function validateStyles(mixed $styles): void {
        if (!$styles instanceof \stdClass || get_object_vars($styles) === []) throw new Problem(422, 'Укажите CSS-свойства объектом.');
        foreach (get_object_vars($styles) as $property => $value) {
            if (!ComponentStylePolicy::allows($property)) throw new Problem(422, 'CSS-свойство не входит в разрешённый список.');
            if ($value === null) continue;
            if (!is_string($value) || $value === '' || mb_strlen($value, 'UTF-8') > 512 || preg_match('/[\x00-\x1F\x7F;{}<>\\\\]/', $value)) throw new Problem(422, 'CSS-значение содержит недопустимые символы или превышает 512 символов.');
        }
    }

    private static function move(\stdClass $document, string $componentId, string $parentId, mixed $index): void {
        $location = self::findComponent($document, $componentId);
        if ($location['parentPath'] === null || $location['index'] === null) throw new Problem(422, 'Корневой компонент страницы нельзя переместить.');
        $parentPath = self::findParentPath($document, $parentId);
        if (self::isPathPrefix($location['path'], $parentPath)) throw new Problem(422, 'Компонент нельзя переместить внутрь самого себя.');
        $oldParent =& self::atPath($document, $location['parentPath']);
        $newParent =& self::atPath($document, $parentPath);
        self::canContain($newParent);
        if (!is_array($oldParent->components ?? null) || !array_is_list($oldParent->components)) throw new Problem(422, 'Некорректный родительский компонент.');
        if (isset($newParent->components) && (!is_array($newParent->components) || !array_is_list($newParent->components))) throw new Problem(422, 'Некорректный список дочерних компонентов.');
        $children = $newParent->components ?? [];
        $maximum = count($children) - ($oldParent === $newParent ? 1 : 0);
        $insertAt = $index === null ? $maximum : self::index($index, $maximum);
        self::relocate($location, $oldParent, $newParent, $insertAt);
    }

    private static function relocate(array $location, \stdClass $oldParent, \stdClass $newParent, int $insertAt): void {
        if (!is_array($oldParent->components ?? null) || !array_is_list($oldParent->components)) throw new Problem(422, 'Некорректный родительский компонент.');
        $node = $oldParent->components[$location['index']] ?? null;
        if (!$node instanceof \stdClass) throw new Problem(422, 'Компонент нельзя переместить.');
        $oldChildren = $oldParent->components;
        array_splice($oldChildren, $location['index'], 1);
        $oldParent->components = $oldChildren;
        $newChildren = $newParent->components ?? [];
        if (!is_array($newChildren) || !array_is_list($newChildren)) throw new Problem(422, 'Некорректный список дочерних компонентов.');
        if ($insertAt > count($newChildren)) throw new Problem(422, 'Индекс компонента находится за пределами списка.');
        array_splice($newChildren, $insertAt, 0, [$node]);
        $newParent->components = $newChildren;
    }

    private static function canContain(\stdClass $parent): void {
        $type = $parent->type ?? null;
        $tag = strtolower((string)($parent->tagName ?? ''));
        if (in_array($type, ['image','text','textnode','link','link-block'], true) || is_string($parent->content ?? null) || in_array($tag, ['img','br','hr'], true)) throw new Problem(422, 'Этот компонент не может содержать дочерние элементы.');
    }

    private static function findComponent(\stdClass $document, string $id): array {
        $matches = self::findLocations($document, $id);
        if ($matches === []) throw new Problem(404, 'Компонент не найден.');
        if (count($matches) !== 1) throw new Problem(422, 'ID компонента неоднозначен.');
        return $matches[0];
    }

    private static function findParentPath(\stdClass $document, string $id): array {
        if (str_starts_with($id, 'page:')) {
            $pageId = substr($id, 5);
            if ($pageId === '') throw new Problem(422, 'Некорректный page ID.');
            foreach ($document->data->pages as $pageIndex => $page) {
                if (($page->id ?? null) !== $pageId) continue;
                $frame = $page->frames[0] ?? null;
                if (!$frame instanceof \stdClass || !isset($frame->component) || !$frame->component instanceof \stdClass) throw new Problem(422, 'У страницы нет корневого компонента.');
                return ['data','pages',$pageIndex,'frames',0,'component'];
            }
            throw new Problem(404, 'Страница не найдена.');
        }
        return self::findComponent($document, $id)['path'];
    }

    private static function findLocations(\stdClass $document, string $id): array {
        $matches = [];
        foreach ($document->data->pages as $pageIndex => $page) foreach ($page->frames as $frameIndex => $frame) {
            if ($frame instanceof \stdClass && isset($frame->component)) self::walk($frame->component, ['data','pages',$pageIndex,'frames',$frameIndex,'component'], null, null, $id, $matches, 0);
        }
        return $matches;
    }

    private static function walk(mixed $node, array $path, ?array $parentPath, ?int $index, string $id, array &$matches, int $depth): void {
        if (!$node instanceof \stdClass || $depth > 35) return;
        if (self::nodeId($node) === $id) $matches[] = ['path'=>$path,'parentPath'=>$parentPath,'index'=>$index];
        if (!is_array($node->components ?? null) || !array_is_list($node->components)) return;
        foreach ($node->components as $childIndex => $child) self::walk($child, [...$path,'components',$childIndex], $path, $childIndex, $id, $matches, $depth + 1);
    }

    private static function nodeId(\stdClass $node): ?string {
        if (($node->attributes ?? null) instanceof \stdClass && is_string($node->attributes->id ?? null)) return $node->attributes->id;
        return is_string($node->id ?? null) ? $node->id : null;
    }

    private static function collectIds(mixed $document, array &$ids): void {
        if (!$document instanceof \stdClass) return;
        foreach ($document->data->pages as $page) foreach ($page->frames as $frame) if ($frame instanceof \stdClass && isset($frame->component)) self::collectNodeIds($frame->component, $ids);
    }

    private static function collectNodeIds(mixed $node, array &$ids): void {
        if (!$node instanceof \stdClass) return;
        $id = self::nodeId($node);
        if ($id !== null) $ids[$id] = true;
        if (is_array($node->components ?? null)) foreach ($node->components as $child) self::collectNodeIds($child, $ids);
    }

    private static function isPathPrefix(array $prefix, array $path): bool {
        return count($prefix) <= count($path) && array_slice($path, 0, count($prefix)) === $prefix;
    }

    private static function index(mixed $value, int $maximum): int {
        if (!is_int($value) || $value < 0 || $value > $maximum) throw new Problem(422, 'Некорректная позиция компонента.');
        return $value;
    }

    private static function identifier(mixed $value): string {
        if (!is_string($value) || $value === '' || mb_strlen($value, 'UTF-8') > 128 || preg_match('/[\x00-\x1F\x7F]/', $value)) throw new Problem(422, 'Некорректный ID компонента или страницы.');
        return $value;
    }

    private static function fields(\stdClass $object, array $allowed, array $required): void {
        $fields = array_keys(get_object_vars($object));
        if (array_diff($fields, $allowed) || array_diff($required, $fields)) throw new Problem(422, 'Операция содержит неизвестные или отсутствующие поля.');
    }

    private static function &atPath(mixed &$root, array $path): mixed {
        foreach ($path as $segment) {
            if (is_int($segment)) $root =& $root[$segment];
            else $root =& $root->{$segment};
        }
        return $root;
    }
}
