<?php
declare(strict_types=1);
namespace Juzimder;

final class ProjectSettings {
    private const DESIGN_TOKEN_DEFAULTS = [
        'ink' => '#183e31',
        'forest' => '#245b46',
        'canvas' => '#ecf4ef',
        'paper' => '#f6faf7',
        'body' => '#527063',
        'muted' => '#68736c',
        'line' => '#dce4de',
        'accent' => '#b0dcc1',
        'fontFamily' => 'Arial, sans-serif',
        'headingFontFamily' => 'Arial, sans-serif',
        'bodyFontFamily' => 'Arial, sans-serif',
        'bodyFontWeight' => '400',
        'headingFontWeight' => '500',
        'baseFontSize' => '16px',
        'fontSizeH1' => '48px',
        'fontSizeH2' => '36px',
        'fontSizeH3' => '24px',
        'fontSizeH4' => '20px',
        'fontSizeH5' => '18px',
        'fontSizeH6' => '16px',
        'bodyLineHeight' => '1.6',
        'headingLineHeight' => '1.15',
        'letterSpacing' => '0px',
        'radius' => '8px',
    ];
    private const DESIGN_TOKEN_VARIABLES = [
        'ink' => '--juzimder-color-ink',
        'forest' => '--juzimder-color-forest',
        'canvas' => '--juzimder-color-canvas',
        'paper' => '--juzimder-color-paper',
        'body' => '--juzimder-color-body',
        'muted' => '--juzimder-color-muted',
        'line' => '--juzimder-color-line',
        'accent' => '--juzimder-color-accent',
        'fontFamily' => '--juzimder-font-family',
        'headingFontFamily' => '--juzimder-font-heading',
        'bodyFontFamily' => '--juzimder-font-body',
        'bodyFontWeight' => '--juzimder-font-weight-body',
        'headingFontWeight' => '--juzimder-font-weight-heading',
        'baseFontSize' => '--juzimder-font-size-base',
        'fontSizeH1' => '--juzimder-font-size-h1',
        'fontSizeH2' => '--juzimder-font-size-h2',
        'fontSizeH3' => '--juzimder-font-size-h3',
        'fontSizeH4' => '--juzimder-font-size-h4',
        'fontSizeH5' => '--juzimder-font-size-h5',
        'fontSizeH6' => '--juzimder-font-size-h6',
        'bodyLineHeight' => '--juzimder-line-height-body',
        'headingLineHeight' => '--juzimder-line-height-heading',
        'letterSpacing' => '--juzimder-letter-spacing',
        'radius' => '--juzimder-radius',
    ];
    private const FONT_FAMILIES = ['Arial, sans-serif', 'system-ui, sans-serif', 'Georgia, serif'];
    private const SEO_DEFAULTS = ['title' => '', 'description' => '', 'robots' => 'index', 'socialImage' => '', 'socialTitle' => '', 'socialDescription' => ''];
    private const NOT_FOUND_DEFAULTS = ['title' => '404', 'message' => 'Страница не найдена или была перемещена.', 'homeLabel' => 'Вернуться на главную', 'backgroundColor' => '', 'textColor' => '', 'buttonColor' => '', 'buttonTextColor' => ''];
    private const SHARED_SECTION_DEFAULTS = ['headerComponentId' => '', 'footerComponentId' => '', 'pages' => []];
    private const FORM_DEFAULTS = [
        'notificationsEnabled' => false, 'recipients' => [], 'senderName' => '', 'senderEmail' => '',
        'subject' => 'Новая заявка с сайта {{site}}', 'body' => "Новая заявка\n\n{{fields}}",
        'autoresponderEnabled' => false, 'autoresponderEmailField' => 'email',
        'autoresponderSubject' => 'Мы получили вашу заявку',
        'autoresponderBody' => "Здравствуйте!\n\nМы получили вашу заявку и свяжемся с вами.\n\n{{site}}",
    ];
    private const CUSTOM_CSS_PROPERTIES = ['color','background-color','display','flex-direction','flex-wrap','justify-content','align-items','align-content','align-self','gap','width','min-width','max-width','height','min-height','max-height','box-sizing','margin','padding','border','border-radius','outline','outline-offset','cursor','font-family','font-size','font-weight','font-style','line-height','letter-spacing','text-align','text-decoration','text-transform','object-fit','overflow','overflow-x','overflow-y','grid-template-columns','opacity'];

    public static function initial(mixed $document): array {
        $pages = self::documentPages($document);
        $routes = [];
        $used = [];
        foreach ($pages as $index => $page) {
            $id = (string)$page->id;
            $base = self::defaultSlug((string)($page->name ?? ''));
            $slug = self::uniqueSlug($base, $used);
            $used[$slug] = true;
            $routes[$id] = ['slug' => $slug, 'isHome' => $index === 0, 'seo' => self::SEO_DEFAULTS];
        }
        return ['schemaVersion' => 10, 'pages' => $routes, 'designTokens' => self::designTokensFromDocument($document), 'forms' => self::FORM_DEFAULTS, 'customCss' => '', 'notFound' => self::NOT_FOUND_DEFAULTS, 'sharedSections' => self::SHARED_SECTION_DEFAULTS];
    }

    public static function reconcile(mixed $settings, mixed $document): array {
        $pages = self::documentPages($document);
        if (!is_array($settings) || !in_array($settings['schemaVersion'] ?? null, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], true) || !is_array($settings['pages'] ?? null)) {
            $settings = self::initial($document);
        }
        $routes = [];
        $used = [];
        $homeId = null;
        foreach ($pages as $index => $page) {
            $id = (string)$page->id;
            $route = $settings['pages'][$id] ?? null;
            $slug = is_array($route) && is_string($route['slug'] ?? null) ? self::normalizeSlug($route['slug']) : self::defaultSlug((string)($page->name ?? ''));
            if ($slug === null || isset($used[$slug])) $slug = self::uniqueSlug(self::defaultSlug((string)($page->name ?? '')), $used);
            $used[$slug] = true;
            $isHome = is_array($route) && ($route['isHome'] ?? false) === true;
            if ($isHome && $homeId === null) $homeId = $id;
            try { $seo = self::validateSeoMetadata(is_array($route) ? ($route['seo'] ?? []) : [], self::SEO_DEFAULTS); }
            catch (Problem) { $seo = self::SEO_DEFAULTS; }
            $routes[$id] = ['slug' => $slug, 'isHome' => $isHome, 'seo' => $seo];
        }
        if ($homeId === null && $routes) $routes[(string)$pages[0]->id]['isHome'] = true;
        $settings['schemaVersion'] = 10;
        $settings['pages'] = $routes;
        $settings['designTokens'] = self::storedDesignTokens($settings['designTokens'] ?? self::designTokensFromDocument($document));
        try { $settings['forms'] = self::validateFormsSettings($settings['forms'] ?? [], self::FORM_DEFAULTS); }
        catch (Problem) { $settings['forms'] = self::FORM_DEFAULTS; }
        try { $settings['customCss'] = self::validateCustomCss($settings['customCss'] ?? ''); }
        catch (Problem) { $settings['customCss'] = ''; }
        try { $settings['notFound'] = self::validateNotFoundSettings($settings['notFound'] ?? [], self::NOT_FOUND_DEFAULTS); }
        catch (Problem) { $settings['notFound'] = self::NOT_FOUND_DEFAULTS; }
        $sectionIds = self::topLevelSectionIds($document);
        try { $settings['sharedSections'] = self::validateSharedSections($settings['sharedSections'] ?? [], array_keys($routes), $sectionIds); }
        catch (Problem) { $settings['sharedSections'] = self::SHARED_SECTION_DEFAULTS; }
        return $settings;
    }

    public static function sharedSectionDefaults(): array { return self::SHARED_SECTION_DEFAULTS; }

    public static function validateSharedSections(mixed $value, array $pageIds, array $componentIds = []): array {
        if ($value instanceof \stdClass) $value = get_object_vars($value);
        if (!is_array($value) || array_diff(array_keys($value), array_keys(self::SHARED_SECTION_DEFAULTS))) throw new Problem(422, 'Настройки общих шапки и подвала содержат недопустимые поля.');
        $result = self::SHARED_SECTION_DEFAULTS;
        foreach (['headerComponentId', 'footerComponentId'] as $key) {
            $id = $value[$key] ?? '';
            if (!is_string($id) || ($id !== '' && !preg_match('/^[A-Za-z0-9_-]{1,120}$/D', $id))) throw new Problem(422, 'Выберите корректную секцию для шапки или подвала.');
            if ($id !== '' && !in_array($id, $componentIds, true)) throw new Problem(422, 'Выбранная секция больше не существует на страницах проекта.');
            $result[$key] = $id;
        }
        if ($result['headerComponentId'] !== '' && $result['headerComponentId'] === $result['footerComponentId']) throw new Problem(422, 'Для шапки и подвала выберите разные секции.');
        $pages = $value['pages'] ?? [];
        if ($pages instanceof \stdClass) $pages = get_object_vars($pages);
        if (!is_array($pages) || array_diff(array_keys($pages), $pageIds)) throw new Problem(422, 'Настройки общих секций ссылаются на неизвестную страницу.');
        foreach ($pages as $pageId => $flags) {
            if ($flags instanceof \stdClass) $flags = get_object_vars($flags);
            if (!is_array($flags) || array_diff(array_keys($flags), ['header', 'footer'])) throw new Problem(422, 'Настройки отображения общих секций некорректны.');
            $result['pages'][$pageId] = ['header' => ($flags['header'] ?? true) === true, 'footer' => ($flags['footer'] ?? true) === true];
            foreach ($flags as $flag) if (!is_bool($flag)) throw new Problem(422, 'Настройки отображения общих секций должны быть переключателями.');
        }
        return $result;
    }

    public static function topLevelSectionIds(mixed $document): array {
        $ids = [];
        foreach (self::documentPages($document) as $page) {
            $root = $page->frames[0]->component ?? null;
            if (!$root instanceof \stdClass) continue;
            foreach (($root->components ?? []) as $component) {
                if (!$component instanceof \stdClass) continue;
                $id = $component->attributes->id ?? null;
                if (is_string($id) && preg_match('/^[A-Za-z0-9_-]{1,120}$/D', $id)) $ids[$id] = true;
            }
        }
        return array_keys($ids);
    }

    public static function notFoundDefaults(): array { return self::NOT_FOUND_DEFAULTS; }

    public static function validateNotFoundSettings(mixed $value, array $fallback = []): array {
        if ($value instanceof \stdClass) $value = get_object_vars($value);
        if (!is_array($value) || array_diff(array_keys($value), array_keys(self::NOT_FOUND_DEFAULTS))) throw new Problem(422, 'Настройки страницы 404 содержат недопустимые поля.');
        $result = array_replace(self::NOT_FOUND_DEFAULTS, $fallback);
        foreach (self::NOT_FOUND_DEFAULTS as $key => $_) {
            if (!array_key_exists($key, $value)) continue;
            $text = $value[$key];
            if (str_ends_with($key, 'Color')) {
                if (!is_string($text) || ($text !== '' && !preg_match('/^#[a-fA-F0-9]{6}$/D', $text))) throw new Problem(422, 'Цвет страницы 404 должен быть задан в формате HEX.');
                $result[$key] = strtolower($text);
                continue;
            }
            $limits = ['title'=>100,'message'=>400,'homeLabel'=>80];
            if (!is_string($text) || mb_strlen($text, 'UTF-8') > $limits[$key] || preg_match('/[\x00-\x1F\x7F]/u', $text)) throw new Problem(422, 'Проверьте текст страницы 404.');
            $text = trim($text);
            if ($text === '') throw new Problem(422, 'Текст страницы 404 не должен быть пустым.');
            $result[$key] = $text;
        }
        return $result;
    }

    public static function validateCustomCss(mixed $value): string {
        if (!is_string($value) || strlen($value) > 12000 || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $value)) throw new Problem(422, 'CSS: максимум 12 000 символов и без управляющих символов.');
        $css = trim($value);
        if ($css === '') return '';
        if (preg_match('~/\*|\*/|[<>\\\\]|url\s*\(|expression\s*\(|javascript:|behavior\s*:|position\s*:~i', $css)) throw new Problem(422, 'CSS содержит запрещённую конструкцию.');
        $mediaPattern = '/@media\s*\(\s*(max|min)-width\s*:\s*(\d{3,4})px\s*\)\s*\{((?:[^{}]|\{[^{}]*\})*)\}/i';
        preg_match_all($mediaPattern, $css, $mediaRules, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
        if (count($mediaRules) > 10) throw new Problem(422, 'CSS: не более 10 media breakpoint правил.');
        if ($mediaRules) {
            $lastMedia = $mediaRules[count($mediaRules) - 1];
            $lastMediaEnd = $lastMedia[0][1] + strlen($lastMedia[0][0]);
            if (trim(substr($css, $lastMediaEnd)) !== '') throw new Problem(422, 'CSS: разместите media breakpoint правила после обычных правил.');
        }
        $baseCss = trim(preg_replace($mediaPattern, '', $css) ?? $css);
        $result = self::validateSimpleCss($baseCss);
        $ruleCount = substr_count($result, '{');
        foreach ($mediaRules as $media) {
            $mediaType = strtolower($media[1][0]);
            $width = (int)$media[2][0];
            if ($width < 320 || $width > 2560) throw new Problem(422, 'CSS: ширина media breakpoint должна быть от 320 до 2560 px.');
            $inner = self::validateSimpleCss(trim($media[3][0]));
            if ($inner === '') throw new Problem(422, 'CSS: media breakpoint должен содержать хотя бы одно правило.');
            $ruleCount += substr_count($inner, '{');
            if ($ruleCount > 100) throw new Problem(422, 'CSS: не более 100 правил суммарно.');
            $result .= ($result === '' ? '' : "\n").'@media ('.$mediaType.'-width: '.$width.'px){'.$inner.'}';
        }
        return $result;
    }

    private static function validateSimpleCss(string $css): string {
        if ($css === '') return '';
        if (preg_match('~/\*|\*/|[<>@\\\\]|url\s*\(|expression\s*\(|javascript:|behavior\s*:|position\s*:~i', $css)) throw new Problem(422, 'CSS содержит запрещённую конструкцию.');
        preg_match_all('/([^{}]+)\{([^{}]*)\}/', $css, $rules, PREG_SET_ORDER);
        if (!$rules || count($rules) > 100 || trim(preg_replace('/([^{}]+)\{([^{}]*)\}/', '', $css) ?? $css) !== '') throw new Problem(422, 'CSS должен содержать до 100 простых правил вида .class { property: value; }.');
        $tags = ['main','header','nav','section','article','aside','footer','div','h1','h2','h3','h4','p','span','a','button','ul','ol','li','img','figure','figcaption','label','input','textarea','select'];
        $valuePatterns = [
            'color' => '/^(?:#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})|transparent|currentcolor|black|white|inherit)$/i',
            'background-color' => '/^(?:#(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})|transparent|black|white|inherit)$/i',
            'display' => '/^(?:block|inline|inline-block|flex|grid|none)$/i',
            'flex-direction' => '/^(?:row|row-reverse|column|column-reverse)$/i',
            'justify-content' => '/^(?:normal|start|end|center|space-between|space-around|space-evenly|flex-start|flex-end)$/i',
            'align-items' => '/^(?:normal|start|end|center|stretch|baseline|flex-start|flex-end)$/i',
            'font-weight' => '/^(?:normal|bold|[1-9]00)$/i',
            'font-family' => '/^(?:Arial,\s*sans-serif|system-ui,\s*sans-serif|Georgia,\s*serif)$/i',
            'font-style' => '/^(?:normal|italic|oblique)$/i',
            'text-transform' => '/^(?:none|uppercase|lowercase|capitalize)$/i',
            'text-align' => '/^(?:start|end|left|right|center|justify)$/i',
            'text-decoration' => '/^(?:none|underline|overline|line-through)$/i',
            'box-sizing' => '/^(?:border-box|content-box)$/i',
            'flex-wrap' => '/^(?:nowrap|wrap|wrap-reverse)$/i',
            'align-content' => '/^(?:normal|start|end|center|space-between|space-around|space-evenly|stretch|flex-start|flex-end)$/i',
            'align-self' => '/^(?:auto|normal|start|end|center|stretch|baseline|flex-start|flex-end)$/i',
            'object-fit' => '/^(?:fill|contain|cover|none|scale-down)$/i',
            'overflow' => '/^(?:auto|hidden|visible|scroll)$/i',
            'overflow-x' => '/^(?:auto|hidden|visible|scroll)$/i',
            'overflow-y' => '/^(?:auto|hidden|visible|scroll)$/i',
            'border' => '/^(?:0|(?:[0-9]{1,3}px)\s+(?:solid|dashed|dotted)\s+(?:#(?:[0-9a-f]{3}|[0-9a-f]{6})|transparent))$/i',
            'outline' => '/^(?:0|(?:[0-9]{1,3}px)\s+(?:solid|dashed|dotted)\s+(?:#(?:[0-9a-f]{3}|[0-9a-f]{6})|transparent))$/i',
            'cursor' => '/^(?:default|pointer|text|not-allowed|help|wait|grab|grabbing)$/i',
        ];
        $length = '(?:0|(?:-?[0-9]{1,4}(?:\.[0-9]{1,2})?(?:px|rem|em|%|vw|vh)))';
        $lengthList = '/^'.$length.'(?:\s+'.$length.'){0,3}$/i';
        $gridTrack = '(?:auto|[1-9]fr|'.$length.')';
        $gridTracks = '/^'.$gridTrack.'(?:\s+'.$gridTrack.'){0,5}$/i';
        foreach ($rules as $rule) {
            $selectors = array_map('trim', explode(',', trim($rule[1])));
            if (count($selectors) > 8) throw new Problem(422, 'CSS: слишком много селекторов в правиле.');
            foreach ($selectors as $selector) {
                $parts = preg_split('/\s+/', $selector, -1, PREG_SPLIT_NO_EMPTY) ?: [];
                if (!$parts || count($parts) > 5) throw new Problem(422, 'CSS: используйте простые селекторы классов и HTML-элементов.');
                foreach ($parts as $part) {
                    if (!preg_match('/^(.+?)(?::(hover|focus|focus-visible|active|disabled|checked))?$/iD', $part, $selectorMatch)) throw new Problem(422, 'CSS: разрешены только простые селекторы и состояния элементов.');
                    $baseSelector = $selectorMatch[1];
                    if (str_starts_with($baseSelector, '.')) { if (!preg_match('/^\.[A-Za-z_][A-Za-z0-9_-]{0,63}$/D', $baseSelector)) throw new Problem(422, 'CSS: некорректный селектор класса.'); }
                    elseif (!in_array(strtolower($baseSelector), $tags, true)) throw new Problem(422, 'CSS: разрешены только классы и базовые HTML-селекторы.');
                }
            }
            $declarations = array_filter(array_map('trim', explode(';', $rule[2])), static fn($item)=>$item !== '');
            if (count($declarations) > 20) throw new Problem(422, 'CSS: не более 20 свойств в одном правиле.');
            foreach ($declarations as $declaration) {
                if (!preg_match('/^([a-z-]+)\s*:\s*(.*?)$/is', $declaration, $match)) throw new Problem(422, 'CSS: проверьте запись свойства и значения.');
                $property = strtolower($match[1]); $item = trim($match[2]);
                if (!in_array($property, self::CUSTOM_CSS_PROPERTIES, true) || $item === '') throw new Problem(422, 'CSS: свойство не входит в безопасный список.');
                $valid = isset($valuePatterns[$property]) ? preg_match($valuePatterns[$property], $item) === 1 : preg_match($lengthList, $item) === 1;
                if (in_array($property, ['gap','padding','border-radius'], true)) $valid = preg_match($lengthList, $item) === 1;
                if ($property === 'outline-offset') $valid = preg_match('/^'.$length.'$/i', $item) === 1;
                if ($property === 'margin') $valid = preg_match('/^(?:auto|'.$length.')(?:\\s+(?:auto|'.$length.')){0,3}$/i', $item) === 1;
                if (in_array($property, ['width','min-width','max-width','height','min-height','max-height','font-size','letter-spacing'], true)) $valid = preg_match('/^'.$length.'$/i', $item) === 1;
                if ($property === 'line-height') $valid = preg_match('/^'.$length.'$/i', $item) === 1 || (is_numeric($item) && (float)$item >= 0.5 && (float)$item <= 4);
                if ($property === 'grid-template-columns') $valid = preg_match($gridTracks, $item) === 1;
                if ($property === 'opacity') $valid = preg_match('/^(?:0|1|0?\.[0-9]{1,2})$/D', $item) === 1;
                if (!$valid || preg_match('/[()"\']/', $item)) throw new Problem(422, 'CSS: значение свойства недопустимо.');
            }
        }
        return implode("\n", array_map(static fn($rule)=>trim($rule[1]).'{'.trim($rule[2]).'}', $rules));
    }

    public static function formDefaults(): array { return self::FORM_DEFAULTS; }

    public static function validateFormsSettings(mixed $value, array $fallback = []): array {
        if ($value instanceof \stdClass) $value = get_object_vars($value);
        if (!is_array($value) || array_diff(array_keys($value), array_keys(self::FORM_DEFAULTS))) throw new Problem(422, 'Настройки форм содержат недопустимые поля.');
        $result = array_replace(self::FORM_DEFAULTS, $fallback);
        foreach (['notificationsEnabled','autoresponderEnabled'] as $key) {
            if (array_key_exists($key, $value)) {
                if (!is_bool($value[$key])) throw new Problem(422, 'Проверьте состояние переключателей доставки.');
                $result[$key] = $value[$key];
            }
        }
        if (array_key_exists('recipients', $value)) {
            if (!is_array($value['recipients']) || !array_is_list($value['recipients']) || count($value['recipients']) > 10) throw new Problem(422, 'Укажите не более 10 адресов получателей.');
            $recipients = [];
            foreach ($value['recipients'] as $email) {
                if (!is_string($email) || strlen($email) > 254 || !filter_var(trim($email), FILTER_VALIDATE_EMAIL)) throw new Problem(422, 'Проверьте адреса email для уведомлений.');
                $email = strtolower(trim($email));
                if (!in_array($email, $recipients, true)) $recipients[] = $email;
            }
            $result['recipients'] = $recipients;
        }
        foreach (['senderName'=>100,'senderEmail'=>254,'subject'=>200,'body'=>10000,'autoresponderEmailField'=>64,'autoresponderSubject'=>200,'autoresponderBody'=>10000] as $key=>$limit) {
            if (!array_key_exists($key, $value)) continue;
            $item = $value[$key];
            if (!is_string($item) || mb_strlen($item, 'UTF-8') > $limit || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', $item)) throw new Problem(422, 'Проверьте длину и символы в настройках писем.');
            $item = trim($item);
            if ($key === 'senderEmail' && $item !== '' && !filter_var($item, FILTER_VALIDATE_EMAIL)) throw new Problem(422, 'Укажите корректный email отправителя.');
            if ($key === 'autoresponderEmailField' && $item !== '' && !preg_match('/^[A-Za-z][A-Za-z0-9_-]{0,63}$/D', $item)) throw new Problem(422, 'Укажите имя поля email из формы.');
            $result[$key] = $item;
        }
        return $result;
    }

    public static function designTokenDefaults(): array { return self::DESIGN_TOKEN_DEFAULTS; }

    public static function seoDefaults(): array { return self::SEO_DEFAULTS; }

    public static function validateSeoMetadata(mixed $value, array $fallback = []): array {
        if ($value instanceof \stdClass) $value = get_object_vars($value);
        if (!is_array($value) || array_diff(array_keys($value), array_keys(self::SEO_DEFAULTS))) throw new Problem(422, 'SEO-настройки должны содержать только разрешённые поля.');
        $seo = self::SEO_DEFAULTS;
        foreach (self::SEO_DEFAULTS as $name => $default) {
            if (array_key_exists($name, $fallback)) $seo[$name] = $fallback[$name];
        }
        foreach ($value as $name => $item) {
            if (in_array($name, ['title', 'description', 'socialTitle', 'socialDescription'], true)) {
                $limit = in_array($name, ['title','socialTitle'], true) ? 70 : 160;
                if (!is_string($item) || mb_strlen(trim($item), 'UTF-8') > $limit || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $item)) throw new Problem(422, $name === 'title' ? 'Заголовок SEO: не более 70 символов.' : 'Описание SEO: не более 160 символов.');
                $seo[$name] = trim($item);
            } elseif ($name === 'robots') {
                if (!is_string($item) || !in_array($item, ['index', 'noindex'], true)) throw new Problem(422, 'Выберите index или noindex.');
                $seo[$name] = $item;
            } elseif ($name === 'socialImage') {
                if (!is_string($item) || mb_strlen($item, 'UTF-8') > 2048) throw new Problem(422, 'Ссылка на изображение должна быть HTTPS-адресом длиной до 2048 символов.');
                $item = trim($item);
                if ($item !== '') {
                    $parts = parse_url($item);
                    if (!filter_var($item, FILTER_VALIDATE_URL) || !is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https' || empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])) throw new Problem(422, 'Изображение для соцсетей должно иметь корректный HTTPS-адрес.');
                }
                $seo[$name] = $item;
            }
        }
        return $seo;
    }

    public static function validateDesignTokens(mixed $value, array $fallback = []): array {
        if ($value instanceof \stdClass) $value = get_object_vars($value);
        if (!is_array($value)) throw new Problem(422, 'Настройки цветов и шрифтов должны быть объектом.');
        if (array_diff(array_keys($value), array_keys(self::DESIGN_TOKEN_DEFAULTS))) throw new Problem(422, 'В настройках есть неизвестный design token.');
        $tokens = self::storedDesignTokens($fallback);
        foreach ($value as $name => $item) {
            if (in_array($name, ['ink','forest','canvas','paper','body','muted','line','accent'], true)) {
                if (!is_string($item) || !preg_match('/^#[0-9a-f]{6}$/i', $item)) throw new Problem(422, 'Укажите цвет в формате #RRGGBB.');
                $tokens[$name] = strtolower($item);
            } elseif (in_array($name, ['fontFamily','headingFontFamily','bodyFontFamily'], true)) {
                if (!is_string($item) || !in_array($item, self::FONT_FAMILIES, true)) throw new Problem(422, 'Выберите шрифт из списка.');
                $tokens[$name] = $item;
            } elseif (in_array($name, ['bodyFontWeight','headingFontWeight'], true)) {
                if (!is_string($item) || !in_array($item, ['300','400','500','600','700','800'], true)) throw new Problem(422, 'Укажите вес шрифта от 300 до 800.');
                $tokens[$name] = $item;
            } elseif (in_array($name, ['baseFontSize','fontSizeH1','fontSizeH2','fontSizeH3','fontSizeH4','fontSizeH5','fontSizeH6'], true)) {
                $bounds = ['baseFontSize'=>[12,24],'fontSizeH1'=>[28,80],'fontSizeH2'=>[22,64],'fontSizeH3'=>[18,48],'fontSizeH4'=>[16,40],'fontSizeH5'=>[14,32],'fontSizeH6'=>[12,28]][$name];
                if (!is_string($item) || !preg_match('/^(\d{1,3})px$/', $item, $size) || (int)$size[1] < $bounds[0] || (int)$size[1] > $bounds[1]) throw new Problem(422, 'Размер типографического токена вне допустимого диапазона.');
                $tokens[$name] = ((int)$size[1]) . 'px';
            } elseif (in_array($name, ['bodyLineHeight','headingLineHeight'], true)) {
                if (!is_string($item) || !in_array($item, ['1','1.1','1.15','1.2','1.25','1.3','1.4','1.5','1.6','1.7','1.8','1.9','2'], true)) throw new Problem(422, 'Межстрочный интервал должен быть от 1 до 2.');
                $tokens[$name] = $item;
            } elseif ($name === 'letterSpacing') {
                if (!is_string($item) || !in_array($item, ['-2px','-1px','-0.5px','0px','0.25px','0.5px','1px','1.5px','2px'], true)) throw new Problem(422, 'Выберите межбуквенный интервал из списка.');
                $tokens[$name] = $item;
            } elseif ($name === 'radius') {
                if (!is_string($item) || !preg_match('/^(?:0|[1-9]|[12][0-9]|3[0-2])px$/', $item)) throw new Problem(422, 'Скругление должно быть от 0 до 32 px.');
                $tokens[$name] = $item;
            }
        }
        $hasSeparateFamilies = array_key_exists('headingFontFamily', $value) || array_key_exists('bodyFontFamily', $value);
        if (array_key_exists('fontFamily', $value) && !$hasSeparateFamilies) {
            $tokens['headingFontFamily'] = $tokens['fontFamily'];
            $tokens['bodyFontFamily'] = $tokens['fontFamily'];
        } else {
            if (array_key_exists('headingFontFamily', $value)) $tokens['headingFontFamily'] = $value['headingFontFamily'];
            if (array_key_exists('bodyFontFamily', $value)) $tokens['bodyFontFamily'] = $value['bodyFontFamily'];
            $tokens['fontFamily'] = $tokens['bodyFontFamily'];
        }
        return $tokens;
    }

    public static function applyDesignTokensToDocument(mixed $document, array $tokens): \stdClass {
        $tokens = self::validateDesignTokens($tokens);
        $copy = json_decode(json_encode($document, JSON_THROW_ON_ERROR), false, 64, JSON_THROW_ON_ERROR);
        foreach (self::documentPages($copy) as $page) {
            foreach (($page->frames ?? []) as $frame) {
                if (!isset($frame->component) || !$frame->component instanceof \stdClass) continue;
                self::migrateLegacyStyles($frame->component);
                if (!isset($frame->component->style) || !$frame->component->style instanceof \stdClass) $frame->component->style = new \stdClass();
                foreach (self::designTokenStyles($tokens) as $property => $value) $frame->component->style->{$property} = $value;
                self::applyInheritedTypography($frame->component->style);
                self::applyHeadingDefaults($frame->component);
            }
        }
        return $copy;
    }

    public static function designTokenStyles(array $tokens): array {
        $tokens = self::validateDesignTokens($tokens);
        $styles = [];
        foreach (self::DESIGN_TOKEN_VARIABLES as $name => $variable) $styles[$variable] = self::designTokenCssValue($name, $tokens[$name]);
        return $styles;
    }

    private static function designTokenCssValue(string $name, string $value): string {
        if ($name === 'fontSizeH1') return 'clamp(28px, calc(18px + 2.35vw), ' . $value . ')';
        if ($name === 'fontSizeH2') return 'clamp(22px, calc(17px + 1.5vw), ' . $value . ')';
        if ($name === 'fontSizeH3') return 'clamp(18px, calc(12px + 0.9vw), ' . $value . ')';
        return $value;
    }

    private static function designTokensFromDocument(mixed $document): array {
        $tokens = self::DESIGN_TOKEN_DEFAULTS;
        foreach (self::documentPages($document) as $page) {
            foreach (($page->frames ?? []) as $frame) {
                $style = $frame->component->style ?? null;
                if (!$style instanceof \stdClass) continue;
                foreach (self::DESIGN_TOKEN_VARIABLES as $name => $variable) {
                    if (!isset($style->{$variable})) continue;
                    $value = $style->{$variable};
                    if (in_array($name, ['fontSizeH1','fontSizeH2','fontSizeH3'], true) && is_string($value) && preg_match('/,\s*(\d{1,3}px)\s*\)$/', $value, $size)) $value = $size[1];
                    $tokens[$name] = $value;
                }
                if (isset($style->{'--juzimder-font-family'}) && !isset($style->{'--juzimder-font-heading'}) && !isset($style->{'--juzimder-font-body'})) {
                    $tokens['fontFamily'] = $style->{'--juzimder-font-family'};
                    $tokens['headingFontFamily'] = $style->{'--juzimder-font-family'};
                    $tokens['bodyFontFamily'] = $style->{'--juzimder-font-family'};
                }
                return self::storedDesignTokens($tokens);
            }
        }
        return $tokens;
    }

    private static function storedDesignTokens(mixed $value): array {
        if ($value instanceof \stdClass) $value = get_object_vars($value);
        $tokens = self::DESIGN_TOKEN_DEFAULTS;
        if (!is_array($value)) return $tokens;
        foreach ($value as $name => $item) {
            if (!array_key_exists($name, self::DESIGN_TOKEN_DEFAULTS)) continue;
            try { $tokens[$name] = self::validateDesignTokens([$name => $item])[$name]; }
            catch (Problem) { /* Ignore invalid historical values and keep the documented default. */ }
        }
        if (isset($value['fontFamily']) && !isset($value['headingFontFamily'])) $tokens['headingFontFamily'] = $tokens['fontFamily'];
        if (isset($value['fontFamily']) && !isset($value['bodyFontFamily'])) $tokens['bodyFontFamily'] = $tokens['fontFamily'];
        $tokens['fontFamily'] = $tokens['bodyFontFamily'];
        return $tokens;
    }

    private static function migrateLegacyStyles(\stdClass $component): void {
        if (isset($component->style) && $component->style instanceof \stdClass) {
            $legacy = [
                '#183e31' => 'ink', '#245b46' => 'forest', '#ecf4ef' => 'canvas', '#f6faf7' => 'paper',
                '#527063' => 'body', '#68736c' => 'muted', '#dce4de' => 'line', '#b0dcc1' => 'accent',
            ];
            $tagName = strtolower((string)($component->tagName ?? ''));
            foreach ($component->style as $property => $value) {
                if (!is_string($value)) continue;
                if ($property === 'font-family' && (strtolower(trim($value)) === strtolower(self::DESIGN_TOKEN_DEFAULTS['fontFamily']) || str_contains($value, '--juzimder-font-family'))) {
                    $fontToken = preg_match('/^h[1-6]$/', $tagName) ? '--juzimder-font-heading' : '--juzimder-font-body';
                    $component->style->{$property} = 'var(' . $fontToken . ')';
                } elseif ($property === 'font-size' && preg_match('/^h([1-6])$/', $tagName, $heading)) {
                    $legacySizes = ['1'=>['clamp(36px, 6vw, 76px)'],'2'=>['36px','clamp(28px, 4vw, 42px)','clamp(28px,4vw,42px)'],'3'=>['20px','18px','16px']];
                    if (str_contains($value, '--juzimder-font-size-h' . $heading[1]) || in_array(trim($value), $legacySizes[$heading[1]] ?? [], true)) $component->style->{$property} = 'var(--juzimder-font-size-h' . $heading[1] . ')';
                } elseif ($property === 'font-size' && $tagName === 'p' && trim($value) === '18px') {
                    $component->style->{$property} = 'var(--juzimder-font-size-base)';
                } elseif ($property === 'font-weight' && preg_match('/^h[1-6]$/', $tagName) && in_array(trim($value), ['500','600','700'], true)) {
                    $component->style->{$property} = 'var(--juzimder-font-weight-heading)';
                } elseif ($property === 'line-height' && preg_match('/^h[1-6]$/', $tagName) && in_array(trim($value), ['1.05','1.15','1.2'], true)) {
                    $component->style->{$property} = 'var(--juzimder-line-height-heading)';
                } elseif ($property === 'line-height' && !preg_match('/^h[1-6]$/', $tagName) && in_array(trim($value), ['1.6','1.65','1.7'], true)) {
                    $component->style->{$property} = 'var(--juzimder-line-height-body)';
                } elseif ($property === 'border-radius' && in_array(trim($value), ['6px','8px'], true)) {
                    $component->style->{$property} = 'var(--juzimder-radius)';
                } else {
                    $component->style->{$property} = preg_replace_callback('/#[0-9a-f]{6}\b/i', static function (array $match) use ($legacy): string {
                        $name = $legacy[strtolower($match[0])] ?? null;
                        return $name ? 'var(--juzimder-color-' . $name . ')' : $match[0];
                    }, $value) ?? $value;
                }
            }
        }
        foreach (($component->components ?? []) as $child) if ($child instanceof \stdClass) self::migrateLegacyStyles($child);
    }

    private static function applyInheritedTypography(\stdClass $style): void {
        $defaults = [
            'font-family' => 'var(--juzimder-font-body, Arial, sans-serif)',
            'font-size' => 'var(--juzimder-font-size-base, 16px)',
            'font-weight' => 'var(--juzimder-font-weight-body, 400)',
            'line-height' => 'var(--juzimder-line-height-body, 1.6)',
            'letter-spacing' => 'var(--juzimder-letter-spacing, 0px)',
        ];
        foreach ($defaults as $property => $value) {
            $current = $style->{$property} ?? null;
            if (!is_string($current) || !str_contains($current, '--juzimder-font') && !str_contains($current, '--juzimder-line-height') && !str_contains($current, '--juzimder-letter-spacing')) {
                if ($current === null) $style->{$property} = $value;
                continue;
            }
            $style->{$property} = $value;
        }
    }

    private static function applyHeadingDefaults(\stdClass $component): void {
        $tagName = strtolower((string)($component->tagName ?? ''));
        if (preg_match('/^h([1-6])$/', $tagName, $match)) {
            if (!isset($component->style) || !$component->style instanceof \stdClass) $component->style = new \stdClass();
            $heading = $match[1];
            $defaults = [
                'font-family' => 'var(--juzimder-font-heading, Arial, sans-serif)',
                'font-size' => 'var(--juzimder-font-size-h' . $heading . ')',
                'font-weight' => 'var(--juzimder-font-weight-heading, 500)',
                'line-height' => 'var(--juzimder-line-height-heading, 1.15)',
            ];
            foreach ($defaults as $property => $value) {
                $current = $component->style->{$property} ?? null;
                if ($current === null || is_string($current) && (str_contains($current, '--juzimder-font') || str_contains($current, '--juzimder-line-height'))) $component->style->{$property} = $value;
            }
        }
        foreach (($component->components ?? []) as $child) if ($child instanceof \stdClass) self::applyHeadingDefaults($child);
    }

    public static function validateSlug(string $raw): string {
        $slug = self::normalizeSlug($raw);
        if ($slug === null) throw new Problem(422, 'Введите URL из одной части, например about-us.');
        if (in_array($slug, ['api','assets','projects','login','register','logout','settings','editor','preview','robots-txt','sitemap-xml'], true)) {
            throw new Problem(422, 'Этот URL зарезервирован системой.');
        }
        return $slug;
    }

    public static function normalizeSlug(string $raw): ?string {
        $raw = trim($raw);
        if ($raw === '') return null;
        if (str_starts_with($raw, '/')) $raw = substr($raw, 1);
        if ($raw === '' || str_contains($raw, '/')) return null;
        $slug = self::slugify($raw);
        return $slug !== '' ? $slug : null;
    }

    public static function slugify(string $value): string {
        $map = [
            'А'=>'a','Б'=>'b','В'=>'v','Г'=>'g','Д'=>'d','Е'=>'e','Ё'=>'yo','Ж'=>'zh','З'=>'z','И'=>'i','Й'=>'y','К'=>'k','Л'=>'l','М'=>'m','Н'=>'n','О'=>'o','П'=>'p','Р'=>'r','С'=>'s','Т'=>'t','У'=>'u','Ф'=>'f','Х'=>'kh','Ц'=>'ts','Ч'=>'ch','Ш'=>'sh','Щ'=>'shch','Ъ'=>'','Ы'=>'y','Ь'=>'','Э'=>'e','Ю'=>'yu','Я'=>'ya',
            'Ә'=>'a','Ғ'=>'g','Қ'=>'q','Ң'=>'n','Ө'=>'o','Ұ'=>'u','Ү'=>'u','Һ'=>'h','І'=>'i',
        ];
        $value = strtr(mb_strtolower(trim($value), 'UTF-8'), array_combine(array_map(static fn($key) => mb_strtolower($key, 'UTF-8'), array_keys($map)), array_values($map)));
        $ascii = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);
        $ascii = strtolower($ascii === false ? $value : $ascii);
        $slug = preg_replace('/[^a-z0-9]+/', '-', $ascii) ?? '';
        return trim($slug, '-');
    }

    public static function defaultSlug(string $value): string {
        $slug = self::slugify($value);
        if ($slug === '') $slug = 'page';
        if (in_array($slug, ['api','assets','projects','login','register','logout','settings','editor','preview','robots-txt','sitemap-xml'], true)) $slug = 'page-' . $slug;
        return $slug;
    }

    private static function uniqueSlug(string $base, array $used): string {
        $base = $base !== '' ? $base : 'page';
        $candidate = $base;
        for ($suffix = 2; isset($used[$candidate]); $suffix++) $candidate = $base . '-' . $suffix;
        return $candidate;
    }

    private static function documentPages(mixed $document): array {
        if (is_array($document) && is_array($document['data']['pages'] ?? null)) {
            $pages = json_decode(json_encode($document['data']['pages'], JSON_THROW_ON_ERROR), false, 64, JSON_THROW_ON_ERROR);
            if (is_array($pages)) return $pages;
        }
        if (!$document instanceof \stdClass || !isset($document->data->pages) || !is_array($document->data->pages)) throw new Problem(422, 'Некорректный список страниц проекта.');
        return $document->data->pages;
    }
}
