const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/app-pjZ6-8AA.js","assets/app-DvJejwMP.css"])))=>i.map(i=>d[i]);
var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>()=>(t||(e((t={exports:{}}).exports,t,t.exports),e=null),t.exports),s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(var c=r(i),l=0,u=c.length,d;l<u;l++)d=c[l],!a.call(e,d)&&d!==o&&t(e,d,{get:(e=>i[e]).bind(null,d),enumerable:!(s=n(i,d))||s.enumerable});return e},c=(n,r,o)=>(o=n==null?{}:e(i(n)),s(r||!n||!n.__esModule||!a.call(n,`default`)?t(o,`default`,{value:n,enumerable:!0}):o,n));(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function l(e,t,n){let r=e.data.pages.find(e=>e.id===t),i,a=e=>{e.type===`zero-block`&&e.attributes?.id===n&&(i=e);for(let t of e.components||[])a(t)};return r&&a(r.frames[0].component),i}function u(e,t,n,r){let i=structuredClone(e),a=structuredClone(t),o=l(i,n,r),s=l(a,n,r);return!o||!s?!1:(o.zeroData=null,s.zeroData=null,JSON.stringify(i)===JSON.stringify(a))}function d(e,t){let n=Error(t?.error||`HTTP ${e.status}`);return n.status=e.status,n.code=t?.code,n}async function f(e){try{return await e.json()}catch{let t=Error(`Сервер вернул некорректный ответ. Обновите страницу и повторите запрос.`);throw t.status=e.status>=400?e.status:502,t}}async function p({path:e,method:t=`GET`,body:n,getSession:r,setSession:i,fetchImpl:a=fetch}){let o=n===void 0?void 0:JSON.stringify(n),s=n=>a(`/api${e}`,{method:t,credentials:`same-origin`,headers:{"Content-Type":`application/json`,...n?{"X-CSRF-Token":n}:{}},...o===void 0?{}:{body:o}}),c=await s(r()?.csrf),l=await f(c);if(c.status===403&&l?.code===`csrf_invalid`&&r()?.user?.id){let e=r(),t=null;try{let e=await a(`/api/session`,{method:`GET`,credentials:`same-origin`,cache:`no-store`,headers:{Accept:`application/json`}});e.ok&&(t=await e.json())}catch{}if(t?.csrf&&!t.sessionExpired&&t.user?.id===e.user.id)i({...e,...t}),c=await s(t.csrf),l=await f(c);else{let e=Error(`Сессия изменилась или истекла. Повторный вход нужен в той же вкладке; текущие несохранённые изменения оставлены в редакторе.`);throw e.status=401,e.code=`session_refresh_required`,e}}if(!c.ok)throw d(c,l);return l}function m(e,t,n=`row`,r=`nowrap`){let i=n.startsWith(`column`),a=n.endsWith(`reverse`);if(e===`flex-direction`)return{row:{name:`arrow-right`},column:{name:`arrow-down`},"row-reverse":{name:`arrow-left`},"column-reverse":{name:`arrow-up`}}[t]||null;if(e===`justify-content`){let e=i?`align-box-top-center`:`align-box-left-middle`,n=i?`align-box-bottom-center`:`align-box-right-middle`;return{"flex-start":{name:a?n:e},center:{name:`align-box-center-middle`},"flex-end":{name:a?e:n},"space-between":{name:i?`layout-distribute-horizontal`:`layout-distribute-vertical`},"space-around":{name:i?`spacing-vertical`:`spacing-horizontal`},"space-evenly":{name:`columns-3`,transform:i?`rotate(90deg)`:``}}[t]||null}if(e===`align-items`){let e=i?`align-box-left-middle`:`align-box-top-center`,n=i?`align-box-right-middle`:`align-box-bottom-center`;return{"flex-start":{name:r===`wrap-reverse`?n:e},center:{name:`align-box-center-middle`},"flex-end":{name:r===`wrap-reverse`?e:n},stretch:{name:i?`arrows-horizontal`:`arrows-vertical`},baseline:{name:`baseline`}}[t]||null}return e===`flex-wrap`&&{nowrap:{name:`text-wrap-disabled`},wrap:{name:`text-wrap`,transform:i?`rotate(90deg)`:``},"wrap-reverse":{name:`text-wrap`,transform:i?`rotate(90deg) scaleY(-1)`:`scaleY(-1)`}}[t]||null}var h={underline:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M7 5v5a5 5 0 0 0 10 0v-5" />
  <path d="M5 19h14" />
</svg>`,search:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M3 10a7 7 0 1 0 14 0a7 7 0 1 0 -14 0" />
  <path d="M21 21l-6 -6" />
</svg>`,"device-floppy":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M6 4h10l4 4v10a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2" />
  <path d="M10 14a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" />
  <path d="M14 4l0 4l-6 0l0 -4" />
</svg>`,"device-desktop":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M3 5a1 1 0 0 1 1 -1h16a1 1 0 0 1 1 1v10a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1 -1v-10" />
  <path d="M7 20h10" />
  <path d="M9 16v4" />
  <path d="M15 16v4" />
</svg>`,dots:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
  <path d="M11 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
  <path d="M18 12a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
</svg>`,scissors:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M3 7a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
  <path d="M3 17a3 3 0 1 0 6 0a3 3 0 1 0 -6 0" />
  <path d="M8.6 8.6l10.4 10.4" />
  <path d="M8.6 15.4l10.4 -10.4" />
</svg>`,"arrows-move":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M18 9l3 3l-3 3" />
  <path d="M15 12h6" />
  <path d="M6 9l-3 3l3 3" />
  <path d="M3 12h6" />
  <path d="M9 18l3 3l3 -3" />
  <path d="M12 15v6" />
  <path d="M15 6l-3 -3l-3 3" />
  <path d="M12 3v6" />
</svg>`,"layout-grid":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 5a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4" />
  <path d="M14 5a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4" />
  <path d="M4 15a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4" />
  <path d="M14 15a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v4a1 1 0 0 1 -1 1h-4a1 1 0 0 1 -1 -1l0 -4" />
</svg>`,"chevron-down":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M6 9l6 6l6 -6" />
</svg>`,strikethrough:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M5 12l14 0" />
  <path d="M16 6.5a4 2 0 0 0 -4 -1.5h-1a3.5 3.5 0 0 0 0 7h2a3.5 3.5 0 0 1 0 7h-1.5a4 2 0 0 1 -4 -1.5" />
</svg>`,"chevron-up":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M6 15l6 -6l6 6" />
</svg>`,typography:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 20l3 0" />
  <path d="M14 20l7 0" />
  <path d="M6.9 15l6.9 0" />
  <path d="M10.2 6.3l5.8 13.7" />
  <path d="M5 20l6 -16l2 0l7 16" />
</svg>`,"file-text":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M14 3v4a1 1 0 0 0 1 1h4" />
  <path d="M17 21h-10a2 2 0 0 1 -2 -2v-14a2 2 0 0 1 2 -2h7l5 5v11a2 2 0 0 1 -2 2" />
  <path d="M9 9l1 0" />
  <path d="M9 13l6 0" />
  <path d="M9 17l6 0" />
</svg>`,"arrows-horizontal":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M7 8l-4 4l4 4" />
  <path d="M17 8l4 4l-4 4" />
  <path d="M3 12l18 0" />
</svg>`,x:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M18 6l-12 12" />
  <path d="M6 6l12 12" />
</svg>`,"chevron-right":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M9 6l6 6l-6 6" />
</svg>`,clipboard:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M9 5h-2a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-12a2 2 0 0 0 -2 -2h-2" />
  <path d="M9 5a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2a2 2 0 0 1 -2 2h-2a2 2 0 0 1 -2 -2" />
</svg>`,link:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M9 15l6 -6" />
  <path d="M11 6l.463 -.536a5 5 0 0 1 7.071 7.072l-.534 .464" />
  <path d="M13 18l-.397 .534a5.068 5.068 0 0 1 -7.127 0a4.972 4.972 0 0 1 0 -7.071l.524 -.463" />
</svg>`,"arrow-right":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M5 12l14 0" />
  <path d="M13 18l6 -6" />
  <path d="M13 6l6 6" />
</svg>`,selector:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M8 9l4 -4l4 4" />
  <path d="M16 15l-4 4l-4 -4" />
</svg>`,settings:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M10.325 4.317c.426 -1.756 2.924 -1.756 3.35 0a1.724 1.724 0 0 0 2.573 1.066c1.543 -.94 3.31 .826 2.37 2.37a1.724 1.724 0 0 0 1.065 2.572c1.756 .426 1.756 2.924 0 3.35a1.724 1.724 0 0 0 -1.066 2.573c.94 1.543 -.826 3.31 -2.37 2.37a1.724 1.724 0 0 0 -2.572 1.065c-.426 1.756 -2.924 1.756 -3.35 0a1.724 1.724 0 0 0 -2.573 -1.066c-1.543 .94 -3.31 -.826 -2.37 -2.37a1.724 1.724 0 0 0 -1.065 -2.572c-1.756 -.426 -1.756 -2.924 0 -3.35a1.724 1.724 0 0 0 1.066 -2.573c-.94 -1.543 .826 -3.31 2.37 -2.37c1 .608 2.296 .07 2.572 -1.065" />
  <path d="M9 12a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" />
</svg>`,download:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2" />
  <path d="M7 11l5 5l5 -5" />
  <path d="M12 4l0 12" />
</svg>`,code:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M7 8l-4 4l4 4" />
  <path d="M17 8l4 4l-4 4" />
  <path d="M14 4l-4 16" />
</svg>`,"eye-off":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M10.585 10.587a2 2 0 0 0 2.829 2.828" />
  <path d="M16.681 16.673a8.717 8.717 0 0 1 -4.681 1.327c-3.6 0 -6.6 -2 -9 -6c1.272 -2.12 2.712 -3.678 4.32 -4.674m2.86 -1.146a9.055 9.055 0 0 1 1.82 -.18c3.6 0 6.6 2 9 6c-.666 1.11 -1.379 2.067 -2.138 2.87" />
  <path d="M3 3l18 18" />
</svg>`,bold:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M7 5h6a3.5 3.5 0 0 1 0 7h-6l0 -7" />
  <path d="M13 12h1a3.5 3.5 0 0 1 0 7h-7v-7" />
</svg>`,plus:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M12 5l0 14" />
  <path d="M5 12l14 0" />
</svg>`,"arrow-back-up":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M9 14l-4 -4l4 -4" />
  <path d="M5 10h11a4 4 0 1 1 0 8h-1" />
</svg>`,copy:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M7 9.667a2.667 2.667 0 0 1 2.667 -2.667h8.666a2.667 2.667 0 0 1 2.667 2.667v8.666a2.667 2.667 0 0 1 -2.667 2.667h-8.666a2.667 2.667 0 0 1 -2.667 -2.667l0 -8.666" />
  <path d="M4.012 16.737a2.005 2.005 0 0 1 -1.012 -1.737v-10c0 -1.1 .9 -2 2 -2h10c.75 0 1.158 .385 1.5 1" />
</svg>`,"align-right":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 6l16 0" />
  <path d="M10 12l10 0" />
  <path d="M6 18l14 0" />
</svg>`,"device-tablet":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M5 4a1 1 0 0 1 1 -1h12a1 1 0 0 1 1 1v16a1 1 0 0 1 -1 1h-12a1 1 0 0 1 -1 -1v-16" />
  <path d="M11 17a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" />
</svg>`,square:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M3 5a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-14" />
</svg>`,"device-mobile":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M6 5a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-8a2 2 0 0 1 -2 -2v-14" />
  <path d="M11 4h2" />
  <path d="M12 17v.01" />
</svg>`,trash:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 7l16 0" />
  <path d="M10 11l0 6" />
  <path d="M14 11l0 6" />
  <path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2 -2l1 -12" />
  <path d="M9 7v-3a1 1 0 0 1 1 -1h4a1 1 0 0 1 1 1v3" />
</svg>`,unlink:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M17 22v-2" />
  <path d="M9 15l6 -6" />
  <path d="M11 6l.463 -.536a5 5 0 0 1 7.071 7.072l-.534 .464" />
  <path d="M13 18l-.397 .534a5.068 5.068 0 0 1 -7.127 0a4.972 4.972 0 0 1 0 -7.071l.524 -.463" />
  <path d="M20 17h2" />
  <path d="M2 7h2" />
  <path d="M7 2v2" />
</svg>`,"arrow-forward-up":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M15 14l4 -4l-4 -4" />
  <path d="M19 10h-11a4 4 0 1 0 0 8h1" />
</svg>`,eye:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M10 12a2 2 0 1 0 4 0a2 2 0 0 0 -4 0" />
  <path d="M21 12c-2.4 4 -5.4 6 -9 6c-3.6 0 -6.6 -2 -9 -6c2.4 -4 5.4 -6 9 -6c3.6 0 6.6 2 9 6" />
</svg>`,"arrows-vertical":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M8 7l4 -4l4 4" />
  <path d="M8 17l4 4l4 -4" />
  <path d="M12 3l0 18" />
</svg>`,"arrow-up":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M12 5l0 14" />
  <path d="M18 11l-6 -6" />
  <path d="M6 11l6 -6" />
</svg>`,italic:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M11 5l6 0" />
  <path d="M7 19l6 0" />
  <path d="M14 5l-4 14" />
</svg>`,"arrow-left":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M5 12l14 0" />
  <path d="M5 12l6 6" />
  <path d="M5 12l6 -6" />
</svg>`,"align-center":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 6l16 0" />
  <path d="M8 12l8 0" />
  <path d="M6 18l12 0" />
</svg>`,"stack-2":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M12 4l-8 4l8 4l8 -4l-8 -4" />
  <path d="M4 12l8 4l8 -4" />
  <path d="M4 16l8 4l8 -4" />
</svg>`,menu:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 8l16 0" />
  <path d="M4 16l16 0" />
</svg>`,history:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M12 8l0 4l2 2" />
  <path d="M3.05 11a9 9 0 1 1 .5 4m-.5 5v-5h5" />
</svg>`,photo:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M15 8h.01" />
  <path d="M3 6a3 3 0 0 1 3 -3h12a3 3 0 0 1 3 3v12a3 3 0 0 1 -3 3h-12a3 3 0 0 1 -3 -3v-12" />
  <path d="M3 16l5 -5c.928 -.893 2.072 -.893 3 0l5 5" />
  <path d="M14 14l1 -1c.928 -.893 2.072 -.893 3 0l3 3" />
</svg>`,"align-left":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 6l16 0" />
  <path d="M4 12l10 0" />
  <path d="M4 18l14 0" />
</svg>`,"arrow-down":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M12 5l0 14" />
  <path d="M18 13l-6 6" />
  <path d="M6 13l6 6" />
</svg>`,"layout-distribute-horizontal":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 4l16 0" />
  <path d="M4 20l16 0" />
  <path d="M6 11a2 2 0 0 1 2 -2h8a2 2 0 0 1 2 2v2a2 2 0 0 1 -2 2h-8a2 2 0 0 1 -2 -2l0 -2" />
</svg>`,"text-wrap-disabled":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 6l10 0" />
  <path d="M4 18l10 0" />
  <path d="M4 12h17l-3 -3m0 6l3 -3" />
</svg>`,"align-box-right-middle":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M15 15h2" />
  <path d="M3 5a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-14" />
  <path d="M11 12h6" />
  <path d="M13 9h4" />
</svg>`,baseline:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 20h16" />
  <path d="M8 16v-8a4 4 0 1 1 8 0v8" />
  <path d="M8 10h8" />
</svg>`,"spacing-horizontal":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M20 20h-2a2 2 0 0 1 -2 -2v-12a2 2 0 0 1 2 -2h2" />
  <path d="M4 20h2a2 2 0 0 0 2 -2v-12a2 2 0 0 0 -2 -2h-2" />
  <path d="M12 8v8" />
</svg>`,"align-box-bottom-center":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M3 5a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-14" />
  <path d="M9 15v2" />
  <path d="M12 11v6" />
  <path d="M15 13v4" />
</svg>`,"align-box-center-middle":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M3 19v-14a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2" />
  <path d="M11 15h2" />
  <path d="M9 12h6" />
  <path d="M10 9h4" />
</svg>`,"columns-3":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M3 4a1 1 0 0 1 1 -1h16a1 1 0 0 1 1 1v16a1 1 0 0 1 -1 1h-16a1 1 0 0 1 -1 -1v-16" />
  <path d="M9 3v18" />
  <path d="M15 3v18" />
</svg>`,"align-box-top-center":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M3 5a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-14" />
  <path d="M9 9v-2" />
  <path d="M12 13v-6" />
  <path d="M15 11v-4" />
</svg>`,"layout-distribute-vertical":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 4l0 16" />
  <path d="M20 4l0 16" />
  <path d="M9 8a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-2a2 2 0 0 1 -2 -2l0 -8" />
</svg>`,"spacing-vertical":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 20v-2a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v2" />
  <path d="M4 4v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2 -2v-2" />
  <path d="M16 12h-8" />
</svg>`,"text-wrap":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M4 6l16 0" />
  <path d="M4 18l5 0" />
  <path d="M4 12h13a3 3 0 0 1 0 6h-4l2 -2m0 4l-2 -2" />
</svg>`,"align-box-left-middle":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
><!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M3 5a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v14a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-14" />
  <path d="M9 15h-2" />
  <path d="M13 12h-6" />
  <path d="M11 9h-4" />
</svg>`,lock:`<!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 13a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2v-6" />
  <path d="M11 16a1 1 0 1 0 2 0a1 1 0 0 0 -2 0" />
  <path d="M8 11v-4a4 4 0 1 1 8 0v4" />
</svg>
`,"lock-open":`<!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 13a2 2 0 0 1 2 -2h10a2 2 0 0 1 2 2v6a2 2 0 0 1 -2 2h-10a2 2 0 0 1 -2 -2l0 -6" />
  <path d="M11 16a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
  <path d="M8 11v-5a4 4 0 0 1 8 0" />
</svg>
`,circle:`<!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0" />
</svg>
`,minus:`<!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12l14 0" />
</svg>
`,"baby-bottle":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round">
<!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M5 10h14" />
  <path d="M12 2v2" />
  <path d="M12 4a5 5 0 0 1 5 5v11a2 2 0 0 1 -2 2h-6a2 2 0 0 1 -2 -2v-11a5 5 0 0 1 5 -5" />
</svg>`,"first-aid-kit":`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round">
<!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M8 8v-2a2 2 0 0 1 2 -2h4a2 2 0 0 1 2 2v2" />
  <path d="M4 10a2 2 0 0 1 2 -2h12a2 2 0 0 1 2 2v8a2 2 0 0 1 -2 2h-12a2 2 0 0 1 -2 -2l0 -8" />
  <path d="M10 14h4" />
  <path d="M12 12v4" />
</svg>`,microscope:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round">
<!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M5 21h14" />
  <path d="M6 18h2" />
  <path d="M7 18v3" />
  <path d="M9 11l3 3l6 -6l-3 -3l-6 6" />
  <path d="M10.5 12.5l-1.5 1.5" />
  <path d="M17 3l3 3" />
  <path d="M12 21a6 6 0 0 0 3.715 -10.712" />
</svg>`,stethoscope:`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round">
<!-- MIT License

Copyright (c) 2020-2026 Paweł Kuna

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
 -->
  <path d="M6 4h-1a2 2 0 0 0 -2 2v3.5a5.5 5.5 0 0 0 11 0v-3.5a2 2 0 0 0 -2 -2h-1" />
  <path d="M8 15a6 6 0 1 0 12 0v-3" />
  <path d="M11 3v2" />
  <path d="M6 3v2" />
  <path d="M18 10a2 2 0 1 0 4 0a2 2 0 1 0 -4 0" />
</svg>`},g=`<!--
tags: [play, start, run, media, video, audio, music, resume, triangle, controls, button, player]
category: Media
version: "1.28"
unicode: "ed46"
-->
<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M7 4v16l13 -8l-13 -8" />
</svg>
`,_=`<!--
tags: [chat, comment, speech-bubble, conversation, sms, text-message, reply, communication, dm, messaging, feedback, inbox, message]
category: Communication
version: "1.0"
unicode: "eaef"
-->
<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M8 9h8" />
  <path d="M8 13h6" />
  <path d="M18 4a3 3 0 0 1 3 3v8a3 3 0 0 1 -3 3h-5l-5 3v-3h-2a3 3 0 0 1 -3 -3v-8a3 3 0 0 1 3 -3h12" />
</svg>
`,v=`<!--
tags: [list, bullet-list, unordered-list, bullets, items, menu, text-editor]
category: Text
version: "1.2"
unicode: "eb6b"
-->
<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9 6l11 0" />
  <path d="M9 12l11 0" />
  <path d="M9 18l11 0" />
  <path d="M5 6l0 .01" />
  <path d="M5 12l0 .01" />
  <path d="M5 18l0 .01" />
</svg>
`,y=`<!--
tags: [bezier, curve, vector, path, pen-tool, anchor, handles, design]
category: Design
version: "1.27"
unicode: "ef1d"
-->
<svg
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 15a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1l0 -2" />
  <path d="M17 15a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1l0 -2" />
  <path d="M10 7a1 1 0 0 1 1 -1h2a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-2a1 1 0 0 1 -1 -1l0 -2" />
  <path d="M10 8.5a6 6 0 0 0 -5 5.5" />
  <path d="M14 8.5a6 6 0 0 1 5 5.5" />
  <path d="M10 8l-6 0" />
  <path d="M20 8l-6 0" />
  <path d="M2 8a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
  <path d="M20 8a1 1 0 1 0 2 0a1 1 0 1 0 -2 0" />
</svg>
`;function b(e){let t=/<svg\b[^>]*>/i.exec(e);if(!t||/\bclass\s*=/.test(t[0]))return e;let n=t[0].replace(/^<svg\b/i,`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"`);return`${e.slice(0,t.index)}${n}${e.slice(t.index+t[0].length)}`}var x=Object.fromEntries(Object.entries({playerPlay:g,message:_,list:v,vectorBezier:y}).map(([e,t])=>[e.replace(/[A-Z]/g,e=>`-${e.toLowerCase()}`),t.slice(t.indexOf(`<svg`)).replace(`<svg`,`<svg class="tabler-editor-icon" aria-hidden="true" focusable="false"`)])),S=e=>b(h[e]||x[e]||h.square),C=Object.fromEntries(Object.entries({close:`x`,move:`arrows-move`,plus:`plus`,caret:`chevron-down`,delete:`trash`,copy:`copy`,arrowUp:`arrow-up`,chevron:`chevron-up`,eye:`eye`,eyeOff:`eye-off`}).map(([e,t])=>[e,S(t)]));function w(e){let t=document.body,n=(e,n,r=!1)=>{for(let i of t.querySelectorAll(e)){if(i.querySelector(`.tabler-editor-icon`))continue;let e=i.getAttribute(`aria-label`)||i.title||i.textContent.trim();r?(i.setAttribute(`aria-label`,e),i.title||=e,i.innerHTML=S(n)):i.insertAdjacentHTML(`afterbegin`,S(n))}},r=()=>{for(let t of e.RichTextEditor.getAll()){let e={bold:`bold`,italic:`italic`,underline:`underline`,strikethrough:`strikethrough`,link:`link`,wrap:`typography`}[t.name];e&&(t.icon=S(e),t.btn&&!t.btn.querySelector(`.tabler-editor-icon`)&&(t.btn.innerHTML=t.icon))}n(`.gjs-frame-wrapper__icon,.frame-wrapper__icon`,`layout-grid`,!0),n(`#theme`,`settings`,!0);for(let[e,t]of Object.entries({"#history":`history`,"#export":`code`,"#static-export":`download`,"#save":`device-floppy`,"#add-page":`plus`,"#undo":`arrow-back-up`,"#redo":`arrow-forward-up`,"#close-inspector":`x`,".dialog-close":`x`,'button[id^="close-"]:not(#close-preview)':`x`,"[data-close-panel]":`x`,"#toggle-layers":`stack-2`,"#toggle-library":`plus`,"#component-actions-trigger":`dots`,".block-card b":`plus`}))n(e,t,!0);for(let[e,t]of Object.entries({"#preview":`eye`,"#start-hero":`plus`,'[data-device="Desktop"]':`device-desktop`,'[data-device="Tablet"]':`device-tablet`,'[data-device="Mobile"]':`device-mobile`}))n(e,t);for(let e of t.querySelectorAll(`.fa`))for(let[t,n]of Object.entries({"fa-arrows":`arrows-move`,"fa-trash-o":`trash`,"fa-trash":`trash`,"fa-clone":`copy`,"fa-arrow-up":`arrow-up`,"fa-chevron-right":`chevron-right`,"fa-chevron-down":`chevron-down`,"fa-eye":`eye`,"fa-eye-slash":`eye-off`,"fa-cog":`settings`,"fa-bars":`menu`,"fa-plus":`plus`,"fa-minus":`chevron-up`}))e.classList.contains(t)&&!e.querySelector(`.tabler-editor-icon`)&&(e.classList.add(`tabler-replaced`),e.innerHTML=S(n))};T(document,{});let i=t.querySelector(`#preview`);i&&(i.textContent=i.textContent.replace(`↗`,``).trim());let a=t.querySelector(`#start-hero`);a&&(a.textContent=a.textContent.replace(/^\+\s*/,``)),r();let o=new MutationObserver(r);o.observe(t,{childList:!0,subtree:!0}),e.on(`destroy`,()=>o.disconnect())}function T(e,t){let n=t[`flex-direction`]||`row`,r=t[`flex-wrap`]||`nowrap`;for(let t of e.querySelectorAll(`[data-flex-property]`)){let e=m(t.dataset.flexProperty,t.dataset.flexValue,n,r);if(!e)continue;let i=e.name+`:`+(e.transform||``);if(t.dataset.iconSpec===i)continue;t.innerHTML=S(e.name),t.dataset.iconSpec=i;let a=t.querySelector(`svg`);a&&e.transform&&(a.style.transform=e.transform)}}var E=(e,t,n)=>Math.max(t,Math.min(n,e)),D=/^#[a-f\d]{6}$/i,ee=`juzimder-saved-colors`,te=`juzimder-zero-saved-colors`;function O(e){if(!D.test(e))return{h:0,s:0,v:1};let[t,n,r]=[1,3,5].map(t=>Number.parseInt(e.slice(t,t+2),16)/255),i=Math.max(t,n,r),a=i-Math.min(t,n,r),o=0;return a&&(o=i===t?(n-r)/a%6:i===n?(r-t)/a+2:(t-n)/a+4,o=(o*60+360)%360),{h:o,s:i?a/i:0,v:i}}function ne(e,t,n){let r=(Number(e)%360+360)%360,i=E(Number(t),0,1),a=E(Number(n),0,1),o=a*i,s=o*(1-Math.abs(r/60%2-1)),c=a-o;return`#${(r<60?[o,s,0]:r<120?[s,o,0]:r<180?[0,o,s]:r<240?[0,s,o]:r<300?[s,0,o]:[o,0,s]).map(e=>Math.round((e+c)*255).toString(16).padStart(2,`0`)).join(``)}`}function re(e,t=globalThis.document){let n=String(e||``).trim();if(/^var\(/i.test(n))return{color:`#ffffff`,opacity:1,valid:!1};if(n.toLowerCase()===`transparent`)return{color:`#ffffff`,opacity:0,valid:!0};let r=n.match(/^#([a-f\d]{3,8})$/i)?.[1];if(r){if(r.length===3||r.length===4)return{color:`#${[0,1,2].map(e=>r[e].repeat(2)).join(``)}`,opacity:r.length===4?Number.parseInt(r[3].repeat(2),16)/255:1,valid:!0};if(r.length===6||r.length===8)return{color:`#${r.slice(0,6)}`.toLowerCase(),opacity:r.length===8?Number.parseInt(r.slice(6),16)/255:1,valid:!0}}let i=n.match(/^rgba?\(\s*([\d.]+%?)\s*,\s*([\d.]+%?)\s*,\s*([\d.]+%?)(?:\s*,\s*([\d.]+%?))?\s*\)$/i);if(i){let e=i.slice(1,4).map(e=>Math.round(e.endsWith(`%`)?Number.parseFloat(e)*2.55:Number(e)));if(e.every(e=>Number.isFinite(e)&&e>=0&&e<=255)){let t=`#${e.map(e=>e.toString(16).padStart(2,`0`)).join(``)}`,n=i[4],r=n?E(n.endsWith(`%`)?Number.parseFloat(n)/100:Number(n),0,1):1;return{color:t,opacity:r,valid:Number.isFinite(r)}}}if(n&&t?.createElement){let e=t.createElement(`canvas`).getContext(`2d`);if(e){e.fillStyle=`#ffffff`,e.fillStyle=n;let t=e.fillStyle;if(t!==n)return re(t,null)}}return{color:`#ffffff`,opacity:1,valid:!1}}function ie(e,t=1){if(!D.test(e))return`#ffffff`;let n=E(Number(t),0,1);if(n>=.999)return e.toLowerCase();let[r,i,a]=[1,3,5].map(t=>Number.parseInt(e.slice(t,t+2),16));return`rgba(${r}, ${i}, ${a}, ${Math.round(n*1e3)/1e3})`}var k=new Set([`linear`,`radial`,`conic`,`multicolor`]),ae=(e,t,n,r)=>Number.isFinite(Number(e))?E(Number(e),t,n):r;function oe(e){if(!e||!k.has(e.type)||!Array.isArray(e.stops))return null;let t=e.type===`multicolor`?3:2;if(e.stops.length<t||e.stops.length>6)return null;let n=e.stops.map(e=>({color:typeof e?.color==`string`&&D.test(e.color)?e.color.toLowerCase():null,opacity:ae(e?.opacity,0,1,NaN),position:ae(e?.position,0,100,NaN)}));return n.some(e=>!e.color||!Number.isFinite(e.opacity)||!Number.isFinite(e.position))?null:(n.sort((e,t)=>e.position-t.position),{type:e.type,angle:ae(e.angle,0,360,90),stops:n})}function se(e){let t=oe(e);if(!t)return``;let n=t.stops.map(({color:e,opacity:t,position:n})=>`${ie(e,t).replaceAll(`, `,`,`)} ${Math.round(n*100)/100}%`).join(`,`);return t.type===`radial`?`radial-gradient(circle,${n})`:t.type===`conic`?`conic-gradient(from ${t.angle}deg,${n})`:`linear-gradient(${t.type===`multicolor`?90:t.angle}deg,${n})`}function ce(){try{return globalThis.localStorage}catch{return null}}function le(e,t){try{let n=JSON.parse(e?.getItem(t)||`[]`);return Array.isArray(n)?[...new Set(n.filter(e=>typeof e==`string`&&D.test(e)).map(e=>e.toLowerCase()))].slice(0,12):[]}catch{return[]}}function ue(e=ce()){let t=le(e,ee);return t.length?t:le(e,te)}function de(e,t=ce()){if(!D.test(e)||!t)return ue(t);let n=ue(t),r=e.toLowerCase();try{t.setItem(ee,JSON.stringify([r,...n.filter(e=>e!==r)].slice(0,12)))}catch{}return ue(t)}function fe(e,t=ce()){if(!D.test(e)||!t)return ue(t);let n=ue(t).filter(t=>t!==e.toLowerCase());try{t.setItem(ee,JSON.stringify(n)),t.setItem(te,JSON.stringify(n))}catch{}return ue(t)}function pe(e=globalThis.document?.body){let t=e?.ownerDocument||globalThis.document;if(!e||!t)return{open(){}};let n=t.createElement(`dialog`);n.className=`jz-color-dialog`,n.setAttribute(`aria-label`,`Выбор цвета`),n.innerHTML=`<header class="jz-color-header"><span data-color-title>Цвет</span><button type="button" data-color-close aria-label="Закрыть палитру">×</button></header>
    <div class="jz-color-fill-controls" data-color-fill-controls hidden><label>Тип заливки<select data-color-fill-type aria-label="Тип заливки"><option value="solid">Solid</option><option value="linear">Линейный градиент</option><option value="radial">Радиальный градиент</option><option value="conic">Конический градиент</option><option value="multicolor">Multicolor</option></select></label><div class="jz-color-gradient-settings" data-color-gradient-settings hidden><label class="jz-color-angle-row" data-color-angle-row>Угол<input type="range" min="0" max="360" step="1" data-color-angle aria-label="Угол градиента"><output data-color-angle-value>90°</output></label><div class="jz-color-gradient-preview" data-color-gradient-preview aria-label="Предпросмотр градиента"></div><div class="jz-color-stops" data-color-stops></div><button type="button" class="jz-color-add-stop" data-color-add-stop>+ Добавить цвет</button></div></div>
    <div class="jz-color-plane" role="group" aria-label="Выбор насыщенности и яркости" tabindex="0"><span class="jz-color-plane-marker" aria-hidden="true"></span></div>
    <label class="jz-color-hue"><span>Тон</span><input type="range" min="0" max="359" step="1" data-color-hue aria-label="Тон цвета"></label>
    <label class="jz-color-alpha" data-color-alpha-row><span>Прозрачность</span><input type="range" min="0" max="100" step="1" data-color-alpha aria-label="Прозрачность цвета"></label>
    <div class="jz-color-hex-row"><label><span>HEX</span><input type="text" data-color-hex maxlength="7" spellcheck="false" aria-label="HEX цвета"></label><output data-color-alpha-value>100%</output><button type="button" data-color-clear aria-label="Сделать цвет прозрачным" title="Сделать цвет прозрачным">×</button></div>
    <section class="jz-saved-colors"><header><span>Сохранённые цвета</span><button type="button" data-color-save aria-label="Сохранить текущий цвет" title="Сохранить текущий цвет">+</button></header><div data-color-swatches></div></section>`,e.append(n);let r=t.createElement(`div`);r.className=`jz-color-context-menu`,r.setAttribute(`role`,`menu`),r.hidden=!0;let i=t.createElement(`button`);i.type=`button`,i.className=`jz-color-delete-action`,i.setAttribute(`role`,`menuitem`),r.append(i),n.append(r);let a=e=>n.querySelector(e),o=a(`.jz-color-plane`),s=a(`.jz-color-plane-marker`),c=a(`[data-color-hue]`),l=a(`[data-color-alpha]`),u=a(`[data-color-alpha-row]`),d=a(`[data-color-alpha-value]`),f=a(`[data-color-hex]`),p=a(`[data-color-swatches]`),m=a(`[data-color-title]`),h=a(`[data-color-clear]`),g=a(`[data-color-fill-controls]`),_=a(`[data-color-fill-type]`),v=a(`[data-color-gradient-settings]`),y=a(`[data-color-angle]`),b=a(`[data-color-angle-value]`),x=a(`[data-color-gradient-preview]`),S=a(`[data-color-stops]`),C=a(`[data-color-add-stop]`),w={h:0,s:0,v:1,a:1},T=null,ee=null,te=null,k=null,ae=0;function ce(){r.hidden=!0,te=null}function le(e,n,a){te=e,i.textContent=`Удалить цвет ${e.toUpperCase()}`,r.hidden=!1,r.style.left=`0px`,r.style.top=`0px`;let o=r.getBoundingClientRect(),s=t.defaultView;r.style.left=`${E(n,8,Math.max(8,s.innerWidth-o.width-8))}px`,r.style.top=`${E(a,8,Math.max(8,s.innerHeight-o.height-8))}px`,i.focus()}function pe(){return ne(w.h,w.s,w.v)}function me(e,t){return`#${[1,3,5].map(n=>Math.round((Number.parseInt(e.slice(n,n+2),16)+Number.parseInt(t.slice(n,n+2),16))/2).toString(16).padStart(2,`0`)).join(``)}`}function he(e){let t={color:pe(),opacity:w.a,position:0},n={color:pe().toLowerCase()===`#ffffff`?`#222629`:`#ffffff`,opacity:1,position:100};return e===`multicolor`?{type:e,angle:90,stops:[t,{color:me(t.color,n.color),opacity:1,position:50},n]}:{type:e,angle:90,stops:[t,n]}}function ge(){if(S.replaceChildren(),!k)return;let e=k.type===`multicolor`?3:2;k.stops.forEach((n,r)=>{let i=t.createElement(`div`),a=t.createElement(`button`),o=t.createElement(`input`),s=t.createElement(`output`),c=t.createElement(`button`);i.className=`jz-color-stop`,a.type=`button`,a.className=`jz-color-stop-swatch`,a.style.backgroundColor=ie(n.color,n.opacity),a.setAttribute(`aria-label`,`Редактировать цвет ${r+1}`),a.setAttribute(`aria-pressed`,String(r===ae)),a.addEventListener(`click`,()=>{ae=r,w={...O(n.color),a:n.opacity},ve()}),o.type=`range`,o.min=r?String(k.stops[r-1].position):`0`,o.max=r<k.stops.length-1?String(k.stops[r+1].position):`100`,o.step=`1`,o.value=String(n.position),o.setAttribute(`aria-label`,`Позиция цвета ${r+1}`),s.textContent=`${Math.round(n.position)}%`,o.addEventListener(`input`,()=>{n.position=Number(o.value),s.textContent=`${o.value}%`,o.min=r?String(k.stops[r-1].position):`0`,o.max=r<k.stops.length-1?String(k.stops[r+1].position):`100`,ve()}),o.addEventListener(`change`,()=>A(!0)),c.type=`button`,c.textContent=`×`,c.className=`jz-color-stop-remove`,c.disabled=k.stops.length<=e,c.setAttribute(`aria-label`,`Удалить цвет ${r+1}`),c.addEventListener(`click`,()=>{k.stops.splice(r,1),ae=Math.min(ae,k.stops.length-1);let e=k.stops[ae];w={...O(e.color),a:e.opacity},ge(),ve(),A(!0)}),i.append(a,o,s,c),S.append(i)}),C.disabled=k.stops.length>=6}function _e(){_.value=k?.type||`solid`,v.hidden=!k;let e=k?.type===`linear`||k?.type===`conic`;a(`[data-color-angle-row]`).hidden=!e,k?(y.value=String(Math.round(k.angle)),b.value=`${Math.round(k.angle)}°`,b.textContent=b.value,x.style.backgroundImage=se(k),[...S.querySelectorAll(`.jz-color-stop`)].forEach((e,t)=>{let n=k.stops[t],r=e.querySelector(`.jz-color-stop-swatch`),i=e.querySelector(`input[type="range"]`),a=e.querySelector(`output`);n&&r&&i&&(r.style.backgroundColor=ie(n.color,n.opacity),r.setAttribute(`aria-pressed`,String(t===ae)),i.value=String(n.position),i.min=t?String(k.stops[t-1].position):`0`,i.max=t<k.stops.length-1?String(k.stops[t+1].position):`100`,a.textContent=`${Math.round(n.position)}%`)})):x.style.backgroundImage=`none`}function ve(){let e=pe();o.style.setProperty(`--jz-color-hue`,String(w.h)),s.style.left=`${w.s*100}%`,s.style.top=`${(1-w.v)*100}%`,c.value=String(Math.round(w.h)),l.value=String(Math.round(w.a*100)),l.style.setProperty(`--jz-color-alpha`,e),f.value=e.toUpperCase(),d.value=`${Math.round(w.a*100)}%`,d.textContent=d.value,k&&(k.stops[ae]={...k.stops[ae],color:e,opacity:w.a}),_e()}function A(e=!1){ve(),ee?.onChange?.({color:pe(),opacity:w.a,fill:oe(k)},e)}function ye(){p.replaceChildren();for(let e of ue()){let n=t.createElement(`button`);n.type=`button`,n.className=`jz-color-swatch`,n.style.backgroundColor=e,n.title=e.toUpperCase(),n.setAttribute(`aria-label`,`Выбрать цвет ${e.toUpperCase()}`),n.setAttribute(`aria-haspopup`,`menu`),n.setAttribute(`aria-keyshortcuts`,`Shift+F10 ContextMenu`),n.addEventListener(`click`,()=>{w={...O(e),a:w.a},A(!0)}),n.addEventListener(`contextmenu`,t=>{t.preventDefault(),le(e,t.clientX,t.clientY)}),n.addEventListener(`keydown`,t=>{if(t.key!==`ContextMenu`&&!(t.key===`F10`&&t.shiftKey))return;t.preventDefault();let r=n.getBoundingClientRect();le(e,r.left,r.bottom)}),p.append(n)}if(!p.childElementCount){let e=t.createElement(`span`);e.className=`jz-color-empty`,e.textContent=`Нажмите +, чтобы сохранить цвет`,p.append(e)}}function be(e,t,n=!1){let r=o.getBoundingClientRect();w.s=E((e-r.left)/r.width,0,1),w.v=1-E((t-r.top)/r.height,0,1),A(n)}if(_.addEventListener(`change`,()=>{let e=_.value;if(e===`solid`)k=null;else{if(k=k?{...k,type:e}:he(e),e===`multicolor`&&k.stops.length<3){let e=k.stops[0],t=k.stops.at(-1);k.stops.splice(1,0,{color:me(e.color,t.color),opacity:(e.opacity+t.opacity)/2,position:(e.position+t.position)/2})}ae=Math.min(ae,k.stops.length-1);let t=k.stops[ae];w={...O(t.color),a:t.opacity}}ge(),ve(),A(!0)}),y.addEventListener(`input`,()=>{k&&(k.angle=Number(y.value),b.value=`${y.value}°`,b.textContent=b.value,_e(),A())}),y.addEventListener(`change`,()=>A(!0)),C.addEventListener(`click`,()=>{if(!k||k.stops.length>=6)return;let e=k.stops.map(e=>({...e})).sort((e,t)=>e.position-t.position),t=e[0],n=e[1];for(let r=1;r<e.length-1;r++)e[r+1].position-e[r].position>n.position-t.position&&(t=e[r],n=e[r+1]);let r={color:me(t.color,n.color),opacity:(t.opacity+n.opacity)/2,position:(t.position+n.position)/2};k.stops.push(r),k.stops.sort((e,t)=>e.position-t.position),ae=k.stops.indexOf(r),w={...O(r.color),a:r.opacity},ge(),ve(),A(!0)}),a(`[data-color-close]`).addEventListener(`click`,()=>n.close()),o.addEventListener(`pointerdown`,e=>{e.button===0&&(e.preventDefault(),T=e.pointerId,o.setPointerCapture(T),be(e.clientX,e.clientY))}),o.addEventListener(`pointermove`,e=>{e.pointerId===T&&be(e.clientX,e.clientY)}),o.addEventListener(`pointerup`,e=>{e.pointerId===T&&(be(e.clientX,e.clientY,!0),T=null)}),o.addEventListener(`pointercancel`,()=>{T=null}),o.addEventListener(`keydown`,e=>{let t=e.shiftKey?.1:.01;[`ArrowLeft`,`ArrowRight`,`ArrowUp`,`ArrowDown`].includes(e.key)&&(e.preventDefault(),e.key===`ArrowLeft`&&(w.s-=t),e.key===`ArrowRight`&&(w.s+=t),e.key===`ArrowDown`&&(w.v-=t),e.key===`ArrowUp`&&(w.v+=t),w.s=E(w.s,0,1),w.v=E(w.v,0,1),A(!0))}),c.addEventListener(`input`,()=>{w.h=Number(c.value),A()}),c.addEventListener(`change`,()=>{w.h=Number(c.value),A(!0)}),l.addEventListener(`input`,()=>{w.a=Number(l.value)/100,A()}),l.addEventListener(`change`,()=>{w.a=Number(l.value)/100,A(!0)}),f.addEventListener(`input`,()=>{D.test(f.value)&&(w={...O(f.value),a:w.a},A())}),f.addEventListener(`change`,()=>{D.test(f.value)&&(w={...O(f.value),a:w.a}),A(!0)}),h.addEventListener(`click`,()=>{(ee?.allowOpacity||ee?.allowFill)&&(w.a=0,A(!0))}),a(`[data-color-save]`).addEventListener(`click`,()=>{de(pe()),ye()}),i.addEventListener(`click`,()=>{te&&fe(te),ce(),ye(),a(`[data-color-save]`).focus()}),`EyeDropper`in globalThis){let e=t.createElement(`button`);e.type=`button`,e.className=`jz-color-eyedropper`,e.textContent=`Пипетка`,e.addEventListener(`click`,async()=>{let e=t.documentElement;e.classList.add(`jz-eyedropper-active`);try{let e=await new globalThis.EyeDropper().open();D.test(e.sRGBHex)&&(w={...O(e.sRGBHex),a:w.a}),A(!0)}catch{}finally{e.classList.remove(`jz-eyedropper-active`)}}),a(`.jz-color-header`).append(e)}return n.addEventListener(`click`,e=>{e.target===n&&n.close()}),t.addEventListener(`pointerdown`,e=>{!r.hidden&&!r.contains(e.target)&&ce(),n.open&&!n.contains(e.target)&&!r.contains(e.target)&&!ee?.trigger?.contains(e.target)&&n.close()}),n.addEventListener(`close`,()=>{n.open||(ee=null,ce())}),ye(),{dialog:n,open({trigger:e,color:r,opacity:i=1,fill:a=null,allowOpacity:o=!1,allowFill:s=!1,label:c=`Цвет`,onChange:p}){let _=re(r,t);k=s?oe(a):null,ae=0;let v=k?.stops[0]?.color||_.color,y=k?.stops[0]?.opacity??(o?E(Number(i??_.opacity),0,1):1);if(w={...O(v),a:y},ee={trigger:e,allowOpacity:o,allowFill:s,onChange:p},m.textContent=c,n.setAttribute(`aria-label`,c),g.hidden=!s,u.hidden=!(o||s&&k),l.hidden=u.hidden,d.hidden=u.hidden,h.hidden=u.hidden,ye(),ge(),ve(),n.open&&!n.matches(`:modal`)&&n.close(),n.open||n.showModal(),e){let t=e.getBoundingClientRect(),r=n.getBoundingClientRect();n.style.left=`${E(t.right-r.width,12,Math.max(12,globalThis.innerWidth-r.width-12))}px`,n.style.top=`${E(t.bottom+8,12,Math.max(12,globalThis.innerHeight-r.height-12))}px`}f.focus(),f.select()}}}var me;function he(e=globalThis.document?.body){return me||=pe(e),me}function ge(e){let t=e.nextElementSibling;if(!t?.classList.contains(`jz-color-field-trigger`))return;let n=re(e.dataset.colorValue||e.value,e.ownerDocument),r=t.querySelector(`.jz-color-chip`),i=t.querySelector(`.jz-color-value`),a=e.dataset.colorValue||e.value,o=n.valid?n.color.toUpperCase():String(a||`Цвет`).toUpperCase();r.style.backgroundColor=n.valid?ie(n.color,n.opacity):`transparent`,i.textContent=o;let s=e.dataset.colorLabel||e.getAttribute(`aria-label`)||e.closest(`label`)?.textContent?.trim()||`Цвет`;t.setAttribute(`aria-label`,`${s}: ${o}. Открыть палитру`),t.title=`${s}: ${o}`}function _e(e,t=e?.dataset.colorValue||e?.value){if(!e)return;let n=re(t,e.ownerDocument);n.valid&&(e.value=n.color),e.dataset.colorValue=n.valid?ie(n.color,n.opacity):String(t||e.value),e.dataset.colorOpacity=String(n.opacity),ge(e)}function ve(e=globalThis.document){e?.querySelectorAll?.(`input[type="color"]`).forEach(e=>_e(e))}function A(e=globalThis.document?.body){if(!e)return{destroy(){}};let t=e.ownerDocument||globalThis.document,n=he(t.body),r=e=>{if(!e.matches?.(`input[type="color"]`)||e.dataset.jzColorEnhanced)return;e.dataset.jzColorEnhanced=`true`,e.classList.add(`jz-color-native-input`),e.tabIndex=-1,e.setAttribute(`aria-hidden`,`true`);let r=e.getAttribute(`aria-label`)||e.closest(`label`)?.textContent?.trim()||e.name||`Цвет`;e.dataset.colorLabel=r;let i=t.createElement(`button`),a=t.createElement(`span`),o=t.createElement(`span`);i.type=`button`,i.className=`jz-color-field-trigger`,i.setAttribute(`aria-haspopup`,`dialog`),a.className=`jz-color-chip`,a.setAttribute(`aria-hidden`,`true`),o.className=`jz-color-value`,i.append(a,o),e.insertAdjacentElement(`afterend`,i);let s=()=>ge(e);e.addEventListener(`input`,s),e.addEventListener(`change`,s),i.addEventListener(`click`,a=>{a.preventDefault(),a.stopPropagation();let o=re(e.dataset.colorValue||e.value,t),c=e.dataset.colorAlpha===`true`,l=null;try{l=JSON.parse(e.dataset.colorFillValue||`null`)}catch{l=null}let u=e.dataset.colorFill===`true`;n.open({trigger:i,color:o.color,opacity:c?e.dataset.colorOpacity??o.opacity:1,fill:l,allowOpacity:c,allowFill:u,label:e.dataset.colorLabel||r,onChange:({color:n,opacity:r,fill:i},a)=>{e.value=n,e.dataset.colorOpacity=String(r),e.dataset.colorValue=c?ie(n,r):n,u&&(e.dataset.colorFillValue=i?JSON.stringify(i):``),s();let o=t.defaultView.Event;e.dispatchEvent(new o(`input`,{bubbles:!0})),a&&e.dispatchEvent(new o(`change`,{bubbles:!0}))}})}),_e(e)},i=e=>{e.nodeType===1&&r(e),e.querySelectorAll?.(`input[type="color"]`).forEach(r)};i(e);let a=t.defaultView?.MutationObserver||globalThis.MutationObserver,o=a?new a(e=>e.forEach(e=>e.addedNodes.forEach(i))):null;return o?.observe(e,{childList:!0,subtree:!0}),{picker:n,destroy:()=>o?.disconnect()}}var ye=Object.freeze({desktop:1200,laptop:980,tablet:640,landscape:480,mobile:360});Object.freeze({elements:300,depth:8});var be=e=>structuredClone(e),xe=()=>`ze-${crypto.randomUUID()}`,Se=/^(?:desktop|laptop|tablet|landscape|mobile|bp-[a-f0-9-]{8,36})$/;function Ce(e,t=`desc`){let n=Object.entries(e.artboards).sort(([,e],[,t])=>t.width-e.width);return t===`asc`?n.reverse():n}function we(e,t){let n=Ce(e),r=n.findIndex(([e])=>e===t);return r<=0?null:n[r-1][1].width-1}function Te(e,t){let n=Ce(e),r=Number(t);if(!Number.isFinite(r)||!n.length)return n[0]?.[0]||`desktop`;if(r>=n[0][1].width)return n[0][0];let i=n.findIndex(([,e],t)=>t>0&&r>=e.width&&r<n[t-1][1].width);return i>0?n[i][0]:n.at(-1)[0]}function Ee(e,t){return{desktop:1200,laptop:980,tablet:640,landscape:480,mobile:360}[e]===t?{desktop:`Desktop`,laptop:`Laptop`,tablet:`Tablet`,landscape:`Mobile landscape`,mobile:`Mobile`}[e]:`Custom breakpoint`}function De(e){let t=Ce(e),n=new Set,r=new Set;if(t.length<1||t.length>10||!e.artboards.desktop||t[0][0]!==`desktop`)throw Error(`Нужен один широчайший базовый брейкпоинт и не более 10 режимов.`);for(let[e,i]of t){if(!Se.test(e))throw Error(`Не удалось распознать ID брейкпоинта.`);if(!Number.isInteger(i.width)||i.width<320||i.width>2400||n.has(e)||r.has(i.width))throw Error(`Ширины брейкпоинтов должны быть уникальными от 320 до 2400 px.`);n.add(e),r.add(i.width)}return t}function Oe(e,t){for(let n of e)t(n),n.children&&Oe(n.children,t)}function ke(e,t){let n=Ie(e,t),r={geometry:be(n.geometry),style:be(n.style),visible:n.visible};return e.type===`image`&&n.src!==void 0&&(r.src=n.src),r}function Ae(e){let t=new Set(Ce(e).map(([,e])=>e.width));if(!t.has(768))return 768;let n=[2401,...[...t].sort((e,t)=>t-e),319],r=null,i=0;for(let e=0;e<n.length-1;e++){let t=n[e],a=n[e+1],o=t-a-1;o>i&&(i=o,r=Math.floor((t+a)/2))}return r}function je(e,t){if(De(e),Object.keys(e.artboards).length>=10||!Number.isInteger(t)||t<320||t>2400||Object.values(e.artboards).some(e=>e.width===t))throw Error(`Выберите свободную ширину от 320 до 2400 px (не более 10 режимов).`);let n=`bp-${crypto.randomUUID()}`,r=Ce(e),i=r[0];if(t>i[1].width){let r=i[1].width,a=be(e.artboards.desktop);a.width=r,e.artboards.desktop.width=t,e.artboards[n]=a,Oe(e.elements,e=>{e.overrides??={},e.overrides[n]=ke(e,`desktop`)})}else{let i=r.filter(([,e])=>e.width>t).at(-1),a=be(e.artboards[i[0]]);a.width=t,e.artboards[n]=a,Oe(e.elements,e=>{e.overrides??={},e.overrides[n]=ke(e,i[0])})}return n}function Me(e,t){let n=De(e);if(!e.artboards[t])throw Error(`Брейкпоинт уже удалён.`);if(n.length===1)throw Error(`В Zero Block должен оставаться хотя бы один брейкпоинт.`);if(t===`desktop`){let t=n[1][0],r=be(e.artboards[t]);Oe(e.elements,e=>{let n=Ie(e,t);e.geometry=be(n.geometry),e.style=be(n.style),e.visible=n.visible,e.type===`image`&&n.src!==void 0&&(e.src=n.src),delete e.overrides?.[t],delete e.overrides?.desktop,e.overrides&&!Object.keys(e.overrides).length&&delete e.overrides}),delete e.artboards.desktop,delete e.artboards[t],e.artboards.desktop=r}else delete e.artboards[t],Oe(e.elements,e=>{delete e.overrides?.[t]});return e}function Ne(){return{version:1,artboards:Object.fromEntries(Object.entries(ye).map(([e,t])=>[e,{width:t,height:650,background:`#ffffff`,backgroundOpacity:1,backgroundImage:``,backgroundImageName:``,backgroundSize:`cover`,backgroundPosition:`center center`,filterStartColor:`#000000`,filterStartOpacity:0,filterEndColor:`#000000`,filterEndOpacity:0,gridWidth:Math.min(1200,t),gridColumns:12,gridColor:`#86c232`,gridOpacity:.08,gridBorderOpacity:.12,margin:20,gutter:20,overflow:`hidden`,scaleGrid:`fixed`,guides:[]}])),elements:[]}}function Pe(e){let t=Math.max(1,Math.min(24,Math.trunc(Number(e.gridColumns)||12))),n=Math.min(e.width,e.gridWidth),r=Math.max(0,Number(e.margin)||0),i=Math.max(0,Number(e.gutter)||0),a=Math.max(0,n-2*r),o=Math.max(0,(a-(t-1)*i)/t);return{columns:t,containerWidth:n,contentWidth:a,margin:r,gutter:i,columnWidth:o,step:Math.max(1,o+i)}}function Fe(e,t={}){let n={text:[420,110],image:[360,240],button:[220,54],tooltip:[36,36],vector:[64,64],video:[560,315],form:[360,330],gallery:[720,420],html:[420,260],group:[400,300],rectangle:[240,180],ellipse:[180,180],line:[280,2]},[r,i]=n[e]||n.rectangle;return{id:xe(),type:e,name:{text:`Текст`,image:`Фото`,button:`Кнопка`,tooltip:`Подсказка`,vector:`Вектор`,video:`Видео`,form:`Форма`,gallery:`Галерея`,html:`HTML`,group:`Группа`,rectangle:`Прямоугольник`,ellipse:`Эллипс`,line:`Линия`}[e],geometry:{container:`grid`,anchorX:0,anchorY:0,originX:0,originY:0,x:80,y:80,width:r,height:i,rotation:0},style:{fill:[`rectangle`,`ellipse`,`line`,`button`].includes(e)?t.forest||`#245b46`:`transparent`,color:e===`button`?`#ffffff`:t.ink||`#183e31`,fontSize:e===`text`?40:16,fontFamily:t.headingFontFamily||`Arial, sans-serif`,...e===`image`?{objectFit:`cover`,objectPosition:`center`}:{},fontWeight:500,lineHeight:1.2,radius:e===`button`||e===`gallery`?12:0,opacity:1,strokeWidth:0,textAlign:`left`},overrides:{},visible:!0,locked:!1,keepAspect:[`image`,`group`,`gallery`].includes(e),...e===`group`?{children:[]}:{content:e===`text`?`Создавайте свободно`:e===`button`?`Подробнее`:e===`tooltip`?`Дополнительная информация`:``},...e===`html`?{code:{html:``,css:``,js:``}}:{},...e===`vector`?{icon:`arrow-right`}:{},...e===`video`?{videoUrl:``}:{},...e===`form`?{submitLabel:`Отправить`,formFields:[{id:`name`,type:`text`,label:`Ваше имя`,placeholder:`Введите имя`,required:!1},{id:`email`,type:`email`,label:`Email`,placeholder:`name@example.com`,required:!0},{id:`message`,type:`textarea`,label:`Сообщение`,placeholder:`Ваш вопрос`,required:!1}]}:{},...e===`gallery`?{galleryOptions:{columns:3,gap:16,objectFit:`cover`},galleryItems:[]}:{}}}function Ie(e,t){let n=e.overrides?.[t]||{};return{...e,...n,geometry:{...e.geometry,...n.geometry},style:{...e.style,...n.style}}}function Le(e,t,n,r,i){let a=t===`desktop`?e:e.overrides[t]??={};n?(a[n]??={},a[n][r]=i):a[r]=i}function Re(e,t){let n,r=(e,i=null)=>{for(let a of e)a.id===t&&(n={element:a,list:e,parent:i}),a.children&&r(a.children,a)};return r(e.elements),n}function ze(e){let t=[],n=(e,r=0)=>{for(let i of e)t.push({element:i,depth:r}),i.children&&n(i.children,r+1)};return n(e.elements),t}function Be(e,t,n=!1){let r=n?t.width:e.container===`grid`?Math.min(t.width,t.gridWidth):t.width;return{x:(n||e.container===`window`?0:(t.width-r)/2)+e.anchorX*r+e.x-e.originX*e.width,y:e.anchorY*t.height+e.y-e.originY*e.height,width:e.width,height:e.height}}function Ve(e,t,n,r=!1){let i={...e,...n},a=Be(e,t,r),o=Be({...i,x:0,y:0},t,r),s=He((i.originX-e.originX)*e.width,(i.originY-e.originY)*e.height,e.rotation);return{...i,x:a.x+e.originX*e.width+s.x-o.x-i.originX*i.width,y:a.y+e.originY*e.height+s.y-o.y-i.originY*i.height}}var He=(e,t,n)=>{let r=n*Math.PI/180;return{x:e*Math.cos(r)-t*Math.sin(r),y:e*Math.sin(r)+t*Math.cos(r)}};function Ue(e,t,n,r,i=!1){let a=He(t,n,-e.rotation),o=e.width,s=e.height,c=0,l=0;if(r.includes(`e`)&&(o=Math.max(1,e.width+a.x)),r.includes(`s`)&&(s=Math.max(1,e.height+a.y)),r.includes(`w`)&&(o=Math.max(1,e.width-a.x),c=e.width-o),r.includes(`n`)&&(s=Math.max(1,e.height-a.y),l=e.height-s),i){let t;t=/[ew]/.test(r)?/[ns]/.test(r)?Math.abs(o/e.width-1)>Math.abs(s/e.height-1)?o/e.width:s/e.height:o/e.width:s/e.height,o=Math.max(1,e.width*t),s=Math.max(1,e.height*t),c=r.includes(`w`)?e.width-o:r.includes(`e`)?0:(e.width-o)/2,l=r.includes(`n`)?e.height-s:r.includes(`s`)?0:(e.height-s)/2}let u=He(c+e.originX*(o-e.width),l+e.originY*(s-e.height),e.rotation);return{...e,width:o,height:s,x:e.x+u.x,y:e.y+u.y}}function We(e,t,n,r=0){return He(e/n,t/n,-r)}function Ge({zoom:e,nextZoom:t,scrollLeft:n=0,scrollTop:r=0,pointX:i=0,pointY:a=0,documentX:o,documentY:s,planeOffsetX:c=80,planeOffsetY:l=80,stagePaddingRight:u=80,stagePaddingBottom:d=80,viewportWidth:f=0,viewportHeight:p=0,boardWidth:m=0,boardHeight:h=0,contentLeft:g=0,contentTop:_=0,contentRight:v=m,contentBottom:y=h,leadingPadding:b=12,minZoom:x=.25,maxZoom:S=3}){let C=Number.isFinite(e)&&e>0?e:1,w=Math.round(Math.min(S,Math.max(x,Number.isFinite(t)?t:C))*100)/100,T=Number.isFinite(o)?o:(n+i-c)/C,E=Number.isFinite(s)?s:(r+a-l)/C,D=c,ee=l,te=b-g*w,O=b-_*w;D=Math.max(D,te),ee=Math.max(ee,O);let ne=D+T*w-i,re=ee+E*w-a;ne<0&&(D-=ne,ne=0),re<0&&(ee-=re,re=0);let ie=Math.max(80,u),k=Math.max(80,d),ae=Math.max(0,D+Math.max(m,v)*w+ie-f),oe=Math.max(0,ee+Math.max(h,y)*w+k-p);return ne>ae&&(ie+=ne-ae,ae=ne),re>oe&&(k+=re-oe,oe=re),{zoom:w,planeOffsetX:D,planeOffsetY:ee,stagePaddingRight:ie,stagePaddingBottom:k,documentX:T,documentY:E,scrollLeft:Math.min(ae,ne),scrollTop:Math.min(oe,re)}}function Ke(e,t,n=!1){return n?`${Number((e*100/t.gridWidth).toFixed(4))}vw`:`${e}px`}function qe(e,t,n=!1,r=!1){let i=r&&(n||e.container===`grid`),a=e=>Ke(e,t,i),o=e.x,s=`calc(${e.anchorX*100}% + ${a(o)})`;return!n&&e.container===`grid`&&(s=i?e.anchorX===.5?`calc(50% + ${a(o)})`:`calc(50% ${e.anchorX===0?`-`:`+`} 50vw + ${a(o)})`:e.anchorX===.5?`calc(50% + ${a(o)})`:`calc(50% ${e.anchorX===0?`-`:`+`} min(50%, ${t.gridWidth/2}px) + ${a(o)})`),`position:absolute;box-sizing:border-box;left:${s};top:calc(${e.anchorY*100}% + ${a(e.y)});width:${a(e.width)};height:${a(e.height)};transform:translate(${-e.originX*100}%,${-e.originY*100}%) rotate(${e.rotation}deg);transform-origin:${e.originX*100}% ${e.originY*100}%;`}function Je(e,t=null,n=!1){let r={fontSize:`font-size`,fontWeight:`font-weight`,lineHeight:`line-height`,letterSpacing:`letter-spacing`,radius:`border-radius`,opacity:`opacity`,color:`color`,fill:`background-color`,fontFamily:`font-family`,textAlign:`text-align`,textDecoration:`text-decoration`,objectFit:`object-fit`,objectPosition:`object-position`},i=``,a=new Set([`fontSize`,`letterSpacing`,`radius`,`strokeWidth`,`shadowX`,`shadowY`,`shadowBlur`]),o=(e,r)=>n&&t?Ke(r,t,!0):`${String(r).replace(/[;{}<>]/g,``)}px`;for(let[t,n]of Object.entries(r))if(e[t]!==void 0){if(t===`fill`&&e.fill&&typeof e.fill==`object`){let t=se(e.fill);t&&(i+=`background-color:transparent;background-image:${t};`)}else i+=`${n}:${a.has(t)?o(t,e[t]):String(e[t]).replace(/[;{}<>]/g,``)};`}let s=o(`strokeWidth`,e.strokeWidth||0);return i+=`border:${s} solid ${e.stroke||`transparent`};`,e.shadowBlur!==void 0&&(i+=`box-shadow:${o(`shadowX`,e.shadowX||0)} ${o(`shadowY`,e.shadowY||0)} ${o(`shadowBlur`,e.shadowBlur)} ${e.shadowColor||`#000000`};`),e.autoHeight&&(i+=`height:auto;`),i}function Ye(e,t){let n=e.artboards[t];for(let{element:r}of ze(e)){if(r.overrides[t])continue;let e=r.geometry,i=Math.min(1,n.width/1200);r.overrides[t]={geometry:{x:Math.round(e.x*i),y:Math.round(e.y*i),width:Math.max(1,Math.round(e.width*i)),height:Math.max(1,Math.round(e.height*i))},style:{fontSize:Math.max(12,Math.round((r.style.fontSize||16)*i))}}}}var Xe=class{constructor(e){this.items=[be(e)],this.index=0}push(e){JSON.stringify(e)!==JSON.stringify(this.items[this.index])&&(this.items=this.items.slice(0,this.index+1),this.items.push(be(e)),this.items.length>100&&this.items.shift(),this.index=this.items.length-1)}undo(){return this.index>0&&this.index--,be(this.items[this.index])}redo(){return this.index<this.items.length-1&&this.index++,be(this.items[this.index])}};function Ze(e,t){let n=e.getDevice();if(n===`Desktop`)return`desktop`;let r=e.Devices.get(n),i=Number.parseFloat(r?.get?.(`width`));return Number.isFinite(i)?Te(t,i):Ce(t)[0]?.[0]||`desktop`}var Qe=32768,$e=16384,et=16384,tt=65536;function nt(e){return new TextEncoder().encode(e).length}function rt(){let e=new Uint8Array(16);return globalThis.crypto.getRandomValues(e),Array.from(e,e=>e.toString(16).padStart(2,`0`)).join(``)}function it(e=globalThis.document){let t=e?.querySelector?.(`meta[name="juzimder-csp-nonce"]`)?.content;return typeof t==`string`&&/^[a-f0-9]{32}$/.test(t)?t:rt()}function at(e){if(!e||typeof e!=`object`||Array.isArray(e))throw TypeError(`HTML-элемент ожидает объект HTML/CSS/JavaScript.`);let t=Object.keys(e).sort();if(t.length!==3||t[0]!==`css`||t[1]!==`html`||t[2]!==`js`||t.some(t=>typeof e[t]!=`string`))throw TypeError(`В HTML-элементе допустимы только поля HTML, CSS и JavaScript.`);let n=nt(e.html),r=nt(e.css),i=nt(e.js);if(n>Qe||r>$e||i>et||n+r+i>tt)throw RangeError(`Код HTML-элемента превышает допустимый размер.`);if(/<\/style\s*>/i.test(e.css))throw TypeError(`В CSS HTML-элемента нельзя закрывать тег style.`);return{html:e.html,css:e.css,js:e.js}}function ot(e){let t=new TextEncoder().encode(e),n=``;for(let e=0;e<t.length;e+=8192)n+=String.fromCharCode(...t.subarray(e,e+8192));return btoa(n)}function st(e,t=rt()){let n=at(e);if(!/^[a-f0-9]{32}$/.test(t))throw TypeError(`Некорректный nonce изолированной песочницы.`);let r=n.js===``?``:`<script nonce="${t}">(function(){const data=${JSON.stringify(ot(n.js))};const bytes=Uint8Array.from(atob(data),c=>c.charCodeAt(0));const code=new TextDecoder().decode(bytes);const node=document.createElement("script");node.nonce=document.currentScript.nonce;node.textContent=code;document.body.append(node);})();<\/script>`;return`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="${`default-src 'none'; script-src 'nonce-${t}'; connect-src 'none'; img-src data: blob:; media-src data: blob:; font-src data:; style-src 'unsafe-inline'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'`}"><style>*,*::before,*::after{box-sizing:border-box}body{margin:0}${n.css}</style></head><body>${n.html}${r}</body></html>`}function ct(e,{id:t=``,runScripts:n=!1,title:r=`HTML-элемент`,nonce:i=it()}={}){let a=st(e,i),o=n&&e.js!==``?`allow-scripts`:``,s=e=>String(e).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]);return`<iframe class="jz-zero-element jz-zero-code" data-ze="${s(t)}" data-zero-code="true"${n?` data-code-running="true"`:``} title="${s(r)}" sandbox="${o}" referrerpolicy="no-referrer" srcdoc="${s(a)}"></iframe>`}var lt=Object.freeze({"arrow-left":`Стрелка влево`,"arrow-right":`Стрелка вправо`,"arrow-up":`Стрелка вверх`,"arrow-down":`Стрелка вниз`,"chevron-right":`Шеврон`,plus:`Плюс`,minus:`Минус`,x:`Крестик`,link:`Ссылка`,search:`Поиск`,photo:`Фото`,eye:`Глаз`,settings:`Настройки`,download:`Скачать`,copy:`Копировать`,square:`Квадрат`,circle:`Круг`,menu:`Меню`,trash:`Корзина`,lock:`Замок`,"lock-open":`Открытый замок`,stethoscope:`Стетоскоп`,microscope:`Микроскоп`,"baby-bottle":`Бутылочка для младенца`,"first-aid-kit":`Аптечка`}),ut=Object.freeze(Object.keys(lt)),dt=/^[A-Za-z0-9_-]{11}$/;function ft(e){if(typeof e!=`string`||!e||e.length>2048)return null;let t;try{t=new URL(e)}catch{return null}let n=e.match(/^https:\/\/([^/?#]*)/i)?.[1]||``;if(t.protocol!==`https:`||t.username||t.password||/:\d+$/.test(n)||t.hash)return null;let r=t.hostname.toLowerCase();if([`youtube.com`,`www.youtube.com`,`youtube-nocookie.com`,`www.youtube-nocookie.com`].includes(r)){let e=t.pathname.match(/^\/(?:embed|shorts|live)\/([A-Za-z0-9_-]{11})\/?$/);if(e)return`https://www.youtube-nocookie.com/embed/${e[1]}`;if(t.pathname===`/watch`){let e=t.searchParams.getAll(`v`);if(e.length===1&&dt.test(e[0]))return`https://www.youtube-nocookie.com/embed/${e[0]}`}return null}if(r===`youtu.be`){let e=t.pathname.match(/^\/([A-Za-z0-9_-]{11})\/?$/);return e?`https://www.youtube-nocookie.com/embed/${e[1]}`:null}if([`vimeo.com`,`www.vimeo.com`].includes(r)){let e=t.pathname.match(/^\/([0-9]{1,12})\/?$/);return e?`https://player.vimeo.com/video/${e[1]}`:null}if(r===`player.vimeo.com`){let e=t.pathname.match(/^\/video\/([0-9]{1,12})\/?$/);return e?`https://player.vimeo.com/video/${e[1]}`:null}return null}var j=e=>String(e??``).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]);function pt(e){return e.some(e=>e.type===`tooltip`||e.children?.length&&pt(e.children))}function mt(e){return e.some(e=>e.type===`vector`||e.children?.length&&mt(e.children))}function ht(e){return e.some(e=>e.type===`video`||e.children?.length&&ht(e.children))}function gt(e){return e.some(e=>e.type===`form`||e.children?.length&&gt(e.children))}function _t(e){return e.some(e=>e.type===`gallery`||e.children?.length&&_t(e.children))}function vt(e){let t=/^#([a-f\d]{6})$/i.exec(String(e||``));return t?[0,2,4].map(e=>parseInt(t[1].slice(e,e+2),16)/255).map(e=>e<=.04045?e/12.92:((e+.055)/1.055)**2.4).reduce((e,t,n)=>e+t*[.2126,.7152,.0722][n],0)>.179?`#222629`:`#ffffff`:`#222629`}function yt(e,t=e?.style||{}){if(e?.type!==`text`)return!1;if(/(?:badge|pill|бейдж|пилюля)/iu.test(String(e.name||``)))return!0;let n=t.fill,r=typeof n==`string`?n.trim()!==``&&n.trim().toLowerCase()!==`transparent`:!!(n&&typeof n==`object`),i=String(e.content||``).trim();return r&&Number(t.radius||0)>=10&&Number(t.fontSize||99)<=18&&i.length>0&&i.length<=64}function bt(e,t=``){let n=j(e.content||``);if(e.runs&&(n=e.runs.map(e=>{let t=j(e.text);return e.bold&&(t=`<strong>${t}</strong>`),e.italic&&(t=`<em>${t}</em>`),e.underline&&(t=`<u>${t}</u>`),t}).join(``)),e.type===`image`)return`<img src="${j(e.src)}" alt="${j(e.alt||``)}" draggable="false" style="width:100%;height:100%;object-fit:inherit;object-position:inherit;border-radius:inherit">`;if(e.type===`tooltip`){let t=`jz-tooltip-${j(e.id)}`;return`<button class="jz-zero-tooltip-trigger" type="button" aria-label="Показать подсказку" aria-describedby="${t}">?</button><span class="jz-zero-tooltip-popover" id="${t}" role="tooltip">${n}</span>`}if(e.type===`vector`)return ut.includes(e.icon)?h[e.icon]:h[`arrow-right`];if(e.type===`video`){let t=ft(e.videoUrl);return t?`<iframe title="${j(e.name||`Видео`)}" src="${t}" loading="lazy" referrerpolicy="no-referrer" sandbox="allow-scripts allow-same-origin allow-presentation" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>`:`<span class="jz-zero-video-placeholder" role="img" aria-label="${j(e.name||`Видео`)}">Добавьте ссылку YouTube или Vimeo в настройках</span>`}if(e.type===`form`){let t=`jz-form-note-${j(e.id)}`,n=(e.formFields||[]).map(t=>{let n=`jz-form-${j(e.id)}-${j(t.id)}`,r=`${j(t.label)}${t.required?`<span class="jz-zero-form-required" aria-hidden="true"> *</span>`:``}`,i=t.required?` aria-required="true"`:``;return`<label class="jz-zero-form-field" for="${n}"><span>${r}</span>${t.type===`textarea`?`<textarea class="jz-zero-form-control" id="${n}" placeholder="${j(t.placeholder)}" readonly aria-readonly="true"${i}></textarea>`:`<input class="jz-zero-form-control" id="${n}" type="${j(t.type)}" placeholder="${j(t.placeholder)}" readonly aria-readonly="true"${i}>`}</label>`}).join(``);return`<div class="jz-zero-form-fields" role="group" aria-label="${j(e.name||`Форма`)}" aria-describedby="${t}">${n}<button class="jz-zero-form-submit" type="button" disabled aria-disabled="true">${j(e.submitLabel||`Отправить`)}</button><p class="jz-zero-form-note" id="${t}">Отправка формы пока не подключена.</p></div>`}if(e.type===`gallery`){let t=(e.galleryItems||[]).map(e=>`<figure class="jz-zero-gallery-item" role="listitem"><img src="${j(e.src)}" alt="${j(e.alt||``)}" loading="lazy" decoding="async" draggable="false"></figure>`).join(``);return`<div class="jz-zero-gallery-grid" role="list" aria-label="${j(e.name||`Галерея`)}">${t||`<span class="jz-zero-gallery-empty">Добавьте фото в настройках галереи</span>`}</div>`}return e.type===`group`?t:n}function xt(e){let t=/^(?:#[a-f\d]{6}|transparent)$/i.test(e.background||``)?e.background:`#ffffff`,n=t===`transparent`?`#ffffff`:t,r=Number.isFinite(e.backgroundOpacity)?Math.max(0,Math.min(1,e.backgroundOpacity)):t===`transparent`?0:1,i=r>=1?n:`rgba(${[1,3,5].map(e=>Number.parseInt(n.slice(e,e+2),16)).join(`,`)},${r})`,a=/^\/api\/projects\/[a-f\d]{24}\/assets\/[a-f\d]{24}\/file$/.test(e.backgroundImage||``),o=se(e.backgroundFill);if(!a)return`background:${i};${o?`background-image:${o};`:``}`;let s=(t,n)=>{let r=/^#[a-f\d]{6}$/i.test(e[t]||``)?e[t]:`#000000`,i=[1,3,5].map(e=>Number.parseInt(r.slice(e,e+2),16)),a=Number.isFinite(e[n])?Math.max(0,Math.min(1,e[n])):0;return`rgba(${i.join(`,`)},${a})`},c=[`cover`,`contain`,`auto`,`100% 100%`].includes(e.backgroundSize)?e.backgroundSize:`cover`,l=[`center center`,`left top`,`center top`,`right top`,`left center`,`right center`,`left bottom`,`center bottom`,`right bottom`].includes(e.backgroundPosition)?e.backgroundPosition:`center center`,u=[`linear-gradient(180deg,${s(`filterStartColor`,`filterStartOpacity`)},${s(`filterEndColor`,`filterEndOpacity`)})`];return o&&u.push(o),u.push(`url("${e.backgroundImage}")`),`background:${i};background-image:${u.join(`,`)};background-size:${c};background-position:${l};background-repeat:no-repeat;`}function St(e,t,n=null,{runScripts:r=!1}={}){let i=`jz-zero-`+String(t).replace(/[^a-zA-Z0-9_-]/g,``),a=Ce(e).map(([e])=>e),o=[...a].reverse().filter(e=>e!==`desktop`),s=new Set,c=`.${i}{position:relative!important;display:block!important;width:${n?`${e.artboards[n].width}px`:`100%`}!important;box-sizing:border-box;isolation:isolate}.`+i+` .jz-zero-element{margin:0;padding:0;white-space:pre-wrap;min-width:0;min-height:0;max-width:none;font-family:inherit;overflow-wrap:anywhere}.`+i+` a.jz-zero-element{padding:12px 16px;text-align:center;text-decoration:none}.`+i+` a.jz-zero-button{align-items:center;justify-content:center;text-align:center}.`+i+` [data-zero-image]{padding:0}.`+i+` .jz-zero-code{border:0;padding:0;overflow:hidden;pointer-events:none}.`+i+` .jz-zero-code[data-code-running="true"]{pointer-events:auto}`;pt(e.elements)&&(c+=`.${i} .jz-zero-tooltip{overflow:visible!important;white-space:normal}.${i} .jz-zero-tooltip-trigger{display:flex;align-items:center;justify-content:center;box-sizing:border-box;width:28px;height:28px;padding:0;border:1px solid currentColor;border-radius:50%;background:transparent;color:inherit;font:inherit;line-height:1;cursor:help}.${i} .jz-zero-tooltip-popover{position:absolute;left:50%;top:calc(100% + 8px);z-index:10000;width:max-content;max-width:280px;box-sizing:border-box;padding:8px 12px;border:0;border-radius:8px;background:#183e31;color:#fff;font:14px/1.4 system-ui,sans-serif;text-align:left;white-space:pre-wrap;overflow-wrap:anywhere;box-shadow:0 8px 24px rgba(0,0,0,.2);opacity:0;visibility:hidden;pointer-events:none;transform:translateX(-50%);transition:opacity .12s ease,visibility .12s ease}.${i} .jz-zero-tooltip:hover .jz-zero-tooltip-popover, .${i} .jz-zero-tooltip:focus-within .jz-zero-tooltip-popover{opacity:1;visibility:visible}`),mt(e.elements)&&(c+=`.${i} .jz-zero-vector{display:flex;align-items:center;justify-content:center}.${i} .jz-zero-vector>svg{display:block;width:100%;height:100%;max-width:100%;max-height:100%}`),ht(e.elements)&&(c+=`.${i} .jz-zero-video{overflow:hidden;padding:0!important;background:#111}.${i} .jz-zero-video>iframe{display:block;width:100%;height:100%;border:0}.${i} .jz-zero-video-placeholder{display:flex;width:100%;height:100%;align-items:center;justify-content:center;padding:16px;background:#111;color:#fff;font:14px/1.4 system-ui,sans-serif;text-align:center}.zero-app:not(.zero-preview) .${i} .jz-zero-video>iframe{pointer-events:none}`),gt(e.elements)&&(c+=`.${i} .jz-zero-form{overflow:auto;white-space:normal}.${i} .jz-zero-form-fields{display:grid;align-content:start;gap:12px;width:100%;min-height:100%;box-sizing:border-box;font:14px/1.4 system-ui,sans-serif;white-space:normal}.${i} .jz-zero-form-field{display:grid;gap:5px;color:inherit;font-weight:600}.${i} .jz-zero-form-control{box-sizing:border-box;width:100%;min-height:40px;padding:9px 11px;border:1px solid rgba(24,62,49,.28);border-radius:8px;background:rgba(255,255,255,.9);color:#183e31;font:14px/1.4 system-ui,sans-serif;white-space:normal}.${i} textarea.jz-zero-form-control{min-height:76px;resize:none}.${i} .jz-zero-form-required{color:#b42318}.${i} .jz-zero-form-submit{min-height:40px;padding:10px 14px;border:0;border-radius:8px;background:#245b46;color:#fff;font:600 14px/1.2 system-ui,sans-serif;opacity:.62;cursor:not-allowed}.${i} .jz-zero-form-note{margin:0;color:rgba(24,62,49,.72);font:12px/1.4 system-ui,sans-serif}.zero-app:not(.zero-preview) .${i} .jz-zero-form-fields{pointer-events:none}`),_t(e.elements)&&(c+=`.${i} .jz-zero-gallery{overflow:hidden!important;white-space:normal}.${i} .jz-zero-gallery-grid{display:grid;grid-template-columns:repeat(var(--jz-gallery-columns,3),minmax(0,1fr));grid-template-rows:repeat(var(--jz-gallery-rows,1),minmax(0,1fr));gap:var(--jz-gallery-gap,16px);width:100%;height:100%;box-sizing:border-box}.${i} .jz-zero-gallery-item{min-width:0;min-height:0;margin:0;overflow:hidden;border-radius:var(--jz-gallery-radius,0px)}.${i} .jz-zero-gallery-item img{display:block;width:100%;height:100%;object-fit:var(--jz-gallery-fit,cover);border-radius:inherit}.${i} .jz-zero-gallery-empty{grid-column:1/-1;display:flex;align-items:center;justify-content:center;min-width:0;min-height:0;color:inherit;text-align:center;white-space:normal}`);let l=(t,r)=>n||t===`desktop`?r:`@media(max-width:${we(e,t)}px){${r}}`;for(let t of n?[n]:a){let r=e.artboards[t],a=!n&&r.scaleGrid===`autoscale`;c+=l(t,`.${i}{height:${a?Ke(r.height,r,!0):`${r.height}px`};${xt(r)}overflow:${r.overflow}}`),c+=l(t,`.${i} .jz-zero-photo-credit{color:${vt(r.background)}!important}`)}let u=(t,d=!1,f={})=>t.map((t,p)=>{for(let o of n?[n]:a){let a=Ie(t,o),u=a.style,m=yt(a,u),h=e.artboards[o],g=d?f[o]:a.geometry.container===`grid`,_=!n&&h.scaleGrid===`autoscale`&&g,v=t.type===`button`?`.${i} a.jz-zero-button[data-ze="${t.id}"]`:t.type===`tooltip`?`.${i} .jz-zero-tooltip[data-ze="${t.id}"]`:`.${i} [data-ze="${t.id}"]`,y=t.type===`button`||m?Je({...u,textAlign:`center`},h,_):Je(u,h,_),b=_&&t.type===`button`?`padding:${Ke(12,h,!0)} ${Ke(16,h,!0)};`:``,x=``,S=t.animation;if(S&&(!n||r)&&[`fade`,`move`,`scale`].includes(S.effect)&&Number.isInteger(S.duration)&&S.duration>=100&&S.duration<=3e3&&Number.isInteger(S.delay)&&S.delay>=0&&S.delay<=5e3&&[`linear`,`ease`,`ease-in`,`ease-out`,`ease-in-out`].includes(S.easing)){if(!s.has(S.effect)){s.add(S.effect);let e={fade:`from{opacity:0}to{opacity:var(--jz-zero-end-opacity,1)}`,move:`from{opacity:0;translate:0 16px}to{opacity:var(--jz-zero-end-opacity,1);translate:0 0}`,scale:`from{opacity:0;scale:.92}to{opacity:var(--jz-zero-end-opacity,1);scale:1}`}[S.effect];c+=`@keyframes ${i}-${S.effect}{${e}}`}x=`--jz-zero-end-opacity:${Number(u.opacity??1)};animation:${i}-${S.effect} ${S.duration}ms ${S.easing} ${S.delay}ms both;`}if(t.type===`gallery`){let e=t.galleryOptions||{columns:3,gap:16,objectFit:`cover`},n=Math.min(e.columns,Math.max(1,t.galleryItems?.length||1),h.width<=480?1:h.width<=820?2:e.columns),r=Math.max(1,Math.ceil((t.galleryItems?.length||1)/n)),i=e=>_?Ke(e,h,!0):`${e}px`,a=`--jz-gallery-columns:${n};--jz-gallery-rows:${r};--jz-gallery-gap:${i(e.gap)};--jz-gallery-fit:${e.objectFit};--jz-gallery-radius:${i(u.radius||0)};`;c+=l(o,`${v}{${a}}`)}let C=u.hoverFill&&typeof u.hoverFill==`object`?`background-color:transparent;background-image:${se(u.hoverFill)};`:u.hoverFill?`background-color:${u.hoverFill};`:``,w=u.hoverFill||u.hoverColor?`${v}:hover{${C}${u.hoverColor?`color:${u.hoverColor};`:``}}`:``;c+=l(o,`${v}{${qe(a.geometry,h,d,_)}${y}${b}${x}z-index:${p+1};display:${a.visible?t.type===`button`||m?`flex`:t.type===`tooltip`?`grid`:t.type===`vector`?`flex`:`block`:`none`};${m?`align-items:center;justify-content:center;text-align:center;`:``}${t.type===`ellipse`?`border-radius:50%;`:``}${t.type===`image`&&!u.objectFit?`object-fit:cover;`:``}${t.type===`tooltip`?`overflow:visible;`:``}${t.type===`video`?`overflow:hidden;`:``}}${w}`)}let m=Object.fromEntries(a.map(e=>[e,d?f[e]:Ie(t,e).geometry.container===`grid`])),h=Ie(t,n||`desktop`),g=yt(h,h.style),_=t.type===`text`?h.tag||`p`:t.type===`button`||t.type===`image`&&h.href?`a`:`div`,v=bt(h,t.children?u(t.children,!0,m):``);return t.type===`html`&&(v=ct(h.code,{id:t.id,runScripts:r,title:t.name||`HTML-элемент`})),t.type===`image`&&!n&&(v=`<picture style="display:block;width:100%;height:100%;object-fit:inherit;object-position:inherit;border-radius:inherit">${o.map(n=>`<source media="(max-width:${we(e,n)}px)" srcset="${j(Ie(t,n).src.replace(/,/g,`%2C`))}">`).join(``)}${v}</picture>`),t.type===`image`&&String(h.copyright||``).trim()&&(v+=`<span class="jz-zero-photo-credit">${j(h.copyright)}</span>`),t.type===`html`?v:`<${_} class="jz-zero-element${g?` jz-zero-badge`:``}${t.type===`button`?` jz-zero-button`:``}${t.type===`tooltip`?` jz-zero-tooltip`:``}${t.type===`vector`?` jz-zero-vector`:``}${t.type===`video`?` jz-zero-video`:``}${t.type===`form`?` jz-zero-form`:``}${t.type===`gallery`?` jz-zero-gallery`:``}" data-ze="${j(t.id)}"${t.type===`vector`?` role="img" aria-label="${j(h.name||`Вектор`)}"`:``}${t.type===`gallery`?` role="group" aria-label="${j(h.name||`Галерея`)}"`:``}${t.type===`image`?` data-zero-image="true"`:``}${_===`a`?` href="${j(h.href||`#`)}" target="${j(h.target||`_self`)}" rel="noopener noreferrer"`:``}>${v}</${_}>`}).join(``),d=u(e.elements);return c+=`.${i} .jz-zero-photo-credit{position:absolute;left:0;top:calc(100% + 2px);display:block;box-sizing:border-box;width:100%;height:auto;min-height:0;margin:0;padding:0;border:0;background:transparent;font-size:8px;line-height:1.2;font-family:inherit;font-weight:400;text-align:left;white-space:normal;overflow-wrap:anywhere}`,s.size&&(c+=`@media(prefers-reduced-motion:reduce){.${i} .jz-zero-element{animation:none!important;translate:none!important;scale:none!important}}`),`<section class="jz-zero-block ${i}" data-zero-id="${j(t)}"><style>${c}</style>${d}</section>`}function Ct(e,{projectId:t,projectSlug:n,beforeOpen:r,isClean:i,onRemote:a,notify:o}){let s=async a=>{if(!a||a.get(`type`)!==`zero-block`)return;let s=window.open(`about:blank`,`jz-zero-${a.getId()}`);if(!s){o(`Разрешите открытие Zero Editor в новом окне.`,!0);return}let c=e.Pages.getSelected().id;s.opener=null,await r(),i()?s.location.href=`/projects/${encodeURIComponent(n||t)}/pages/${c}/zero/${a.getAttributes().id}/edit`:(s.close(),o(`Сначала сохраните изменения и разрешите конфликт.`,!0))};e.Commands.add(`zero:edit`,{run:()=>s(e.getSelected())}),e.Components.addType(`zero-block`,{model:{defaults:{tagName:`section`,name:`Zero Block`,droppable:!1,editable:!1,stylable:!1,resizable:!1,zeroData:null,components:[],traits:[]},init(){this.get(`zeroData`)||this.set(`zeroData`,Ne(),{silent:!0}),this.getAttributes().id||this.addAttributes({id:`zero-${crypto.randomUUID()}`})},toHTML(){return St(this.get(`zeroData`),this.getAttributes().id)}},view:{events:{dblclick:`editZero`},editZero(e){e.preventDefault(),e.stopPropagation(),s(this.model)},init(){this.listenTo(this.model,`change:zeroData change:attributes`,this.render)},onRender(){let t=this.model.get(`zeroData`);this.el.innerHTML=St(t,this.model.getAttributes().id,Ze(e,t)),this.el.querySelector(`.jz-zero-block`).style.pointerEvents=`none`}}}),e.Blocks.add(`zero-block`,{label:`Zero Block`,category:`Секции`,content:{type:`zero-block`}});let c=document.createElement(`button`);c.type=`button`,c.className=`block-card`,c.dataset.category=`Секции`,c.innerHTML=`<div class="block-media" aria-hidden="true">${S(`layout-grid`)}</div><strong>Zero Block</strong>`,c.onclick=()=>{let[t]=e.addComponents({type:`zero-block`});e.select(t)},document.querySelector(`.block-list`).prepend(c);let l=document.createElement(`button`);l.type=`button`,l.textContent=`Редактировать Zero Block`,l.hidden=!0,l.id=`edit-zero-block`,l.onclick=()=>s(e.getSelected()),document.querySelector(`#quick-edit`).prepend(l);let u=document.createElement(`p`);u.id=`zero-info`,u.textContent=`Свободная абсолютная компоновка. Координаты элементов настраиваются в Zero Editor.`,u.hidden=!0,document.querySelector(`#quick-edit`).append(u),e.on(`component:selected`,e=>{u.hidden=e.get(`type`)!==`zero-block`,l.hidden=e.get(`type`)!==`zero-block`}),e.on(`component:deselected`,()=>{l.hidden=!0,u.hidden=!0}),e.on(`device:select`,()=>{let t=e=>{e.get(`type`)===`zero-block`&&e.getView()?.render(),e.components().each(t)};t(e.getWrapper())});let d=new BroadcastChannel(`jz-zero-${t}`);d.onmessage=e=>{let n=e.data;n?.type===`zero:saved`&&n.projectId===t&&a(n)},e.on(`destroy`,()=>d.close())}var wt={column1:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M2 20h20V4H2v16Zm-1 0V4a1 1 0 0 1 1-1h20a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1Z"/>
      </svg>`,column2:`<svg viewBox="0 0 23 24">
        <path fill="currentColor" d="M2 20h8V4H2v16Zm-1 0V4a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1ZM13 20h8V4h-8v16Zm-1 0V4a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-8a1 1 0 0 1-1-1Z"/>
      </svg>`,column3:`<svg viewBox="0 0 23 24">
        <path fill="currentColor" d="M2 20h4V4H2v16Zm-1 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1ZM17 20h4V4h-4v16Zm-1 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1ZM9.5 20h4V4h-4v16Zm-1 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1Z"/>
      </svg>`,"column3-7":`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M2 20h5V4H2v16Zm-1 0V4a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1ZM10 20h12V4H10v16Zm-1 0V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H10a1 1 0 0 1-1-1Z"/>
      </svg>`,text:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M18.5,4L19.66,8.35L18.7,8.61C18.25,7.74 17.79,6.87 17.26,6.43C16.73,6 16.11,6 15.5,6H13V16.5C13,17 13,17.5 13.33,17.75C13.67,18 14.33,18 15,18V19H9V18C9.67,18 10.33,18 10.67,17.75C11,17.5 11,17 11,16.5V6H8.5C7.89,6 7.27,6 6.74,6.43C6.21,6.87 5.75,7.74 5.3,8.61L4.34,8.35L5.5,4H18.5Z" />
      </svg>`,link:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M3.9,12C3.9,10.29 5.29,8.9 7,8.9H11V7H7A5,5 0 0,0 2,12A5,5 0 0,0 7,17H11V15.1H7C5.29,15.1 3.9,13.71 3.9,12M8,13H16V11H8V13M17,7H13V8.9H17C18.71,8.9 20.1,10.29 20.1,12C20.1,13.71 18.71,15.1 17,15.1H13V17H17A5,5 0 0,0 22,12A5,5 0 0,0 17,7Z" />
      </svg>`,image:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M21,3H3C2,3 1,4 1,5V19A2,2 0 0,0 3,21H21C22,21 23,20 23,19V5C23,4 22,3 21,3M5,17L8.5,12.5L11,15.5L14.5,11L19,17H5Z" />
      </svg>`,video:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M10,15L15.19,12L10,9V15M21.56,7.17C21.69,7.64 21.78,8.27 21.84,9.07C21.91,9.87 21.94,10.56 21.94,11.16L22,12C22,14.19 21.84,15.8 21.56,16.83C21.31,17.73 20.73,18.31 19.83,18.56C19.36,18.69 18.5,18.78 17.18,18.84C15.88,18.91 14.69,18.94 13.59,18.94L12,19C7.81,19 5.2,18.84 4.17,18.56C3.27,18.31 2.69,17.73 2.44,16.83C2.31,16.36 2.22,15.73 2.16,14.93C2.09,14.13 2.06,13.44 2.06,12.84L2,12C2,9.81 2.16,8.2 2.44,7.17C2.69,6.27 3.27,5.69 4.17,5.44C4.64,5.31 5.5,5.22 6.82,5.16C8.12,5.09 9.31,5.06 10.41,5.06L12,5C16.19,5 18.8,5.16 19.83,5.44C20.73,5.69 21.31,6.27 21.56,7.17Z" />
      </svg>`,map:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M20.5,3L20.34,3.03L15,5.1L9,3L3.36,4.9C3.15,4.97 3,5.15 3,5.38V20.5A0.5,0.5 0 0,0 3.5,21L3.66,20.97L9,18.9L15,21L20.64,19.1C20.85,19.03 21,18.85 21,18.62V3.5A0.5,0.5 0 0,0 20.5,3M10,5.47L14,6.87V18.53L10,17.13V5.47M5,6.46L8,5.45V17.15L5,18.31V6.46M19,17.54L16,18.55V6.86L19,5.7V17.54Z" />
      </svg>`,form:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 5.5c0-.3-.5-.5-1.3-.5H3.4c-.8 0-1.3.2-1.3.5v3c0 .3.5.5 1.3.5h17.4c.8 0 1.3-.2 1.3-.5v-3zM21 8H3V6h18v2zM22 10.5c0-.3-.5-.5-1.3-.5H3.4c-.8 0-1.3.2-1.3.5v3c0 .3.5.5 1.3.5h17.4c.8 0 1.3-.2 1.3-.5v-3zM21 13H3v-2h18v2z"/><rect width="10" height="3" x="2" y="15" rx=".5"/></svg>`,input:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 9c0-.6-.5-1-1.3-1H3.4C2.5 8 2 8.4 2 9v6c0 .6.5 1 1.3 1h17.4c.8 0 1.3-.4 1.3-1V9zm-1 6H3V9h18v6z"/><path d="M4 10h1v4H4z"/></svg>`,textarea:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 7.5c0-.9-.5-1.5-1.3-1.5H3.4C2.5 6 2 6.6 2 7.5v9c0 .9.5 1.5 1.3 1.5h17.4c.8 0 1.3-.6 1.3-1.5v-9zM21 17H3V7h18v10z"/><path d="M4 8h1v4H4zM19 7h1v10h-1zM20 8h1v1h-1zM20 15h1v1h-1z"/></svg>`,select:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 9c0-.6-.5-1-1.3-1H3.4C2.5 8 2 8.4 2 9v6c0 .6.5 1 1.3 1h17.4c.8 0 1.3-.4 1.3-1V9zm-1 6H3V9h18v6z"/><path d="M18.5 13l1.5-2h-3zM4 11.5h11v1H4z"/></svg>`,button:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 9c0-.6-.5-1-1.3-1H3.4C2.5 8 2 8.4 2 9v6c0 .6.5 1 1.3 1h17.4c.8 0 1.3-.4 1.3-1V9zm-1 6H3V9h18v6z"/><path d="M4 11.5h16v1H4z"/></svg>`,label:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 11.9c0-.6-.5-.9-1.3-.9H3.4c-.8 0-1.3.3-1.3.9V17c0 .5.5.9 1.3.9h17.4c.8 0 1.3-.4 1.3-.9V12zM21 17H3v-5h18v5z"/><rect width="14" height="5" x="2" y="5" rx=".5"/><path d="M4 13h1v3H4z"/></svg>`,checkbox:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M10 17l-5-5 1.41-1.42L10 14.17l7.59-7.59L19 8m0-5H5c-1.11 0-2 .89-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5a2 2 0 0 0-2-2z"></path></svg>`,radio:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8m0-18C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 5c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5z"></path></svg>`},Tt={"text-link":`link`,heading:`text`,paragraph:`textarea`,"link-block":`link`,container:`column1`},Et={"vacancy-detail":`file-text`,"course-outcomes":`layout-grid`,"event-ticket-options":`columns-3`,"venue-guidelines":`clipboard`,"volunteer-roles":`menu`,"case-results":`columns-3`,"project-roadmap":`layout-distribute-horizontal`,"warranty-care":`history`,breadcrumbs:`chevron-right`,"article-byline":`file-text`,"release-notes":`history`,"product-variants":`layout-grid`,"feature-matrix":`columns-3`,"onboarding-checklist":`clipboard`,"support-expectations":`menu`,"privacy-contacts":`file-text`,"branch-locations":`layout-grid`,"event-calendar":`history`,"review-sources":`quote`,"awards-history":`file-text`,"email-updates":`arrow-right`,"accessibility-info":`layout-grid`,"community-participation":`menu`,"newsletter-contact":`arrow-right`,credentials:`file-text`,"partner-network":`layout-grid`,"social-channels":`menu`,"payment-options":`device-floppy`,"service-coverage":`layout-grid`,"metrics-strip":`columns-3`,"question-groups":`text-wrap`,"image-comparison":`photo`,"option-comparison":`columns-3`,"before-start":`clipboard`,"download-catalog":`download`,"page-directory":`layout-grid`,"service-boundaries":`columns-3`,"appointment-info":`history`,"exhibition-grid":`photo`,"policy-summary":`file-text`,"cover-panorama":`device-desktop`,"feature-spotlight":`columns-3`,"destination-grid":`photo`,"event-announcement":`history`,"case-timeline":`layout-distribute-vertical`,"offer-inclusions":`clipboard`,"photo-story":`photo`,"founder-letter":`typography`,"press-feature":`file-text`,"opening-hours":`history`,"course-program":`file-text`,"learning-format":`device-desktop`,"instructor-grid":`photo`,"audience-fit":`layout-grid`,"project-deliverables":`clipboard`,"collaboration-steps":`layout-distribute-horizontal`,"job-openings":`file-text`,"resource-library":`columns-3`,"office-grid":`photo`,"support-channels":`menu`,"product-catalog":`layout-grid`,"product-detail":`photo`,"restaurant-menu":`menu`,"weekly-schedule":`history`,"document-links":`file-text`,"service-detail":`columns-3`,"delivery-info":`arrow-right`,"location-card":`photo`,"editorial-intro":`typography`,"gallery-captions":`photo`,"about-split":`columns-3`,"services-list":`menu`,"benefits-split":`layout-grid`,"portfolio-grid":`photo`,"case-study":`file-text`,"faq-grid":`text-wrap`,"price-list":`file-text`,"event-program":`history`,"team-profile":`photo`,"cta-split":`arrow-right`,hero:`device-desktop`,features:`layout-grid`,cta:`arrow-right`,navigation:`menu`,process:`layout-distribute-horizontal`,testimonial:`typography`,faq:`text-wrap`,footer:`align-box-bottom-center`,flexbox:`layout-distribute-horizontal`,"bullet-list":`menu`,divider:`spacing-vertical`,spacer:`arrows-vertical`,quote:`typography`,"content-card":`file-text`,"image-card":`photo`,"card-grid":`layout-grid`,article:`file-text`,"article-grid":`columns-3`,gallery:`photo`,pricing:`columns-3`,team:`layout-grid`,"cover-centered":`align-box-center-middle`,"cover-split":`columns-3`,"contact-details":`file-text`,"footer-columns":`align-box-bottom-center`};Object.assign(Et,{"account-recovery-guide":`history`,"planned-maintenance":`history`,"compatibility-matrix":`columns-3`,"data-migration-guide":`layout-distribute-horizontal`,"api-integration-guide":`device-desktop`,"admin-roles-guide":`menu`,"trial-period-guide":`history`,"service-level-overview":`columns-3`,"size-fit-guide":`layout-grid`,"product-origin":`file-text`,"accommodation-info":`photo`,"reservation-policy":`history`,"event-access-guide":`layout-grid`,"incident-report":`history`,"security-disclosure":`clipboard`,"membership-benefits":`columns-3`,"return-policy":`file-text`,"subscription-management":`history`,"privacy-request-guide":`clipboard`,"grant-application":`file-text`,"press-kit":`download`,"conference-session":`photo`,"course-enrollment":`layout-distribute-horizontal`,"service-status":`history`,"property-listing":`photo`,"rental-terms":`file-text`,"trip-itinerary":`history`,"menu-allergens":`clipboard`,"clinic-visit-prep":`history`,"software-requirements":`device-desktop`,"research-methodology":`file-text`,"donation-transparency":`columns-3`});var Dt=e=>wt[e]||wt[Tt[e]]||S(Et[e]||`square`);function Ot({editor:e,projectId:t,api:n,csrf:r,insert:i,notify:a,allowExternalUrl:o=!0}){let s=document.querySelector(`#image-dialog`);s.innerHTML=`<div class="asset-dialog-head"><div><p class="eyebrow">МЕДИА САЙТА</p><h2 id="image-dialog-title">Выберите изображение</h2></div><button type="button" id="close-image" aria-label="Закрыть изображения">${S(`x`)}</button></div>
    <nav class="image-source-tabs" aria-label="Источник изображения"><button type="button" data-image-source="library" aria-pressed="true">Библиотека сайта <span id="asset-count"></span></button>${o?`<button type="button" data-image-source="url" aria-pressed="false">По ссылке</button>`:``}</nav>
    <section id="image-library-panel"><div class="asset-upload-zone" id="asset-drop-zone"><div><strong>Добавьте свои фотографии</strong><p>Перетащите файл сюда или выберите его на компьютере.</p><small>PNG, JPEG, WebP, GIF · до 4 МБ · хранилище сайта 20 МБ</small></div><button type="button" class="primary" id="upload-asset">${S(`arrow-up`)} Загрузить с компьютера</button><input id="asset-file" type="file" accept="image/png,image/jpeg,image/gif,image/webp" hidden></div>
    <div class="asset-library-toolbar"><label class="asset-search-label"><span class="visually-hidden">Поиск по библиотеке сайта</span><input type="search" id="asset-search" placeholder="Найти изображение по имени"></label><button type="button" id="refresh-assets" title="Обновить библиотеку" aria-label="Обновить библиотеку">${S(`arrow-back-up`)}</button></div><p id="asset-status" role="status" aria-live="polite"></p><div id="asset-library" class="asset-library"></div></section>
    ${o?`<section id="image-url-panel" hidden><form id="image-form"><label>HTTPS-адрес изображения<input name="src" type="url" required pattern="https://.*" placeholder="https://example.com/photo.jpg"></label><p class="muted small">Изображение по ссылке не загружается в личную библиотеку сайта.</p></form></section>`:``}
    <footer class="image-picker-footer"><label>Описание изображения <span class="muted small">для доступности</span><input id="image-alt" maxlength="200" placeholder="Что изображено на фотографии?"></label><div class="image-picker-actions"><span id="asset-selection" class="muted small">Выберите фото из библиотеки</span><button type="button" id="cancel-image">Отмена</button><button type="button" class="primary" id="insert-image" disabled>Вставить изображение</button></div></footer>`;let c=e=>s.querySelector(e),l=[],u=null,d=`library`,f=null,p=``,m=0,h=!1,g=e=>{c(`#asset-status`).textContent=e},_=()=>{c(`#insert-image`).disabled=d===`library`&&!u,c(`#asset-selection`).textContent=d===`url`?`Внешний HTTPS-адрес`:u?.name||`Выберите фото из библиотеки`;for(let e of s.querySelectorAll(`[data-asset-id]`))e.setAttribute(`aria-pressed`,String(e.dataset.assetId===u?.id))},v=()=>{let e=c(`#asset-library`);e.replaceChildren(),c(`#asset-count`).textContent=String(l.length);let t=c(`#asset-search`).value.trim().toLocaleLowerCase(`ru`),n=l.filter(e=>e.name.toLocaleLowerCase(`ru`).includes(t));for(let t of n){let n=document.createElement(`button`);n.type=`button`,n.className=`asset-card`,n.dataset.assetId=t.id,n.setAttribute(`aria-label`,`Выбрать `+t.name);let r=document.createElement(`img`);r.src=t.url,r.alt=``,r.loading=`lazy`;let i=document.createElement(`span`);i.className=`asset-card-info`;let a=document.createElement(`strong`);a.textContent=t.name,a.title=t.name;let o=document.createElement(`small`);o.textContent=`${t.width} × ${t.height} · ${Math.ceil(t.size/1024)} КБ`,i.append(a,o),n.append(r,i),e.append(n)}if(!n.length){let t=document.createElement(`div`);t.className=`asset-library-empty`,t.textContent=l.length?`Ничего не найдено. Попробуйте другое имя.`:`Здесь будут фотографии вашего сайта. Загрузите первую с компьютера.`,e.append(t)}_()},y=async()=>{let e=++m;c(`#refresh-assets`).disabled=!0,g(`Загружаем библиотеку сайта…`);try{let r=await n(`/projects/${t}/assets`);if(e!==m)return;l=r,u=l.find(e=>e.id===u?.id)||l.find(e=>e.url===p)||null,v(),g(l.length?`Доступно изображений: `+l.length:`Библиотека пока пуста.`)}catch(t){e===m&&g(`Не удалось загрузить библиотеку: `+t.message)}finally{e===m&&(c(`#refresh-assets`).disabled=!1)}},b=e=>{d=e,c(`#image-library-panel`).hidden=e!==`library`;let t=c(`#image-url-panel`);t&&(t.hidden=e!==`url`);for(let t of s.querySelectorAll(`[data-image-source]`))t.setAttribute(`aria-pressed`,String(t.dataset.imageSource===e));_()},x=()=>{let e=u?.url;if(d===`url`){if(!c(`#image-form`).reportValidity())return;e=c(`#image-form`).elements.src.value.trim()}if(!e)return;let t=c(`#image-alt`).value.trim()||u?.name||``,n=f;if(n){let r=n.options?.target;n.select({type:`image`,src:e,name:u?.name||`Изображение`},!0),r?.is(`image`)&&r.addAttributes({alt:t})}else i(e,t,u?.name||``);s.close()},C=async e=>{if(!h&&e){if(![`image/png`,`image/jpeg`,`image/gif`,`image/webp`].includes(e.type))g(`Выберите PNG, JPEG, WebP или GIF.`);else if(e.size>4194304)g(`Размер файла превышает 4 МБ. Выберите файл поменьше.`);else{h=!0,c(`#upload-asset`).disabled=!0,g(`Загружаем «`+e.name+`»…`);try{let n=await fetch(`/api/projects/${t}/assets`,{method:`POST`,headers:{"Content-Type":`application/octet-stream`,"X-CSRF-Token":r(),"X-Asset-Name":encodeURIComponent(e.name)},body:e}),i=await n.json();if(!n.ok)throw Error(i.error||`HTTP ${n.status}`);u=i,c(`#asset-search`).value=``,b(`library`),await y(),g(`Фото загружено и выбрано. Нажмите «Вставить изображение».`),a(`Изображение сохранено в библиотеке сайта`)}catch(e){g(`Не удалось загрузить фото: `+e.message)}finally{h=!1,c(`#upload-asset`).disabled=!1,c(`#asset-file`).value=``}}}};c(`#upload-asset`).onclick=()=>c(`#asset-file`).click(),c(`#asset-file`).onchange=e=>C(e.target.files?.[0]),c(`#asset-search`).oninput=v,c(`#refresh-assets`).onclick=y,c(`#asset-library`).onclick=e=>{let t=e.target.closest(`[data-asset-id]`);t&&(u=l.find(e=>e.id===t.dataset.assetId),_())};for(let e of s.querySelectorAll(`[data-image-source]`))e.onclick=()=>b(e.dataset.imageSource);let w=c(`#image-form`);w&&(w.onsubmit=e=>{e.preventDefault(),x()}),c(`#insert-image`).onclick=x,c(`#cancel-image`).onclick=c(`#close-image`).onclick=()=>s.close(),s.addEventListener(`close`,()=>{let e=f;f=null,m++,c(`#refresh-assets`).disabled=!1,e&&e.close()});let T=c(`#asset-drop-zone`);return T.ondragover=e=>{e.preventDefault(),e.stopPropagation(),T.classList.add(`drag-over`)},T.ondragleave=()=>T.classList.remove(`drag-over`),T.ondrop=e=>{e.preventDefault(),e.stopPropagation(),T.classList.remove(`drag-over`),e.dataTransfer.files.length===1?C(e.dataTransfer.files[0]):g(`Перетащите одно изображение за раз.`)},{open(e=null,t=`Выберите изображение`,n=`Вставить изображение`){f=e,p=e?.options?.target?.getSrc?.()||``,u=null,c(`#asset-search`).value=``,c(`#image-form`)?.reset(),p.startsWith(`https://`)&&c(`#image-form`)&&(c(`#image-form`).elements.src.value=p),c(`#image-alt`).value=e?.options?.target?.getAttributes?.().alt||``,c(`#image-dialog-title`).textContent=t,c(`#insert-image`).textContent=e?`Использовать изображение`:n,b(`library`),s.open||s.showModal(),y()}}}function kt(e,t){let n=document.querySelector(`.publication-actions`);if(!n)return;let r=document.createElement(`button`);r.type=`button`,r.className=`secondary-link`,r.textContent=`Заявки`,r.setAttribute(`aria-haspopup`,`dialog`);let i=document.createElement(`dialog`);i.id=`form-inbox-dialog`,i.setAttribute(`aria-labelledby`,`form-inbox-title`),i.innerHTML=`<div class="form-inbox-header"><div><p class="eyebrow">ОБРАЩЕНИЯ С САЙТА</p><h2 id="form-inbox-title">Заявки</h2></div><button type="button" aria-label="Закрыть">×</button></div><p class="form-inbox-status" role="status" aria-live="polite"></p><div class="form-inbox-list"></div>`,document.body.append(i);let a=i.querySelector(`.form-inbox-status`),o=i.querySelector(`.form-inbox-list`),s=async()=>{a.textContent=`Загружаем заявки…`,o.replaceChildren();try{let{submissions:n=[]}=await t(`/projects/${e}/form-submissions`);a.textContent=n.length?`Последние ${n.length} заявок`:`Пока нет заявок. Опубликованные формы появятся здесь после первой отправки.`;for(let r of n){let n=document.createElement(`article`);n.className=`form-inbox-item`;let i=document.createElement(`div`);i.className=`form-inbox-item-header`;let c=document.createElement(`strong`);c.textContent=`${r.pagePath||`Страница`} · ${r.createdAt||``}`;let l=document.createElement(`button`);l.type=`button`,l.className=`form-inbox-delete`,l.textContent=`Удалить`,l.addEventListener(`click`,async()=>{if(window.confirm(`Удалить эту заявку без возможности восстановления?`)){l.disabled=!0;try{await t(`/projects/${e}/form-submissions/${r.id}/delete`,`POST`,{}),await s()}catch(e){l.disabled=!1,a.textContent=e.message||`Не удалось удалить заявку.`}}}),i.append(c,l),n.append(i);for(let[e,t]of Object.entries(r.fields||{})){let r=document.createElement(`p`),i=document.createElement(`span`);i.textContent=`${e}: `,r.append(i,document.createTextNode(String(t))),n.append(r)}o.append(n)}}catch(e){a.textContent=e.message||`Не удалось загрузить заявки.`}};r.addEventListener(`click`,()=>{i.showModal(),s()}),i.querySelector(`[aria-label="Закрыть"]`).addEventListener(`click`,()=>i.close()),i.addEventListener(`click`,e=>{e.target===i&&i.close()}),n.prepend(r)}var At=o(((e,t,n)=>{(function(n,r){typeof e==`object`&&typeof t==`object`?t.exports=r():typeof define==`function`&&define.amd?define([],r):typeof e==`object`?e["grapesjs-plugin-forms"]=r():n[`grapesjs-plugin-forms`]=r()})(typeof globalThis<`u`?globalThis:typeof window<`u`?window:n,(()=>(()=>{var e={d:(t,n)=>{for(var r in n)e.o(n,r)&&!e.o(t,r)&&Object.defineProperty(t,r,{enumerable:!0,get:n[r]})},o:(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r:e=>{typeof Symbol<`u`&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:`Module`}),Object.defineProperty(e,"__esModule",{value:!0})}},t={};e.r(t),e.d(t,{default:()=>p});var n=`form`,r=`input`,i=`textarea`,a=`select`,o=`checkbox`,s=`radio`,c=`button`,l=`label`,u=`option`,d=function(){return d=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},d.apply(this,arguments)},f=function(){return f=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},f.apply(this,arguments)};let p=function(e,t){t===void 0&&(t={});var p=f({blocks:[`form`,`input`,`textarea`,`select`,`button`,`label`,`checkbox`,`radio`],category:{id:`forms`,label:`Forms`},block:function(){return{}}},t);(function(e){var t=e.Components,d={name:`name`},f={name:`placeholder`},p={type:`checkbox`,name:`required`},m=function(e,t){return{type:u,content:t,attributes:{value:e}}},h=function(t){e.Commands.isActive(`preview`)||t.preventDefault()};t.addType(n,{isComponent:function(e){return e.tagName==`FORM`},model:{defaults:{tagName:`form`,droppable:`:not(form)`,draggable:`:not(form)`,attributes:{method:`get`},traits:[{type:`select`,name:`method`,options:[{value:`get`,name:`GET`},{value:`post`,name:`POST`}]},{name:`action`}]}},view:{events:{submit:function(e){return e.preventDefault()}}}}),t.addType(r,{isComponent:function(e){return e.tagName==`INPUT`},model:{defaults:{tagName:`input`,droppable:!1,highlightable:!1,attributes:{type:`text`},traits:[d,f,{type:`select`,name:`type`,options:[{value:`text`},{value:`email`},{value:`password`},{value:`number`}]},p]}},extendFnView:[`updateAttributes`],view:{updateAttributes:function(){this.el.setAttribute(`autocomplete`,`off`)}}}),t.addType(i,{extend:r,isComponent:function(e){return e.tagName==`TEXTAREA`},model:{defaults:{tagName:`textarea`,attributes:{},traits:[d,f,p]}}}),t.addType(u,{isComponent:function(e){return e.tagName==`OPTION`},model:{defaults:{tagName:`option`,layerable:!1,droppable:!1,draggable:!1,highlightable:!1}}}),t.addType(a,{isComponent:function(e){return e.tagName==`SELECT`},model:{defaults:{tagName:`select`,droppable:!1,highlightable:!1,components:[m(`opt1`,`Option 1`),m(`opt2`,`Option 2`)],traits:[d,{name:`options`,type:`select-options`},p]}},view:{events:{mousedown:h}}}),t.addType(o,{extend:r,isComponent:function(e){return e.tagName==`INPUT`&&e.type==`checkbox`},model:{defaults:{copyable:!1,attributes:{type:`checkbox`},traits:[{name:`id`},d,{name:`value`},p,{type:`checkbox`,name:`checked`}]}},view:{events:{click:h},init:function(){this.listenTo(this.model,`change:attributes:checked`,this.handleChecked)},handleChecked:function(){this.el.checked=!!this.model.get(`attributes`)?.checked}}}),t.addType(s,{extend:o,isComponent:function(e){return e.tagName==`INPUT`&&e.type==`radio`},model:{defaults:{attributes:{type:`radio`}}}}),t.addType(c,{extend:r,isComponent:function(e){return e.tagName==`BUTTON`},model:{defaults:{tagName:`button`,attributes:{type:`button`},text:`Send`,traits:[{name:`text`,changeProp:!0},{type:`select`,name:`type`,options:[{value:`button`},{value:`submit`},{value:`reset`}]}]},init:function(){var e=this.components(),t=e.length===1&&e.models[0],n=t&&t.is(`textnode`)&&t.get(`content`)||``,r=n||this.get(`text`);this.set(`text`,r),this.on(`change:text`,this.__onTextChange),r!==n&&this.__onTextChange()},__onTextChange:function(){this.components(this.get(`text`))}},view:{events:{click:h}}}),t.addType(l,{extend:`text`,isComponent:function(e){return e.tagName==`LABEL`},model:{defaults:{tagName:`label`,components:`Label`,traits:[{name:`for`}]}}})})(e),function(e){e.TraitManager.addType(`select-options`,{events:{keyup:`onChange`},onValueChange:function(){for(var e,t=this.model,n=this.target,r=t.get(`value`).trim().split(`
`),i=[],a=0;a<r.length;a++){var o=r[a].split(`::`);i.push({type:u,components:o[1]||o[0],attributes:{value:o[0]}})}n.components().reset(i),(e=n.view)==null||e.render()},getInputEl:function(){if(!this.$input){for(var e=[],t=this.target.components(),n=0;n<t.length;n++){var r=t.models[n],i=r.get(`attributes`)?.value||``,a=r.components().models[0],o=a&&a.get(`content`)||``;e.push(`${i}::${o}`)}var s=document.createElement(`textarea`);s.value=e.join(`
`),this.$input=s}return this.$input}})}(e),function(e,t){var u=t,f=e.BlockManager,p=function(e,n){u.blocks?.indexOf(e)>=0&&f.add(e,d(d(d({},n),{category:u.category,select:!0}),t.block(e)))};p(n,{label:`Form`,media:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 5.5c0-.3-.5-.5-1.3-.5H3.4c-.8 0-1.3.2-1.3.5v3c0 .3.5.5 1.3.5h17.4c.8 0 1.3-.2 1.3-.5v-3zM21 8H3V6h18v2zM22 10.5c0-.3-.5-.5-1.3-.5H3.4c-.8 0-1.3.2-1.3.5v3c0 .3.5.5 1.3.5h17.4c.8 0 1.3-.2 1.3-.5v-3zM21 13H3v-2h18v2z"/><rect width="10" height="3" x="2" y="15" rx=".5"/></svg>`,content:{type:n,components:[{components:[{type:l,components:`Name`},{type:r}]},{components:[{type:l,components:`Email`},{type:r,attributes:{type:`email`}}]},{components:[{type:l,components:`Gender`},{type:o,attributes:{value:`M`}},{type:l,components:`M`},{type:o,attributes:{value:`F`}},{type:l,components:`F`}]},{components:[{type:l,components:`Message`},{type:i}]},{components:[{type:c}]}]}}),p(r,{label:`Input`,media:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 9c0-.6-.5-1-1.3-1H3.4C2.5 8 2 8.4 2 9v6c0 .6.5 1 1.3 1h17.4c.8 0 1.3-.4 1.3-1V9zm-1 6H3V9h18v6z"/><path d="M4 10h1v4H4z"/></svg>`,content:{type:r}}),p(i,{label:`Textarea`,media:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 7.5c0-.9-.5-1.5-1.3-1.5H3.4C2.5 6 2 6.6 2 7.5v9c0 .9.5 1.5 1.3 1.5h17.4c.8 0 1.3-.6 1.3-1.5v-9zM21 17H3V7h18v10z"/><path d="M4 8h1v4H4zM19 7h1v10h-1zM20 8h1v1h-1zM20 15h1v1h-1z"/></svg>`,content:{type:i}}),p(a,{label:`Select`,media:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 9c0-.6-.5-1-1.3-1H3.4C2.5 8 2 8.4 2 9v6c0 .6.5 1 1.3 1h17.4c.8 0 1.3-.4 1.3-1V9zm-1 6H3V9h18v6z"/><path d="M18.5 13l1.5-2h-3zM4 11.5h11v1H4z"/></svg>`,content:{type:a}}),p(c,{label:`Button`,media:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 9c0-.6-.5-1-1.3-1H3.4C2.5 8 2 8.4 2 9v6c0 .6.5 1 1.3 1h17.4c.8 0 1.3-.4 1.3-1V9zm-1 6H3V9h18v6z"/><path d="M4 11.5h16v1H4z"/></svg>`,content:{type:c}}),p(l,{label:`Label`,media:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M22 11.9c0-.6-.5-.9-1.3-.9H3.4c-.8 0-1.3.3-1.3.9V17c0 .5.5.9 1.3.9h17.4c.8 0 1.3-.4 1.3-.9V12zM21 17H3v-5h18v5z"/><rect width="14" height="5" x="2" y="5" rx=".5"/><path d="M4 13h1v3H4z"/></svg>`,content:{type:l}}),p(o,{label:`Checkbox`,media:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M10 17l-5-5 1.41-1.42L10 14.17l7.59-7.59L19 8m0-5H5c-1.11 0-2 .89-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5a2 2 0 0 0-2-2z"></path></svg>`,content:{type:o}}),p(s,{label:`Radio`,media:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8m0-18C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2m0 5c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5z"></path></svg>`,content:{type:s}})}(e,p)};return t})()))})),jt=o(((e,t,n)=>{(function(n,r){typeof e==`object`&&typeof t==`object`?t.exports=r():typeof define==`function`&&define.amd?define([],r):typeof e==`object`?e["gjs-blocks-basic"]=r():n[`gjs-blocks-basic`]=r()})(typeof globalThis<`u`?globalThis:typeof window<`u`?window:n,(()=>(()=>{var e={d:(t,n)=>{for(var r in n)e.o(n,r)&&!e.o(t,r)&&Object.defineProperty(t,r,{enumerable:!0,get:n[r]})},o:(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r:e=>{typeof Symbol<`u`&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:`Module`}),Object.defineProperty(e,"__esModule",{value:!0})}},t={};e.r(t),e.d(t,{default:()=>i});var n=function(){return n=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},n.apply(this,arguments)},r=function(){return r=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},r.apply(this,arguments)};let i=function(e,t){t===void 0&&(t={}),function(e,t){var r=e.BlockManager,i=t.category,a=t.blocks,o=t.stylePrefix,s=t.flexGrid,c=t.rowHeight,l=t.addBasicStyle,u=`${o}row`,d=`${o}cell`,f=s?`
    .${u} {
      display: flex;
      justify-content: flex-start;
      align-items: stretch;
      flex-wrap: nowrap;
      padding: 10px;
    }
    @media (max-width: 768px) {
      .${u} {
        flex-wrap: wrap;
      }
    }`:`
    .${u} {
      display: table;
      padding: 10px;
      width: 100%;
    }
    @media (max-width: 768px) {
      .${o}cell, .${o}cell30, .${o}cell70 {
        width: 100%;
        display: block;
      }
    }`,p=s?`
    .${d} {
      min-height: ${c}px;
      flex-grow: 1;
      flex-basis: 100%;
    }`:`
    .${d} {
      width: 8%;
      display: table-cell;
      height: ${c}px;
    }`,m=`
  .${o}cell30 {
    width: 30%;
  }`,h=`
  .${o}cell70 {
    width: 70%;
  }`,g=1,_={tl:0,tc:0,tr:0,cl:0,cr:0,bl:0,br:0,minDim:g},v=n(n({},_),{cr:1,bc:0,currentUnit:1,minDim:g,step:.2});s&&(v.keyWidth=`flex-basis`);var y={class:u,"data-gjs-droppable":`.${d}`,"data-gjs-resizable":_,"data-gjs-name":`Row`},b={class:d,"data-gjs-draggable":`.${u}`,"data-gjs-resizable":v,"data-gjs-name":`Cell`};s&&(b[`data-gjs-unstylable`]=[`width`],b[`data-gjs-stylable-require`]=[`flex-basis`]);var x=[`.${u}`,`.${d}`];e.on(`selector:add`,(function(e){return x.indexOf(e.getFullName())>=0&&e.set(`private`,1)}));var S=function(e){var t=[];for(var n in e){var r=e[n];r=r instanceof Array||r instanceof Object?JSON.stringify(r):r,t.push(`${n}=${`'${r}'`}`)}return t.length?` ${t.join(` `)}`:``},C=function(e){return a.indexOf(e)>=0},w=S(y),T=S(b),E={category:i,select:!0};C(`column1`)&&r.add(`column1`,n(n({},E),{label:t.labelColumn1,media:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M2 20h20V4H2v16Zm-1 0V4a1 1 0 0 1 1-1h20a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1Z"/>
      </svg>`,content:`<div ${w}>
        <div ${T}></div>
      </div>
      ${l?`<style>
          ${f}
          ${p}
        </style>`:``}`})),C(`column2`)&&r.add(`column2`,n(n({},E),{label:t.labelColumn2,media:`<svg viewBox="0 0 23 24">
        <path fill="currentColor" d="M2 20h8V4H2v16Zm-1 0V4a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1ZM13 20h8V4h-8v16Zm-1 0V4a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-8a1 1 0 0 1-1-1Z"/>
      </svg>`,content:`<div ${w}>
        <div ${T}></div>
        <div ${T}></div>
      </div>
      ${l?`<style>
          ${f}
          ${p}
        </style>`:``}`})),C(`column3`)&&r.add(`column3`,n(n({},E),{label:t.labelColumn3,media:`<svg viewBox="0 0 23 24">
        <path fill="currentColor" d="M2 20h4V4H2v16Zm-1 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1ZM17 20h4V4h-4v16Zm-1 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1ZM9.5 20h4V4h-4v16Zm-1 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1h-4a1 1 0 0 1-1-1Z"/>
      </svg>`,content:`<div ${w}>
        <div ${T}></div>
        <div ${T}></div>
        <div ${T}></div>
      </div>
      ${l?`<style>
          ${f}
          ${p}
        </style>`:``}`})),C(`column3-7`)&&r.add(`column3-7`,n(n({},E),{label:t.labelColumn37,media:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M2 20h5V4H2v16Zm-1 0V4a1 1 0 0 1 1-1h5a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1ZM10 20h12V4H10v16Zm-1 0V4a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H10a1 1 0 0 1-1-1Z"/>
      </svg>`,content:`<div ${w}>
        <div ${T} style='${s?`flex-basis`:`width`}: 30%;'></div>
        <div ${T} style='${s?`flex-basis`:`width`}: 70%;'></div>
      </div>
      ${l?`<style>
          ${f}
          ${p}
          ${m}
          ${h}
        </style>`:``}`})),C(`text`)&&r.add(`text`,n(n({},E),{activate:!0,label:t.labelText,media:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M18.5,4L19.66,8.35L18.7,8.61C18.25,7.74 17.79,6.87 17.26,6.43C16.73,6 16.11,6 15.5,6H13V16.5C13,17 13,17.5 13.33,17.75C13.67,18 14.33,18 15,18V19H9V18C9.67,18 10.33,18 10.67,17.75C11,17.5 11,17 11,16.5V6H8.5C7.89,6 7.27,6 6.74,6.43C6.21,6.87 5.75,7.74 5.3,8.61L4.34,8.35L5.5,4H18.5Z" />
      </svg>`,content:{type:`text`,content:`Insert your text here`,style:{padding:`10px`}}})),C(`link`)&&r.add(`link`,n(n({},E),{label:t.labelLink,media:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M3.9,12C3.9,10.29 5.29,8.9 7,8.9H11V7H7A5,5 0 0,0 2,12A5,5 0 0,0 7,17H11V15.1H7C5.29,15.1 3.9,13.71 3.9,12M8,13H16V11H8V13M17,7H13V8.9H17C18.71,8.9 20.1,10.29 20.1,12C20.1,13.71 18.71,15.1 17,15.1H13V17H17A5,5 0 0,0 22,12A5,5 0 0,0 17,7Z" />
      </svg>`,content:{type:`link`,content:`Link`,style:{color:`#d983a6`}}})),C(`image`)&&r.add(`image`,n(n({},E),{activate:!0,label:t.labelImage,media:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M21,3H3C2,3 1,4 1,5V19A2,2 0 0,0 3,21H21C22,21 23,20 23,19V5C23,4 22,3 21,3M5,17L8.5,12.5L11,15.5L14.5,11L19,17H5Z" />
      </svg>`,content:{style:{color:`black`},type:`image`}})),C(`video`)&&r.add(`video`,n(n({},E),{label:t.labelVideo,media:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M10,15L15.19,12L10,9V15M21.56,7.17C21.69,7.64 21.78,8.27 21.84,9.07C21.91,9.87 21.94,10.56 21.94,11.16L22,12C22,14.19 21.84,15.8 21.56,16.83C21.31,17.73 20.73,18.31 19.83,18.56C19.36,18.69 18.5,18.78 17.18,18.84C15.88,18.91 14.69,18.94 13.59,18.94L12,19C7.81,19 5.2,18.84 4.17,18.56C3.27,18.31 2.69,17.73 2.44,16.83C2.31,16.36 2.22,15.73 2.16,14.93C2.09,14.13 2.06,13.44 2.06,12.84L2,12C2,9.81 2.16,8.2 2.44,7.17C2.69,6.27 3.27,5.69 4.17,5.44C4.64,5.31 5.5,5.22 6.82,5.16C8.12,5.09 9.31,5.06 10.41,5.06L12,5C16.19,5 18.8,5.16 19.83,5.44C20.73,5.69 21.31,6.27 21.56,7.17Z" />
      </svg>`,content:{type:`video`,src:`img/video2.webm`,style:{height:`350px`,width:`615px`}}})),C(`map`)&&r.add(`map`,n(n({},E),{label:t.labelMap,media:`<svg viewBox="0 0 24 24">
        <path fill="currentColor" d="M20.5,3L20.34,3.03L15,5.1L9,3L3.36,4.9C3.15,4.97 3,5.15 3,5.38V20.5A0.5,0.5 0 0,0 3.5,21L3.66,20.97L9,18.9L15,21L20.64,19.1C20.85,19.03 21,18.85 21,18.62V3.5A0.5,0.5 0 0,0 20.5,3M10,5.47L14,6.87V18.53L10,17.13V5.47M5,6.46L8,5.45V17.15L5,18.31V6.46M19,17.54L16,18.55V6.86L19,5.7V17.54Z" />
      </svg>`,content:{type:`map`,style:{height:`350px`}}}))}(e,r({blocks:[`column1`,`column2`,`column3`,`column3-7`,`text`,`link`,`image`,`video`,`map`],flexGrid:!1,stylePrefix:`gjs-`,addBasicStyle:!0,category:`Basic`,labelColumn1:`1 Column`,labelColumn2:`2 Columns`,labelColumn3:`3 Columns`,labelColumn37:`2 Columns 3/7`,labelText:`Text`,labelLink:`Link`,labelImage:`Image`,labelVideo:`Video`,labelMap:`Map`,rowHeight:75},t))};return t})()))})),Mt=o(((e,t,n)=>{(function(n,r){typeof e==`object`&&typeof t==`object`?t.exports=r():typeof define==`function`&&define.amd?define([],r):typeof e==`object`?e["grapesjs-blocks-flexbox"]=r():n[`grapesjs-blocks-flexbox`]=r()})(typeof globalThis<`u`?globalThis:typeof window<`u`?window:n,(()=>(()=>{var e={d:(t,n)=>{for(var r in n)e.o(n,r)&&!e.o(t,r)&&Object.defineProperty(t,r,{enumerable:!0,get:n[r]})},o:(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r:e=>{typeof Symbol<`u`&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:`Module`}),Object.defineProperty(e,"__esModule",{value:!0})}},t={};e.r(t),e.d(t,{default:()=>i});var n=function(){return n=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},n.apply(this,arguments)},r=function(){return r=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},r.apply(this,arguments)};let i=function(e,t){t===void 0&&(t={}),function(e,t){t===void 0&&(t={});var r=e.BlockManager,i=t.stylePrefix,a=`${i}row`,o=`${i}cell`,s=t.labelRow,c=t.labelColumn,l=function(e){var t=[];for(var n in e){var r=e[n],i=r instanceof Array||r instanceof Object;r=i?JSON.stringify(r):r,t.push(`${n}=${i?`'${r}'`:`"${r}"`}`)}return t.length?` ${t.join(` `)}`:``},u=1,d={tl:0,tc:0,tr:0,cl:0,cr:0,bl:0,br:0,minDim:u},f=n(n({},d),{cr:1,bc:0,keyWidth:`flex-basis`,currentUnit:1,minDim:u,step:.2}),p={class:a,"data-gjs-droppable":`.${o}`,"data-gjs-resizable":d,"data-gjs-custom-name":s},m={class:o,"data-gjs-draggable":`.${a}`,"data-gjs-resizable":f,"data-gjs-custom-name":c,"data-gjs-unstylable":[`width`],"data-gjs-stylable-require":[`flex-basis`]},h=[`.${a}`,`.${o}`];e.on(`selector:add`,(function(e){return h.indexOf(e.getFullName())>=0&&e.set(`private`,1)}));var g=l(p),_=l(m),v=`
    .${a} {
      display: flex;
      justify-content: flex-start;
      align-items: stretch;
      flex-wrap: nowrap;
      padding: 10px;
    }
    @media (max-width: 768px) {
      .${a} {
        flex-wrap: wrap;
      }
    }
    `,y=`
    .${o} {
      min-height: 75px;
      flex-grow: 1;
      flex-basis: 100%;
    }`;r.add(`flexbox`,n({label:`Flexbox`,category:`Basic`,attributes:{class:`gjs-fonts gjs-f-b2`},content:`
        <div ${g}>
          <div ${_}></div>
          <div ${_}></div>
        </div>
        <style>
          ${v}
          ${y}
        </style>
        `},t.flexboxBlock))}(e,r({flexboxBlock:{},stylePrefix:``,labelRow:`Row`,labelColumn:`Column`},t))};return t})()))})),Nt=o(((e,t,n)=>{(function(n,r){typeof e==`object`&&typeof t==`object`?t.exports=r():typeof define==`function`&&define.amd?define([],r):typeof e==`object`?e["grapesjs-style-gradient"]=r():n[`grapesjs-style-gradient`]=r()})(typeof globalThis<`u`?globalThis:typeof window<`u`?window:n,(()=>(()=>{var e={9:function(e){e.exports=function(e){function t(r){if(n[r])return n[r].exports;var i=n[r]={i:r,l:!1,exports:{}};return e[r].call(i.exports,i,i.exports,t),i.l=!0,i.exports}var n={};return t.m=e,t.c=n,t.d=function(e,n,r){t.o(e,n)||Object.defineProperty(e,n,{configurable:!1,enumerable:!0,get:r})},t.n=function(e){var n=e&&e.__esModule?function(){return e.default}:function(){return e};return t.d(n,`a`,n),n},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p=``,t(t.s=1)}([function(e,t,n){function r(e,t,n){t=t.split(/\s+/);for(var r=0;r<t.length;++r)e.addEventListener(t[r],n)}function i(e,t,n){t=t.split(/\s+/);for(var r=0;r<t.length;++r)e.removeEventListener(t[r],n)}Object.defineProperty(t,"__esModule",{value:!0}),t.on=r,t.off=i,t.isFunction=function(e){return typeof e==`function`},t.isDef=function(e){return e!==void 0},t.getPointerEvent=function(e){return e.touches&&e.touches[0]||e}},function(e,t,n){var r=function(e){return e&&e.__esModule?e:{default:e}}(n(2));e.exports=function(e){return new r.default(e)}},function(e,t,n){function r(e){return e&&e.__esModule?e:{default:e}}function i(e){if(Array.isArray(e)){for(var t=0,n=Array(e.length);t<e.length;t++)n[t]=e[t];return n}return Array.from(e)}function a(e,t){if(!(e instanceof t))throw TypeError(`Cannot call a class as a function`)}function o(e,t){if(!e)throw ReferenceError(`this hasn't been initialised - super() hasn't been called`);return!t||typeof t!=`object`&&typeof t!=`function`?e:t}function s(e,t){if(typeof t!=`function`&&t!==null)throw TypeError(`Super expression must either be null or a function, not `+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}Object.defineProperty(t,"__esModule",{value:!0});var c=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,`value`in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),l=r(n(3)),u=r(n(4)),d=n(0),f=function(e,t){return e.position-t.position},p=function(e){return e+`-gradient(`};t.default=function(e){function t(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{};a(this,t);var n=o(this,(t.__proto__||Object.getPrototypeOf(t)).call(this));e=Object.assign({},e);var r={pfx:`grp`,el:`.grp`,colorEl:``,min:0,max:100,direction:`90deg`,type:`linear`,height:`30px`,width:`100%`,emptyColor:`#000`,onValuePos:function(e){return parseInt(e)}};for(var i in r)i in e||(e[i]=r[i]);var s=e.el;if(!((s=typeof s==`string`?document.querySelector(s):s)instanceof HTMLElement))throw`Element not found, given `+s;return n.el=s,n.handlers=[],n.options=e,n.on(`handler:color:change`,(function(e,t){return n.change(t)})),n.on(`handler:position:change`,(function(e,t){return n.change(t)})),n.on(`handler:remove`,(function(e){return n.change(1)})),n.on(`handler:add`,(function(e){return n.change(1)})),n.render(),n}return s(t,e),c(t,[{key:`destroy`,value:function(){var e=this;this.clear(),this.e={},[`el`,`handlers`,`options`,`colorPicker`].forEach((function(t){return e[t]=0})),[`previewEl`,`wrapperEl`,`sandEl`].forEach((function(t){var n=e[t];n&&n.parentNode&&n.parentNode.removeChild(n),delete e[t]}))}},{key:`setColorPicker`,value:function(e){this.colorPicker=e}},{key:`getValue`,value:function(e,t){var n=this.getColorValue(),r=e||this.getType(),i=[`top`,`left`,`bottom`,`right`,`center`],a=t||this.getDirection();return[`linear`,`repeating-linear`].indexOf(r)>=0&&i.indexOf(a)>=0&&(a=a===`center`?`to right`:`to `+a),[`radial`,`repeating-radial`].indexOf(r)>=0&&i.indexOf(a)>=0&&(a=`circle at `+a),n?r+`-gradient(`+a+`, `+n+`)`:``}},{key:`getSafeValue`,value:function(e,t){var n=this.previewEl,r=this.getValue(e,t);if(!this.sandEl&&(this.sandEl=document.createElement(`div`)),!n||!r)return``;for(var a=this.sandEl.style,o=[r].concat(i(this.getPrefixedValues(e,t))),s=void 0,c=0;c<o.length&&(s=o[c],a.backgroundImage=s,a.backgroundImage!=s);c++);return a.backgroundImage}},{key:`setValue`,value:function(){var e=this,t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:``,n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{},r=this.type,i=this.direction,a=t.indexOf(`(`)+1,o=t.lastIndexOf(`)`),s=t.substring(a,o),c=s.split(/,(?![^(]*\)) /);if(this.clear(n),s){c.length>2&&(i=c.shift());var l=void 0;[`repeating-linear`,`repeating-radial`,`linear`,`radial`].forEach((function(e){t.indexOf(p(e))>-1&&!l&&(l=1,r=e)})),this.setDirection(i,n),this.setType(r,n),c.forEach((function(t){var r=t.split(` `),i=parseFloat(r.pop()),a=r.join(``);e.addHandler(i,a,0,n)})),this.updatePreview()}else this.updatePreview()}},{key:`getColorValue`,value:function(){var e=this.handlers;return e.sort(f),(e=e.length==1?[e[0],e[0]]:e).map((function(e){return e.getValue()})).join(`, `)}},{key:`getPrefixedValues`,value:function(e,t){var n=this.getValue(e,t);return[`-moz-`,`-webkit-`,`-o-`,`-ms-`].map((function(e){return``+e+n}))}},{key:`change`,value:function(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:1,t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};this.updatePreview(),!t.silent&&this.emit(`change`,e)}},{key:`setDirection`,value:function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};this.options.direction=e;var n=t.complete,r=n===void 0?1:n;this.change(r,t)}},{key:`getDirection`,value:function(){return this.options.direction}},{key:`setType`,value:function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:{};this.options.type=e;var n=t.complete,r=n===void 0?1:n;this.change(r,t)}},{key:`getType`,value:function(){return this.options.type}},{key:`addHandler`,value:function(e,t){var n=arguments.length>2&&arguments[2]!==void 0?arguments[2]:1,r=arguments.length>3&&arguments[3]!==void 0?arguments[3]:{},i=new u.default(this,e,t,n,r);return!r.silent&&this.emit(`handler:add`,i),i}},{key:`getHandler`,value:function(e){return this.handlers[e]}},{key:`getHandlers`,value:function(){return this.handlers}},{key:`clear`,value:function(){for(var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},t=this.handlers,n=t.length-1;n>=0;n--)t[n].remove(e)}},{key:`getSelected`,value:function(){for(var e=this.getHandlers(),t=0;t<e.length;t++){var n=e[t];if(n.isSelected())return n}return null}},{key:`updatePreview`,value:function(){var e=this.previewEl;e&&(e.style.backgroundImage=this.getValue(`linear`,`to right`))}},{key:`initEvents`,value:function(){var e=this,t=this.previewEl;t&&(0,d.on)(t,`click`,(function(n){var r=e.options,i=r.min,a=r.max,o={w:t.clientWidth,h:t.clientHeight},s=n.offsetX-t.clientLeft,c=n.offsetY-t.clientTop,l=s/o.w*100;if(!(l>a||l<i||c>o.h||c<0)){var u=document.createElement(`canvas`),d=u.getContext(`2d`);u.width=o.w,u.height=o.h;var f=d.createLinearGradient(0,0,o.w,o.h);e.getHandlers().forEach((function(e){return f.addColorStop(e.position/100,e.color)})),d.fillStyle=f,d.fillRect(0,0,u.width,u.height),u.style.background=`black`;var p=u.getContext(`2d`).getImageData(s,c,1,1).data,m=`rgba(`+p[0]+`, `+p[1]+`, `+p[2]+`, `+p[3]+`)`,h=m==`rgba(0, 0, 0, 0)`?r.emptyColor:m;e.addHandler(l,h)}}))}},{key:`render`,value:function(){var e=this.options,t=this.el,n=e.pfx,r=e.height,i=e.width;if(t){var a=n+`-wrapper`,o=n+`-preview`;t.innerHTML=`
      <div class="`+a+`">
        <div class="`+o+`"></div>
      </div>
    `;var s=t.querySelector(`.`+a),c=t.querySelector(`.`+o),l=s.style;l.position=`relative`,this.wrapperEl=s,this.previewEl=c,r&&(l.height=r),i&&(l.width=i),this.initEvents(),this.updatePreview()}}}]),t}(l.default)},function(e,t,n){function r(e,t){if(!(e instanceof t))throw TypeError(`Cannot call a class as a function`)}Object.defineProperty(t,"__esModule",{value:!0});var i=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,`value`in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}();t.default=function(){function e(){r(this,e)}return i(e,[{key:`on`,value:function(e,t,n){var r=this.e||={};return(r[e]||(r[e]=[])).push({fn:t,ctx:n}),this}},{key:`once`,value:function(e,t,n){function r(){i.off(e,r),t.apply(n,arguments)}var i=this;return r._=t,this.on(e,r,n)}},{key:`emit`,value:function(e){for(var t=[].slice.call(arguments,1),n=((this.e||={})[e]||[]).slice(),r=0,i=n.length;r<i;r++)n[r].fn.apply(n[r].ctx,t);return this}},{key:`off`,value:function(e,t){var n=this.e||={},r=n[e],i=[];if(r&&t)for(var a=0,o=r.length;a<o;a++)r[a].fn!==t&&r[a].fn._!==t&&i.push(r[a]);return i.length?n[e]=i:delete n[e],this}}]),e}()},function(e,t,n){function r(e,t){if(!(e instanceof t))throw TypeError(`Cannot call a class as a function`)}Object.defineProperty(t,"__esModule",{value:!0});var i=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,`value`in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),a=n(0);t.default=function(){function e(t){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:0,i=arguments.length>2&&arguments[2]!==void 0?arguments[2]:`black`,a=arguments.length>3&&arguments[3]!==void 0?arguments[3]:1,o=arguments.length>4&&arguments[4]!==void 0?arguments[4]:{};r(this,e),t.getHandlers().push(this),this.gp=t,this.position=n,this.color=i,this.selected=0,this.render(),a&&this.select(o)}return i(e,[{key:`toJSON`,value:function(){return{position:this.position,selected:this.selected,color:this.color}}},{key:`setColor`,value:function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1;this.color=e,this.emit(`handler:color:change`,this,t)}},{key:`setPosition`,value:function(e){var t=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1,n=this.getEl();this.position=e,n&&(n.style.left=e+`%`),this.emit(`handler:position:change`,this,t)}},{key:`getColor`,value:function(){return this.color}},{key:`getPosition`,value:function(){var e=this.position,t=this.gp.options.onValuePos;return(0,a.isFunction)(t)?t(e):e}},{key:`isSelected`,value:function(){return!!this.selected}},{key:`getValue`,value:function(){return this.getColor()+` `+this.getPosition()+`%`}},{key:`select`,value:function(){var e=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},t=this.getEl(),n=this.gp.getHandlers();!e.keepSelect&&n.forEach((function(e){return e.deselect()})),this.selected=1;var r=this.getSelectedCls();t&&(t.className+=` `+r),this.emit(`handler:select`,this)}},{key:`deselect`,value:function(){var e=this.getEl();this.selected=0;var t=this.getSelectedCls();e&&(e.className=e.className.replace(t,``).trim()),this.emit(`handler:deselect`,this)}},{key:`getSelectedCls`,value:function(){return this.gp.options.pfx+`-handler-selected`}},{key:`remove`,value:function(){var e=this,t=arguments.length>0&&arguments[0]!==void 0?arguments[0]:{},n=this.cpFn,r=this.getEl(),i=this.gp.getHandlers(),o=i.splice(i.indexOf(this),1)[0];return r&&r.parentNode.removeChild(r),!t.silent&&this.emit(`handler:remove`,o),(0,a.isFunction)(n)&&n(this),[`el`,`gp`].forEach((function(t){return e[t]=0})),o}},{key:`getEl`,value:function(){return this.el}},{key:`initEvents`,value:function(){var e=this,t=this.getEl(),n=this.gp.previewEl,r=this.gp.options,i=r.min,o=r.max,s=t.querySelector(`[data-toggle=handler-close]`),c=t.querySelector(`[data-toggle=handler-color-c]`),l=t.querySelector(`[data-toggle=handler-color-wrap]`),u=t.querySelector(`[data-toggle=handler-color]`),d=t.querySelector(`[data-toggle=handler-drag]`),f=function(t){var n=arguments.length>1&&arguments[1]!==void 0?arguments[1]:1,r=t.target.value;e.setColor(r,n),l&&(l.style.backgroundColor=r)};if(c&&(0,a.on)(c,`click`,(function(e){return e.stopPropagation()})),s&&(0,a.on)(s,`click`,(function(t){t.stopPropagation(),e.remove()})),u&&((0,a.on)(u,`change`,f),(0,a.on)(u,`input`,(function(e){return f(e,0)}))),d){var p=0,m=0,h=0,g={},_={},v={},y=function(t){var n=(0,a.getPointerEvent)(t);h=1,v.x=n.clientX-_.x,v.y=n.clientY-_.y,p=100*v.x,p/=g.w,p=(p=(p=m+p)<i?i:p)>o?o:p,e.setPosition(p,0),e.emit(`handler:drag`,e,p),(0,a.isDef)(t.button)&&t.which===0&&b(t)},b=function t(n){(0,a.off)(document,`touchmove mousemove`,y),(0,a.off)(document,`touchend mouseup`,t),h&&(h=0,e.setPosition(p),e.emit(`handler:drag:end`,e,p))};(0,a.on)(d,`touchstart mousedown`,function(t){if(!(0,a.isDef)(t.button)||t.button===0){e.select();var r=(0,a.getPointerEvent)(t);m=e.position,g.w=n.clientWidth,g.h=n.clientHeight,_.x=r.clientX,_.y=r.clientY,(0,a.on)(document,`touchmove mousemove`,y),(0,a.on)(document,`touchend mouseup`,b),e.emit(`handler:drag:start`,e)}}),(0,a.on)(d,`click`,(function(e){return e.stopPropagation()}))}}},{key:`emit`,value:function(){var e;(e=this.gp).emit.apply(e,arguments)}},{key:`render`,value:function(){var e=this.gp,t=e.options,n=e.previewEl,r=e.colorPicker,i=t.pfx,a=t.colorEl,o=this.getColor();if(n){var s=document.createElement(`div`),c=s.style,l=i+`-handler`;return s.className=l,s.innerHTML=`
      <div class="`+l+`-close-c">
        <div class="`+l+`-close" data-toggle="handler-close">&Cross;</div>
      </div>
      <div class="`+l+`-drag" data-toggle="handler-drag"></div>
      <div class="`+l+`-cp-c" data-toggle="handler-color-c">
        `+(a||`
          <div class="`+l+`-cp-wrap" data-toggle="handler-color-wrap" style="background-color: `+o+`">
            <input type="color" data-toggle="handler-color" value="`+o+`">
          </div>`)+`
      </div>
    `,c.position=`absolute`,c.top=0,c.left=this.position+`%`,n.appendChild(s),this.el=s,this.initEvents(),this.cpFn=r&&r(this),s}}}]),e}()}])}},t={};function n(r){var i=t[r];if(i!==void 0)return i.exports;var a=t[r]={exports:{}};return e[r].call(a.exports,a,a.exports,n),a.exports}n.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return n.d(t,{a:t}),t},n.d=(e,t)=>{for(var r in t)n.o(t,r)&&!n.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},n.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),n.r=e=>{typeof Symbol<`u`&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:`Module`}),Object.defineProperty(e,"__esModule",{value:!0})};var r={};return(()=>{n.r(r),n.d(r,{GRAD_DIRS:()=>l,GRAD_TYPES:()=>u,default:()=>g,getValidDir:()=>c,parseGradient:()=>o,toGradient:()=>s});var e=n(9),t=n.n(e),i=function(){return i=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},i.apply(this,arguments)},a=function(e,t,n){if(n||arguments.length===2)for(var r,i=0,a=t.length;i<a;i++)!r&&i in t||(r||=Array.prototype.slice.call(t,0,i),r[i]=t[i]);return e.concat(r||Array.prototype.slice.call(t))},o=function(e){var t=e.indexOf(`(`)+1,n=e.lastIndexOf(`)`),r=e.substring(t,n),i=r.split(/,(?![^(]*\))/),a={direction:`left`,type:`linear`,content:r,colors:r,stops:[]};if(!r)return a;i.length>2&&(a.direction=i.shift(),a.colors=i.join(`,`).trim());var o=!1;return[`repeating-linear`,`repeating-radial`,`linear`,`radial`].forEach((function(t){e.indexOf(function(e){return`${e}-gradient(`}(t))>-1&&!o&&(o=!0,a.type=t)})),a.stops=i.map((function(e){var t=e.split(` `),n=(t.length>1?t.pop():``).trim();return{color:t.join(` `).trim(),position:n}})),a},s=function(e,t,n){var r=a(a([],l,!0),[`center`],!1),i=t;return[`linear`,`repeating-linear`].indexOf(e)>=0&&r.indexOf(i)>=0&&(i=i===`center`?`to right`:`to ${i}`),[`radial`,`repeating-radial`].indexOf(e)>=0&&r.indexOf(i)>=0&&(i=`circle at ${i}`),n?`${e}-gradient(${i}, ${n})`:``},c=function(e){return l.filter((function(t){return e.indexOf(t)>-1}))[0]},l=[`right`,`bottom`,`left`,`top`],u=[`linear`,`radial`,`repeating-linear`,`repeating-radial`],d=`[data-toggle="handler-color-wrap"]`,f=`background-image-gradient`,p=`${f}-dir`,m=`${f}-type`,h=function(){return h=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},h.apply(this,arguments)};let g=function(e,n){n===void 0&&(n={}),function(e,n){n===void 0&&(n={});var r=e.getModel(),a=e.Styles,h=n.colorPicker,g=n.builtInType,_=n.styleType,v=function(t){var n=t.getEl().querySelector(d),r=e.$(n);r.spectrum&&r.spectrum(`destroy`)};_&&a.addType(_,{create:function(e){var a=e.change,o=document.createElement(`div`);o.className=`gp-container`,o.style.width=`100%`;var s=new(t())(i({el:o},n.grapickOpts));return s.on(`change`,(function(e){return a({value:s.getValue(),partial:!e})})),this.gp=s,h==="default"&&(h=function(e){var t=e.getEl(),n=t.querySelector(d),i=t.querySelector(`input`);i?.parentNode.removeChild(i);var a=n.style;a.backgroundColor=e.getColor();var o=function(t,n){n===void 0&&(n=1);var r=function(e){return(e.getAlpha()==1?e.toHexString():e.toRgbString()).replace(/ /g,``)}(t);a.backgroundColor=r,e.setColor(r,n)};r.initBaseColorPicker(n,{color:e.getColor(),change:function(e){o(e)},move:function(e){o(e,0)}})},s.on(`handler:remove`,v)),h&&s.setColorPicker(h),o},emit:function(e,t){var n=e.updateStyle,r=t.partial;n(t.value,{partial:r})},update:function(e){var t=e.value,r=this.gp;if(r.getValue()!==t){var i=r.getHandlers();i.map(v),r.setValue(t,{silent:!0}),n.selectEdgeStops&&[i[0],i[i.length-1]].filter(Boolean).map((function(e){return e.select({keepSelect:!0})}))}},destroy:function(){var e;(e=this.gp)==null||e.destroy()}}),g&&a.addBuiltIn(g,{type:`composite`,fromStyle:function(e,t){var n,r=t.name,i=o(e[r]||``),a=i.type||u[0],d=c(i.direction)||l[0];return(n={})[f]=s(a,d,i.colors),n[m]=a,n[p]=d,n},toStyle:function(e,t){var n,r=t.name,i=e[f]||``,a=s(e[m]||u[0],e[p]||l[0],o(i).colors);return(n={})[r]=a,n},properties:[{name:` `,full:!0,defaults:`none`,type:_,property:f},{name:`Direction`,type:`select`,defaults:`right`,property:p,options:l.map((function(e){return{value:e}}))},{name:`Type`,type:`select`,defaults:`linear`,property:m,options:u.map((function(e){return{value:e}}))}]})}(e,h({grapickOpts:{},selectEdgeStops:!0,styleType:`gradient`,builtInType:`background-image`},n))}})(),r})()))})),Pt=o(((e,t,n)=>{(function(n,r){typeof e==`object`&&typeof t==`object`?t.exports=r():typeof define==`function`&&define.amd?define([],r):typeof e==`object`?e["grapesjs-style-filter"]=r():n[`grapesjs-style-filter`]=r()})(typeof globalThis<`u`?globalThis:typeof window<`u`?window:n,(()=>(()=>{var e={d:(t,n)=>{for(var r in n)e.o(n,r)&&!e.o(t,r)&&Object.defineProperty(t,r,{enumerable:!0,get:n[r]})},o:(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r:e=>{typeof Symbol<`u`&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:`Module`}),Object.defineProperty(e,"__esModule",{value:!0})}},t={};e.r(t),e.d(t,{default:()=>r});var n=function(){return n=Object.assign||function(e){for(var t,n=1,r=arguments.length;n<r;n++)for(var i in t=arguments[n])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i]);return e},n.apply(this,arguments)};let r=function(e){e.Styles.addBuiltIn(`filter`,{type:`stack`,layerSeparator:` `,fromStyle:function(e,t){var n=t.property,r=e[t.name]||``,i=n.getLayerSeparator();return r?r.split(i).map((function(e){var t=n.__parseFn(e);return{name:t.name,value:t.value}})):[]},toStyle:function(e,t){var n;return(n={})[t.name]=`${e.name}(${e.value})`,n},properties:[{property:`name`,name:`Type`,type:`select`,default:`sepia`,full:!0,options:[{id:`blur`,propValue:{min:0,units:[`px`,`em`,`rem`,`vw`,`vh`]}},{id:`brightness`,propValue:{min:0,units:[`%`]}},{id:`contrast`,propValue:{min:0,units:[`%`]}},{id:`grayscale`,propValue:{min:0,max:100,units:[`%`]}},{id:`hue-rotate`,propValue:{min:0,max:360,units:[`deg`,`rad`,`grad`]}},{id:`invert`,propValue:{min:0,max:100,units:[`%`]}},{id:`saturate`,propValue:{min:0,units:[`%`]}},{id:`sepia`,propValue:{min:0,max:100,units:[`%`]}}],onChange:function(e){var t=e.property;if(e.to.value){var r=t.getOption(),i=n({},r.propValue||{}),a=t.getParent().getProperty(`value`),o=a.getUnit();(!o||i?.units.indexOf(o)<0)&&(i.unit=i?.units[0]||``),a.up(i)}}},{property:`value`,type:`slider`,default:`0`,full:!0}]})};return t})()))})),Ft=o(((e,t)=>{(function(n,r){typeof e==`object`&&typeof t==`object`?t.exports=r():typeof define==`function`&&define.amd?define([],r):typeof e==`object`?e["grapesjs-touch"]=r():n[`grapesjs-touch`]=r()})(window,function(){return function(e){var t={};function n(r){if(t[r])return t[r].exports;var i=t[r]={i:r,l:!1,exports:{}};return e[r].call(i.exports,i,i.exports,n),i.l=!0,i.exports}return n.m=e,n.c=t,n.d=function(e,t,r){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:r})},n.r=function(e){typeof Symbol<`u`&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:`Module`}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t||4&t&&typeof e==`object`&&e&&e.__esModule)return e;var r=Object.create(null);if(n.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&t&&typeof e!=`string`)for(var i in e)n.d(r,i,function(t){return e[t]}.bind(null,i));return r},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,`a`,t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p=``,n(n.s=0)}([function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=a(n(1)),i=a(n(2));function a(e){return e&&e.__esModule?e:{default:e}}t.default=function(e){(0,i.default)(),(0,r.default)()}},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0}),t.default=function(){var e;(function(e){var t=function(){function e(){this._dropEffect=`move`,this._effectAllowed=`all`,this._data={}}return Object.defineProperty(e.prototype,"dropEffect",{get:function(){return this._dropEffect},set:function(e){this._dropEffect=e},enumerable:!0,configurable:!0}),Object.defineProperty(e.prototype,"effectAllowed",{get:function(){return this._effectAllowed},set:function(e){this._effectAllowed=e},enumerable:!0,configurable:!0}),Object.defineProperty(e.prototype,"types",{get:function(){return Object.keys(this._data)},enumerable:!0,configurable:!0}),e.prototype.clearData=function(e){e==null?this._data=null:delete this._data[e]},e.prototype.getData=function(e){return this._data[e]||``},e.prototype.setData=function(e,t){this._data[e]=t},e.prototype.setDragImage=function(e,t,r){var i=n._instance;i._imgCustom=e,i._imgOffset={x:t,y:r}},e}();e.DataTransfer=t;var n=function(){function e(){if(this._lastClick=0,e._instance)throw`DragDropTouch instance already created.`;var t=!1;if(document.addEventListener(`test`,function(){},{get passive(){return t=!0,!0}}),`ontouchstart`in document){var n=document,r=this._touchstart.bind(this),i=this._touchmove.bind(this),a=this._touchend.bind(this),o=!!t&&{passive:!1,capture:!1};n.addEventListener(`touchstart`,r,o),n.addEventListener(`touchmove`,i,o),n.addEventListener(`touchend`,a),n.addEventListener(`touchcancel`,a)}}return e.getInstance=function(){return e._instance},e.prototype._touchstart=function(t){var n=this;if(this._shouldHandle(t)){if(Date.now()-this._lastClick<e._DBLCLICK&&this._dispatchEvent(t,`dblclick`,t.target))return t.preventDefault(),void this._reset();this._reset();var r=this._closestDraggable(t.target);r&&(this._dispatchEvent(t,`mousemove`,t.target)||this._dispatchEvent(t,`mousedown`,t.target)||(this._dragSource=r,this._ptDown=this._getPoint(t),this._lastTouch=t,t.preventDefault(),setTimeout(function(){n._dragSource==r&&n._img==null&&n._dispatchEvent(t,`contextmenu`,r)&&n._reset()},e._CTXMENU)))}},e.prototype._touchmove=function(t){if(this._shouldHandle(t)){var n=this._getTarget(t);if(this._dragSource&&!this._img&&this._getDelta(t)>e._THRESHOLD&&(this._dispatchEvent(t,`dragstart`,this._dragSource),this._createImage(t),this._dispatchEvent(t,`dragenter`,n)),this._img&&(this._lastTouch=t,t.preventDefault(),n!=this._lastTarget&&(this._dispatchEvent(this._lastTouch,`dragleave`,this._lastTarget),this._dispatchEvent(t,`dragenter`,n),this._lastTarget=n),this._moveImage(t),this._dispatchEvent(t,`dragover`,n)),this._dispatchEvent(t,`mousemove`,n))return this._lastTouch=t,void t.preventDefault()}},e.prototype._touchend=function(e){if(this._shouldHandle(e)){if(this._destroyImage(),this._dragSource)return e.type.indexOf(`cancel`)<0&&this._dispatchEvent(this._lastTouch,`drop`,this._lastTarget),this._dispatchEvent(this._lastTouch,`dragend`,this._dragSource),this._reset(),void e.preventDefault();if(this._dispatchEvent(this._lastTouch,`mouseup`,e.target))return void e.preventDefault();this._img||(this._dragSource=null,this._dispatchEvent(this._lastTouch,`click`,e.target),this._lastClick=Date.now())}},e.prototype._shouldHandle=function(e){return e&&!e.defaultPrevented&&e.touches&&e.touches.length<2},e.prototype._reset=function(){this._destroyImage(),this._dragSource=null,this._lastTouch=null,this._lastTarget=null,this._ptDown=null,this._dataTransfer=new t},e.prototype._getPoint=function(e,t){return e&&e.touches&&(e=e.touches[0]),{x:t?e.pageX:e.clientX,y:t?e.pageY:e.clientY}},e.prototype._getDelta=function(e){var t=this._getPoint(e);return Math.abs(t.x-this._ptDown.x)+Math.abs(t.y-this._ptDown.y)},e.prototype._getTarget=function(e){var t=this._getPoint(e),n=document.elementFromPoint(t.x,t.y);if(n&&n.nodeName===`IFRAME`)try{var r=n.contentWindow.document,i={x:0,y:0};do i.x+=n.offsetLeft||0,i.y+=n.offsetTop||0,n=n.offsetParent;while(n);var a=t.x-i.x,o=t.y-i.y;n=r.elementFromPoint(a,o)}catch{}for(;n&&getComputedStyle(n).pointerEvents==`none`;)n=n.parentElement;return n},e.prototype._createImage=function(t){this._img&&this._destroyImage();var n=this._imgCustom||this._dragSource;if(this._img=n.cloneNode(!0),this._copyStyle(n,this._img),this._img.style.top=this._img.style.left=`-9999px`,!this._imgCustom){var r=n.getBoundingClientRect(),i=this._getPoint(t);this._imgOffset={x:i.x-r.left,y:i.y-r.top},this._img.style.opacity=e._OPACITY.toString()}this._moveImage(t),document.body.appendChild(this._img)},e.prototype._destroyImage=function(){this._img&&this._img.parentElement&&this._img.parentElement.removeChild(this._img),this._img=null,this._imgCustom=null},e.prototype._moveImage=function(e){var t=this;requestAnimationFrame(function(){if(t._img){var n=t._getPoint(e,!0),r=t._img.style;r.position=`absolute`,r.pointerEvents=`none`,r.zIndex=`999999`,r.left=Math.round(n.x-t._imgOffset.x)+`px`,r.top=Math.round(n.y-t._imgOffset.y)+`px`}})},e.prototype._copyProps=function(e,t,n){for(var r=0;r<n.length;r++){var i=n[r];e[i]=t[i]}},e.prototype._copyStyle=function(t,n){if(e._rmvAtts.forEach(function(e){n.removeAttribute(e)}),t instanceof HTMLCanvasElement){var r=t,i=n;i.width=r.width,i.height=r.height,i.getContext(`2d`).drawImage(r,0,0)}for(var a=getComputedStyle(t),o=0;o<a.length;o++){var s=a[o];s.indexOf(`transition`)<0&&(n.style[s]=a[s])}for(n.style.pointerEvents=`none`,o=0;o<t.children.length;o++)this._copyStyle(t.children[o],n.children[o])},e.prototype._dispatchEvent=function(t,n,r){if(t&&r){var i=document.createEvent(`Event`),a=t.touches?t.touches[0]:t;return i.initEvent(n,!0,!0),i.button=0,i.which=i.buttons=1,this._copyProps(i,t,e._kbdProps),this._copyProps(i,a,e._ptProps),i.dataTransfer=this._dataTransfer,r.dispatchEvent(i),i.defaultPrevented}return!1},e.prototype._closestDraggable=function(e){for(;e;e=e.parentElement)if(e.hasAttribute(`draggable`)&&e.draggable)return e;return null},e}();n._instance=new n,n._THRESHOLD=5,n._OPACITY=.5,n._DBLCLICK=500,n._CTXMENU=900,n._rmvAtts=`id,class,style,draggable`.split(`,`),n._kbdProps=`altKey,ctrlKey,metaKey,shiftKey`.split(`,`),n._ptProps=`pageX,pageY,clientX,clientY,screenX,screenY`.split(`,`),e.DragDropTouch=n})(e||={})}},function(e,t,n){Object.defineProperty(t,"__esModule",{value:!0});var r=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){return typeof e}:function(e){return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e};t.default=function(){(function(){var e,t,n,i=0,a=navigator.userAgent,o=[`touchstart`,`touchmove`,`touchend`,`touchcancel`,`touchleave`],s={};function c(){var e=[];this.touchList=e,this.Touch=function(e,t,n,r,i,a,o,s){this.identifier=e,this.target=t,this.screenX=n,this.screenY=r,this.clientX=i,this.clientY=a,this.pageX=o,this.pageY=s},this.getTouch=function(t){for(var n=0;n<e.length;n+=1)if(e[n].identifier===t)return e[n]},this.addUpdateTouch=function(t){for(var n=0;n<e.length;n+=1)if(e[n].identifier===t.identifier)return void(e[n]=t);e.push(t)},this.removeTouch=function(t){for(var n=0;n<e.length;n+=1)e[n].identifier===t&&e.splice(n,1)},this.clearTouches=function(){for(;e.length>0;)e.pop()},this.containsTouchAt=function(t,n){for(var r=0;r<e.length;r+=1)if(e[r].screenX===t&&e[r].screenY===n)return!0;return!1}}function l(e,t){return e.screenX===t.screenX&&e.screenY===t.screenY}function u(e,t){var n;return t||={bubbles:!1,cancelable:!1,detail:void 0},(n=document.createEvent(`CustomEvent`)).initCustomEvent(e,t.bubbles,t.cancelable,t.detail),n}function d(r,a,o,s,c){var d,f,p;function m(e,t){var r,i;for(n.clearTouches(),r=0;r<t.length;r++)(i=t[r]).target.isSameNode(e)&&n.addUpdateTouch(i)}r.type!==`pointerdown`&&(f=e.getTouch(r.pointerId),p=f.target,r.target=p),(d=r.type===`pointerdown`||r.type===`pointermove`?function(r){var a,o,s;if(r.type===`pointerdown`)a=`touchstart`;else{if(r.type!==`pointermove`)throw Error(`touchHandler received invalid event type: `+a+`. Valid event types are pointerdown and pointermove`);a=`touchmove`}return o=new e.Touch(r.pointerId,r.type===`pointerdown`?r.target:p,r.screenX,r.screenY,r.clientX,r.clientY,r.pageX,r.pageY),r.hwTimestamp>i&&function(){var n,r=t.touchList,i,a,o;for(n=0;n<r.length;n+=1)o=(i=r[n]).identifier,(a=e.getTouch(o))&&!l(a,i)||t.removeTouch(o)}(),e.addUpdateTouch(o),t.addUpdateTouch(o),m(o.target,e.touchList),r.type=a,(s=new u(a,{bubbles:!0,cancelable:!0})).touches=e.touchList,s.changedTouches=t.touchList,s.targetTouches=n.touchList,s.type=a,s}(r):function(r){var a,o,s;return r.changedTouches=[],r.changedTouches.length=1,r.changedTouches[0]=r,r.changedTouches[0].identifier=r.pointerId,r.type===`pointerup`?a=`touchend`:r.type===`pointercancel`?a=`touchcancel`:r.type===`pointerleave`&&(a=`touchleave`),o=new e.Touch(r.pointerId,p,r.screenX,r.screenY,r.clientX,r.clientY,r.pageX,r.pageY),r.hwTimestamp>i&&t.clearTouches(),e.removeTouch(o.identifier),t.addUpdateTouch(o),m(o.target,e.touchList),r.type=a,(s=new u(a,{bubbles:!0,cancelable:!0})).touches=e.touchList,s.changedTouches=t.touchList,s.targetTouches=n.touchList,s.type=a,s}(r)).preventDefault=function(){r.preventDefault!==void 0&&r.preventDefault()},r.target.dispatchEvent(d),i=event.hwTimestamp}function f(e,t,n,r,i,a){d(t)}function p(e,t,n){var r,i;if(``+n+t,e.__handJobjsGlobalRegisteredEvents||=[],n){if(e.__handJobjsGlobalRegisteredEvents[t]!==void 0)return void(e.__handJobjsGlobalRegisteredEvents[t]+=1);e.__handJobjsGlobalRegisteredEvents[t]=1,e.__handJobjsGlobalRegisteredEvents[t]}else e.__handJobjsGlobalRegisteredEvents[t]!==void 0&&(--e.__handJobjsGlobalRegisteredEvents[t],e.__handJobjsGlobalRegisteredEvents[t]<0&&(e.__handJobjsGlobalRegisteredEvents[t]=0));r=d,e[`on`+(i=function(e){return e}(t)).toLowerCase()]!==void 0&&function(e,t,n,r){if(e.__handJobjsRegisteredEvents===void 0&&(e.__handJobjsRegisteredEvents=[]),r){if(e.__handJobjsRegisteredEvents[t]!==void 0)return void(e.__handJobjsRegisteredEvents[t]+=1);e.__handJobjsRegisteredEvents[t]=1,``+t,e.addEventListener(t,n,!1)}else{if(e.__handJobjsRegisteredEvents.indexOf(t)!==-1&&(--e.__handJobjsRegisteredEvents[t],e.__handJobjsRegisteredEvents[t]!==0))return;e.removeEventListener(t,n),e.__handJobjsRegisteredEvents[t]=0}}(e,i,function(e){r(e,t)},n)}function m(e){var t=e.prototype?e.prototype.addEventListener:e.addEventListener;function n(e,n,r){o.indexOf(e)!==-1&&p(this,e,!0),t.call(this,e,n,r)}e.prototype?e.prototype.addEventListener=n:e.addEventListener=n}function h(e,t){e.preventManipulation&&e.preventManipulation(),d(touchPoint)}function g(e){var t=e.prototype?e.prototype.removeEventListener:e.removeEventListener;function n(e,n,r){o.indexOf(e)!==-1&&function(e,t){if(e.ontouchdown===void 0&&e.ontouchstart!==void 0)switch(t.toLowerCase()){case`touchstart`:e.removeEventListener(`pointerdown`,function(e){h(e)});break;case`touchmove`:e.removeEventListener(`pointermove`,function(e){h(e)});break;case`touchend`:e.removeEventListener(`pointerup`,function(e){h(e)});break;case`touchcancel`:e.removeEventListener(`pointercancel`,function(e){h(e)})}}(this,e),t.call(this,e,n,r)}e.prototype?e.prototype.removeEventListener=n:e.removeEventListener=n}function _(e,t){return e.__handJobjsGlobalRegisteredEvents&&e.__handJobjsGlobalRegisteredEvents[t]}function v(e,t,n,r,i,a){(function(e,t){for(;e&&!_(e,t);)e=e.parentNode;return e||(_(window,t)?window:void 0)})(n,e)&&f(0,t)}function y(e){var t=[];if(e)for(t.unshift(e);e.parentNode;)t.unshift(e.parentNode),e=e.parentNode;return t}function b(e,t){for(var n=y(e),r=y(t),i=null;n.length>0&&n[0]===r.shift();)i=n.shift();return i}u.prototype=window.Event.prototype,r(window.ontouchstart)!==`object`&&(a.match(/iPad/i)||a.match(/iPhone/i)||a.match(/iPod/i)||a.match(/Android/i)||a.match(/MSIE/i)&&!a.match(/Touch/i)||(function(){var e=`html { -ms-touch-action: none; }`,t=document.head||document.getElementsByTagName(`head`)[0],n=document.createElement(`style`);n.type=`text/css`,n.styleSheet?n.styleSheet.cssText=e:n.appendChild(document.createTextNode(e)),t.appendChild(n)}(),e=new c,t=new c,n=new c,window.CustomEvent=u,m(window),m(window.HTMLElement||window.Element),m(document),m(HTMLBodyElement),m(HTMLDivElement),m(HTMLImageElement),m(HTMLUListElement),m(HTMLAnchorElement),m(HTMLLIElement),m(HTMLTableElement),window.HTMLSpanElement&&m(HTMLSpanElement),window.HTMLCanvasElement&&m(HTMLCanvasElement),window.SVGElement&&m(SVGElement),g(window),g(window.HTMLElement||window.Element),g(document),g(HTMLBodyElement),g(HTMLDivElement),g(HTMLImageElement),g(HTMLUListElement),g(HTMLAnchorElement),g(HTMLLIElement),g(HTMLTableElement),window.HTMLSpanElement&&g(HTMLSpanElement),window.HTMLCanvasElement&&g(HTMLCanvasElement),window.SVGElement&&g(SVGElement),function(){function t(e){return e.pointerType===`mouse`||e.type===`pointerdown`&&e.x===0&&e.y===0||e.pointerType===`pen`&&e.pressure===0&&e.type===`pointermove`}window.addEventListener(`pointerdown`,function(e){var n=e;t(e)||(s[n.identifier]=n.target,v(`touchenter`,n,n.target),function(e,t,n){for(var r=b(e,t),i=e,a=[];i&&i!==r;)_(i,`touchenter`)&&a.push(i),i=i.parentNode;for(;a.length>0;)n(a.pop())}(n.target,null,function(e){f(0,n)}),v(`touchstart`,n,n.target))}),window.addEventListener(`pointerup`,function(e){var n=e,r=s[n.identifier];t(e)||(v(`touchend`,n,r),v(`touchleave`,n,r),function(e,t,n){for(var r=b(e,t),i=e;i&&i!==r;)_(i,`touchleave`)&&n(i),i=i.parentNode}(r,null,function(e){f(0,n)}))}),window.addEventListener(`pointermove`,function(n){var r=n,i=s[r.identifier];t(n)||(``+n.screenX+n.screenY,e.containsTouchAt(n.screenX,n.screenY)||(i&&!0===function(e){for(;e&&!e.handJobjs_forcePreventDefault;)e=e.parentNode;return!!e||window.handJobjs_forcePreventDefault}(i)&&n.preventDefault(),v(`touchmove`,r,i)))})}()))})()}}])})})),It=c(At(),1),Lt=c(jt(),1),Rt=c(Mt(),1),zt=c(Nt(),1),Bt=c(Pt(),1),Vt=c(Ft(),1),Ht=(e,...t)=>{for(;typeof e!=`function`&&e?.default;)e=e.default;return e(...t)};function Ut(e){e.StyleManager.addType(`color`,{create({props:e,change:t}){let n=document.createElement(`div`);n.className=`jz-color-property`;let r=document.createElement(`input`);return r.type=`color`,r.dataset.colorAlpha=`true`,r.dataset.colorLabel=`Цвет · ${e.name||e.property||`элемента`}`,r.value=`#ffffff`,r.addEventListener(`input`,e=>t({event:e,partial:!0})),r.addEventListener(`change`,e=>t({event:e})),n.append(r),n},emit({updateStyle:e},{event:t,partial:n}){e(t.target.dataset.colorValue||t.target.value,{partial:n})},update({value:e,el:t}){_e(t.querySelector(`input[type="color"]`),e||`#ffffff`)},destroy(){}}),Ht(Lt.default,e,{blocks:[`column1`,`column2`,`column3`,`column3-7`],flexGrid:!0,labelColumn1:`Одна колонка`,labelColumn2:`Две колонки`,labelColumn3:`Три колонки`,labelColumn37:`Колонки 3/7`}),Ht(Rt.default,e,{labelRow:`Строка`,labelColumn:`Колонка`,flexboxBlock:{label:`Flex-контейнер`}}),Ht(It.default,e,{category:`Формы`}),e.Components.addType(`form`,{model:{defaults:{traits:[]}}});for(let[t,n]of Object.entries({form:`Форма`,input:`Текстовое поле`,textarea:`Многострочное поле`,select:`Список выбора`,checkbox:`Флажок`,radio:`Переключатель`,label:`Подпись поля`}))e.Blocks.get(t)?.set(`label`,n);e.Blocks.get(`form`)?.set(`content`,{type:`form`,tagName:`form`,style:{display:`flex`,"flex-direction":`column`,gap:`16px`,padding:`24px`},components:[{type:`label`,attributes:{for:`contact-name`},components:`Имя`},{type:`input`,attributes:{id:`contact-name`,name:`name`,placeholder:`Ваше имя`,"aria-label":`Имя`,required:!0}},{type:`label`,attributes:{for:`contact-email`},components:`Email`},{type:`input`,attributes:{id:`contact-email`,name:`email`,type:`email`,required:!0,"aria-label":`Email`}},{type:`label`,attributes:{for:`contact-message`},components:`Сообщение`},{type:`textarea`,attributes:{id:`contact-message`,name:`message`,rows:`4`,"aria-label":`Сообщение`}},{type:`button`,attributes:{type:`submit`},components:`Отправить`}]}),Ht(zt.default,e,{}),Ht(Bt.default,e,{}),Ht(Vt.default,e,{})}function Wt(e,t){for(let n of[`column1`,`column2`,`column3`,`column3-7`,`flexbox`,`form`,`input`,`textarea`,`select`,`checkbox`,`radio`,`label`]){let r=e.Blocks.get(n);if(!r)continue;let i=document.createElement(`button`);i.type=`button`,i.className=`block-card`;let a=[`form`,`input`,`textarea`,`select`,`checkbox`,`radio`,`label`].includes(n);i.dataset.category=a?`Формы`:`Компоновка`,i.dataset.pluginBlock=n;let o=document.createElement(`div`);o.className=`block-media`,o.setAttribute(`aria-hidden`,`true`),o.innerHTML=Dt(n),i.append(o);let s=document.createElement(`strong`);s.textContent=String(r.getLabel()).replace(/<[^>]*>/g,``),i.append(s);let c=document.createElement(`small`);c.textContent=a?`Поля формы · заявки в панели проекта`:`Редактируемая компоновка GrapesJS`,i.append(c),i.title=s.textContent+` — `+c.textContent,i.onclick=()=>{let t=e.addComponents(r.getContent());e.select(t[0])},t.append(i)}let n=e.StyleManager.getSectors().find(e=>e.get(`name`)===`Оформление`);n&&(e.StyleManager.addProperty(n.getId(),{type:`gradient`,name:`Градиент`,property:`background-image`}),e.StyleManager.addProperty(n.getId(),{extend:`filter`,name:`Фильтр`}))}var Gt={"font-size":`8px`,"line-height":`1.2`,"margin-top":`2px`,width:`100%`,"text-align":`left`,color:`inherit`},Kt={display:`inline-flex`,"flex-direction":`column`,"align-items":`flex-start`,"max-width":`100%`,margin:`0`},qt={display:`flex`,"flex-direction":`column`,"align-items":`stretch`,width:`100%`,"min-width":`0`,margin:`0`},Jt=[`display`,`position`,`top`,`right`,`bottom`,`left`,`z-index`,`transform`,`width`,`min-width`,`max-width`,`margin`,`align-self`,`flex`],Yt={"box-sizing":`border-box`,position:`absolute`,right:`12px`,bottom:`10px`,"z-index":`2`,width:`max-content`,"max-width":`calc(100% - 24px)`,margin:`0`,padding:`4px 8px`,"border-radius":`999px`,"background-color":`rgba(0, 0, 0, 0.62)`,color:`#ffffff`,"font-size":`8px`,"line-height":`1.3`,"text-align":`right`,"white-space":`normal`},Xt={display:`inline`,padding:`0`,"border-radius":`0`,"background-color":`transparent`,"font-weight":`400`,"font-size":`8px`,"line-height":`1.4`,color:`inherit`,"text-decoration":`underline`};function Zt(e,t){if(typeof e?.style?.setProperty==`function`)for(let[n,r]of Object.entries(t))e.style.setProperty(n,String(r));else e?.style&&Object.assign(e.style,t)}function Qt(e,t){if(typeof e?.getClasses==`function`)return e.getClasses().includes(t);let n=e?.getAttributes?.()?.class||e?.get?.(`attributes`)?.class||``;return String(n).split(/\s+/).includes(t)}function $t(e){let t=e?.components?.();return Array.isArray(t?.models)?t.models.slice():[]}function en(e,t){typeof e?.addStyle==`function`?e.addStyle(t):typeof e?.setStyle==`function`&&e.setStyle({...e.getStyle?.(),...t})}function tn(e,t){let n=e?.getStyle?.()||{};(!n.position||n.position===`static`)&&en(e,{position:`relative`}),en(t,Yt);for(let e of $t(t))(String(e?.get?.(`tagName`)||e?.get?.(`type`)||``).toLowerCase()===`a`||e?.get?.(`type`)===`link`)&&en(e,Xt)}function nn(e){let t=0,n=e=>{let r=$t(e);for(let e=0;e<r.length;e++){let i=r[e];if(Qt(i,`ai-hero-background`)){let n=r[e+1];if(n&&Qt(n,`ai-photo-credit`)&&typeof n.move==`function`){tn(i,n),n.move(i,{at:$t(i).length}),t++;continue}}n(i)}};for(let t of e?.Pages?.getAll?.()||[]){let e=t?.getMainComponent?.();e&&n(e)}return t}function rn(e){return{type:`text`,tagName:`figcaption`,name:`Копирайт`,content:String(e??``),style:{...Gt}}}function an(e,t){let n=JSON.parse(JSON.stringify(e||{})),r={...n.style&&typeof n.style==`object`?n.style:{}},i={...Kt};for(let e of Jt)r[e]!==void 0&&(i[e]=r[e],delete r[e]);r.display=`block`,i.width!==void 0&&(r.width=`100%`);let a={...n,style:r};return delete a.components,delete a.content,{type:`wrapper`,tagName:`figure`,name:`Фото`,style:i,components:[a,rn(t)]}}function on(e){return String(e??``).trim()}function sn(e,t){if(t.kind!==`commons`)return;let n=e.ownerDocument,r=e.closest(`.ai-hero-background`),i=n.createElement(r?`p`:`figcaption`);if(i.className=`ai-photo-credit`,r){let e=n.defaultView?.getComputedStyle?.(r);(!e||e.position===`static`)&&(r.style.position=`relative`),Zt(i,Yt)}else Zt(i,{...Gt,"margin-top":`2px`});for(let[e,r]of[[t.sourceUrl,`Фото: `+t.author+` / Wikimedia Commons`],[t.licenseUrl,t.license]]){i.childNodes.length&&i.append(n.createTextNode(` · `));let t=n.createElement(`a`);t.href=e,t.textContent=r,Zt(t,Xt),i.append(t)}if(r)return r.append(i),i;let a=n.createElement(`figure`);return a.className=`ai-photo-figure`,Zt(a,qt),e.parentNode&&e.parentNode.replaceChild(a,e),a.append(e,i),i}function cn(e,t=`#000000`,n=0){if(!e)return`none`;if(!/^(https:\/\/[^\s"<>\\(){};]+|\/api\/projects\/[a-f0-9]{24}\/assets\/[a-f0-9]{24}\/file)$/.test(e))throw Error(`Укажите HTTPS URL изображения или файл библиотеки проекта.`);let r=e.startsWith(`https:`)?new URL(e):null;if(r&&(r.username||r.password))throw Error(`URL с логином или паролем запрещён.`);if(!/^#[a-f\d]{6}$/i.test(t))throw Error(`Некорректный цвет overlay.`);let i=Math.round(Math.max(0,Math.min(1,Number(n)||0))*1e3)/1e3,[a,o,s]=[1,3,5].map(e=>parseInt(t.slice(e,e+2),16)),c=`rgba(${a}, ${o}, ${s}, ${i})`;return`linear-gradient(${c}, ${c}), url("${e}")`}function ln(e=``){let t=e.match(/url\(["']?([^"')]+)["']?\)/)?.[1]||``,n=e.match(/rgba\((\d+),\s*(\d+),\s*(\d+),\s*([\d.]+)\)/);return{src:t,color:n?`#`+n.slice(1,4).map(e=>Number(e).toString(16).padStart(2,`0`)).join(``):`#000000`,opacity:n?Number(n[4]):0}}function un(e,t,n,r){let i=document.createElement(`fieldset`);i.className=`background-controls`,i.innerHTML=`<legend>Фон контейнера</legend><label>Background image<input id="container-background-url" type="url" placeholder="https://… или файл библиотеки"></label><label>Библиотека проекта<select id="container-background-asset"><option value="">Выберите изображение</option></select></label><button type="button" id="background-library-load">Обновить библиотеку</button><label>Background Overlay<input id="container-overlay-color" type="color" value="#000000"></label><label>Непрозрачность overlay <output id="container-overlay-value">0%</output><input id="container-overlay-opacity" type="range" min="0" max="100" value="0"></label><button type="button" id="background-apply">Применить фон</button><button type="button" id="background-remove">Убрать фон</button><p class="muted small" id="background-status">Выберите контейнер.</p>`;let a=null,o=e=>i.querySelector(`#`+e),s=()=>{let e=[...document.querySelectorAll(`#styles .gjs-sm-sector`)].find(e=>e.querySelector(`.gjs-sm-sector-title`)?.textContent.includes(`Оформление`))?.querySelector(`.gjs-sm-properties`)||document.querySelector(`#styles`);e&&!i.isConnected&&e.append(i)},c=e=>{s(),a=e;let t=e?.get(`tagName`),n=e&&![`img`,`a`,`button`,`h1`,`h2`,`h3`,`h4`,`p`,`span`].includes(t);if(i.hidden=!n,!n)return;let r=ln(e.getStyle()[`background-image`]);o(`container-background-url`).value=r.src,o(`container-overlay-color`).value=r.color,_e(o(`container-overlay-color`)),o(`container-overlay-opacity`).value=String(r.opacity*100),o(`container-overlay-value`).textContent=Math.round(r.opacity*100)+`%`,o(`background-status`).textContent=`Фон покрывает контейнер; overlay не меняет прозрачность текста.`};o(`container-overlay-opacity`).oninput=e=>o(`container-overlay-value`).textContent=e.target.value+`%`,o(`container-background-asset`).onchange=e=>o(`container-background-url`).value=e.target.value,o(`background-library-load`).onclick=async()=>{try{let e=await n(`/projects/${t}/assets`),r=o(`container-background-asset`);r.replaceChildren(new Option(`Выберите изображение`,``));for(let t of e)r.add(new Option(t.name,t.url))}catch(e){o(`background-status`).textContent=e.message}},o(`background-apply`).onclick=()=>{if(a&&e.getSelected()===a)try{a.addStyle({"background-image":cn(o(`container-background-url`).value.trim(),o(`container-overlay-color`).value,Number(o(`container-overlay-opacity`).value)/100),"background-size":`cover`,"background-position":`center`,"background-repeat":`no-repeat`}),o(`background-status`).textContent=`Фон применён. Доступна отмена.`}catch(e){r(e.message,!0)}},o(`background-remove`).onclick=()=>{a&&e.getSelected()===a&&(a.addStyle({"background-image":`none`}),c(a))},e.on(`component:selected`,c),e.on(`undo redo`,()=>c(e.getSelected())),e.on(`component:deselected`,()=>i.hidden=!0),e.on(`load`,s),s(),i.hidden=!0}function dn(e){let t=e?.get?.(`attributes`)?.id;return typeof t==`string`?t:``}function fn(e={},t={}){let n=e?.sharedSections||{},r=t?.data?.pages||[],i=new Map;for(let e of r)for(let t of e?.frames?.[0]?.component?.components||[]){let e=t?.attributes?.id;typeof e==`string`&&e&&i.set(e,{name:t.name||t.attributes?.[`aria-label`]||t.type||`Секция`})}let a=e=>{let t=n[`${e}ComponentId`]||``,a=i.get(t),o=a?r.filter(t=>n.pages?.[t.id]?.[e]!==!1).length:0;return{configured:!!(t&&a),name:a?.name||``,pageCount:o}};return{header:a(`header`),footer:a(`footer`)}}function pn(e,t,n,r=0){let i=Number.isFinite(e)&&e>0?e:0,a=Number.isFinite(t)&&t>0?t:0,o=Number.isFinite(n)&&n>0?n:0,s=Number.isFinite(r)&&r>0?r:0,c=i>0&&a>0?Math.min(1,i/a):1;return{scale:c,fitted:c<1,wrapperHeight:Math.ceil(o*c+s)}}var mn={src:`data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j6J8AAAAASUVORK5CYII=`},hn=Object.freeze({ink:`#183e31`,forest:`#245b46`,canvas:`#ecf4ef`,paper:`#f6faf7`,body:`#527063`,muted:`#68736c`,line:`#dce4de`,accent:`#b0dcc1`,fontFamily:`Arial, sans-serif`,headingFontFamily:`Arial, sans-serif`,bodyFontFamily:`Arial, sans-serif`,bodyFontWeight:`400`,headingFontWeight:`500`,baseFontSize:`16px`,fontSizeH1:`48px`,fontSizeH2:`36px`,fontSizeH3:`24px`,fontSizeH4:`20px`,fontSizeH5:`18px`,fontSizeH6:`16px`,bodyLineHeight:`1.6`,headingLineHeight:`1.15`,letterSpacing:`0px`,radius:`8px`});Object.freeze([`ink`,`forest`,`canvas`,`paper`,`body`,`muted`,`line`,`accent`]);var gn=Object.freeze([`Arial, sans-serif`,`system-ui, sans-serif`,`Georgia, serif`]),_n=Object.freeze([`300`,`400`,`500`,`600`,`700`,`800`]),vn=Object.freeze([{name:`ink`,label:`Основной текст`,variable:`--juzimder-color-ink`,type:`color`},{name:`forest`,label:`Брендовый цвет`,variable:`--juzimder-color-forest`,type:`color`},{name:`canvas`,label:`Фон секций`,variable:`--juzimder-color-canvas`,type:`color`},{name:`paper`,label:`Поверхность карточек`,variable:`--juzimder-color-paper`,type:`color`},{name:`body`,label:`Вторичный текст`,variable:`--juzimder-color-body`,type:`color`},{name:`muted`,label:`Приглушённый текст`,variable:`--juzimder-color-muted`,type:`color`},{name:`line`,label:`Границы`,variable:`--juzimder-color-line`,type:`color`},{name:`accent`,label:`Акцент`,variable:`--juzimder-color-accent`,type:`color`},{name:`fontFamily`,label:`Шрифт`,variable:`--juzimder-font-family`,type:`font`},{name:`headingFontFamily`,label:`Шрифт заголовков`,variable:`--juzimder-font-heading`,type:`font`},{name:`bodyFontFamily`,label:`Шрифт текста`,variable:`--juzimder-font-body`,type:`font`},{name:`bodyFontWeight`,label:`Вес основного текста`,variable:`--juzimder-font-weight-body`,type:`weight`},{name:`headingFontWeight`,label:`Вес заголовков`,variable:`--juzimder-font-weight-heading`,type:`weight`},{name:`baseFontSize`,label:`Базовый размер текста`,variable:`--juzimder-font-size-base`,type:`size`},{name:`fontSizeH1`,label:`Размер H1`,variable:`--juzimder-font-size-h1`,type:`size`},{name:`fontSizeH2`,label:`Размер H2`,variable:`--juzimder-font-size-h2`,type:`size`},{name:`fontSizeH3`,label:`Размер H3`,variable:`--juzimder-font-size-h3`,type:`size`},{name:`fontSizeH4`,label:`Размер H4`,variable:`--juzimder-font-size-h4`,type:`size`},{name:`fontSizeH5`,label:`Размер H5`,variable:`--juzimder-font-size-h5`,type:`size`},{name:`fontSizeH6`,label:`Размер H6`,variable:`--juzimder-font-size-h6`,type:`size`},{name:`bodyLineHeight`,label:`Межстрочный интервал текста`,variable:`--juzimder-line-height-body`,type:`lineHeight`},{name:`headingLineHeight`,label:`Межстрочный интервал заголовков`,variable:`--juzimder-line-height-heading`,type:`lineHeight`},{name:`letterSpacing`,label:`Межбуквенный интервал`,variable:`--juzimder-letter-spacing`,type:`letterSpacing`},{name:`radius`,label:`Скругление карточек`,variable:`--juzimder-radius`,type:`radius`}]),yn=Object.freeze({baseFontSize:[12,24],fontSizeH1:[28,80],fontSizeH2:[22,64],fontSizeH3:[18,48],fontSizeH4:[16,40],fontSizeH5:[14,32],fontSizeH6:[12,28]}),bn=Object.freeze([`1`,`1.1`,`1.15`,`1.2`,`1.25`,`1.3`,`1.4`,`1.5`,`1.6`,`1.7`,`1.8`,`1.9`,`2`]),xn=Object.freeze([`-2px`,`-1px`,`-0.5px`,`0px`,`0.25px`,`0.5px`,`1px`,`1.5px`,`2px`]),Sn=new Map(vn.map(e=>[e.name,e]));function Cn(e,t){let n=Sn.get(e);if(!n)throw TypeError(`Неизвестный design token: ${e}`);if(n.type===`color`){if(typeof t!=`string`||!/^#[0-9a-f]{6}$/i.test(t))throw TypeError(`Некорректный цвет токена «${e}».`);return t.toLowerCase()}if(n.type===`font`){if(!gn.includes(t))throw TypeError(`Выберите шрифт из списка.`);return t}if(n.type===`weight`){if(!_n.includes(t))throw TypeError(`Укажите вес шрифта от 300 до 800.`);return t}if(n.type===`size`){let n=yn[e],r=typeof t==`string`&&t.match(/^(\d{1,3})px$/);if(!r||Number(r[1])<n[0]||Number(r[1])>n[1])throw TypeError(`Размер ${e} должен быть в диапазоне ${n[0]}–${n[1]} px.`);return`${Number(r[1])}px`}if(n.type===`lineHeight`){if(!bn.includes(t))throw TypeError(`Межстрочный интервал должен быть от 1 до 2.`);return t}if(n.type===`letterSpacing`){if(!xn.includes(t))throw TypeError(`Выберите межбуквенный интервал из списка.`);return t}if(n.type===`radius`){if(typeof t!=`string`||!/^(?:0|[1-9]|[12][0-9]|3[0-2])px$/.test(t))throw TypeError(`Скругление должно быть от 0 до 32 px.`);return t}throw TypeError(`Неподдерживаемый тип токена «${e}».`)}function wn(e={}){if(!e||typeof e!=`object`||Array.isArray(e))throw TypeError(`Токены темы должны быть объектом.`);let t=Object.keys(e).filter(e=>!Sn.has(e));if(t.length)throw TypeError(`Неизвестный design token: ${t[0]}`);let n={...hn};for(let[t,r]of Object.entries(e))n[t]=Cn(t,r);let r=Object.hasOwn(e,`headingFontFamily`)||Object.hasOwn(e,`bodyFontFamily`);return Object.hasOwn(e,`fontFamily`)&&!r?(n.headingFontFamily=n.fontFamily,n.bodyFontFamily=n.fontFamily):(Object.hasOwn(e,`headingFontFamily`)&&(n.headingFontFamily=Cn(`headingFontFamily`,e.headingFontFamily)),Object.hasOwn(e,`bodyFontFamily`)&&(n.bodyFontFamily=Cn(`bodyFontFamily`,e.bodyFontFamily)),n.fontFamily=n.bodyFontFamily),n}function Tn(e,t){return e.name===`fontSizeH1`?`clamp(28px, calc(18px + 2.35vw), ${t})`:e.name===`fontSizeH2`?`clamp(22px, calc(17px + 1.5vw), ${t})`:e.name===`fontSizeH3`?`clamp(18px, calc(12px + 0.9vw), ${t})`:t}function En(e={}){let t={};for(let n of vn){let r=e[n.variable];if(typeof r==`string`){if(n.name===`fontSizeH1`||n.name===`fontSizeH2`||n.name===`fontSizeH3`){let e=r.match(/,\s*(\d{1,3}px)\s*\)$/);if(e){t[n.name]=e[1];continue}}try{t[n.name]=Cn(n.name,r)}catch{}}}if(!Object.hasOwn(t,`bodyFontFamily`)&&typeof e[`--juzimder-font-family`]==`string`)try{t.fontFamily=Cn(`fontFamily`,e[`--juzimder-font-family`])}catch{}return wn(t)}function Dn(e){let t=wn(e);return Object.fromEntries(vn.map(e=>[e.variable,Tn(e,t[e.name])]))}function M(e,t=hn[e]){let n=Sn.get(e);if(!n)throw TypeError(`Неизвестный design token: ${e}`);return`var(${n.variable}, ${Tn(n,t)})`}var On=Object.freeze({ink:`#183e31`,forest:`#245b46`,canvas:`#ecf4ef`,paper:`#f6faf7`,body:`#527063`,muted:`#68736c`,line:`#dce4de`,accent:`#b0dcc1`}),kn=Object.freeze({H1:[`clamp(36px, 6vw, 76px)`],H2:[`36px`,`clamp(28px, 4vw, 42px)`,`clamp(28px,4vw,42px)`],H3:[`20px`,`18px`,`16px`]});function An(e,t,n=``){if(typeof t!=`string`)return t;let r=String(n).toLowerCase();if(e===`font-family`&&(t.trim().toLowerCase()===hn.fontFamily.toLowerCase()||t.includes(`--juzimder-font-family`)))return M(/^h[1-6]$/.test(r)?`headingFontFamily`:`bodyFontFamily`);let i=r.match(/^h([1-6])$/)?.[1];if(e===`font-size`&&i){let e=`fontSizeH${i}`;if(t.includes(`--juzimder-font-size-h${i}`)||kn[`H${i}`]?.includes(t.trim()))return M(e)}if(e===`font-size`&&r===`p`&&t.trim()===`18px`)return M(`baseFontSize`);if(e===`font-weight`&&i&&[`500`,`600`,`700`].includes(t.trim()))return M(`headingFontWeight`);if(e===`line-height`){if(i&&[`1.05`,`1.15`,`1.2`].includes(t.trim()))return M(`headingLineHeight`);if(!i&&[`1.6`,`1.65`,`1.7`].includes(t.trim()))return M(`bodyLineHeight`)}return e===`border-radius`&&[`6px`,`8px`].includes(t.trim())?M(`radius`):t.replace(/#[0-9a-f]{6}\b/gi,e=>{let t=Object.keys(On).find(t=>On[t]===e.toLowerCase());return t?M(t):e})}var jn={"font-family":M(`bodyFontFamily`),"font-size":M(`baseFontSize`),"line-height":M(`bodyLineHeight`),color:M(`body`)},N=(e,t)=>({type:`text`,tagName:e,content:t,style:{margin:`0`,"font-family":M(`headingFontFamily`),"font-size":M(e===`h1`?`fontSizeH1`:e===`h2`?`fontSizeH2`:`fontSizeH3`),"line-height":M(`headingLineHeight`),color:M(`ink`)}}),P=e=>({type:`text`,tagName:`p`,content:e,style:{...jn,margin:`0`}}),F=()=>({type:`image`,name:`Выберите фотографию`,attributes:{src:mn.src,alt:`Выберите фотографию`},style:{width:`100%`,"max-width":`100%`,"min-height":`180px`,"aspect-ratio":`4/3`,"background-color":M(`line`),"object-fit":`cover`,"border-radius":M(`radius`)}}),I=(e=`Измените ссылку`)=>({type:`link`,attributes:{href:`https://example.com`},content:e,style:{...jn,color:M(`forest`)}}),Mn=()=>({...I(`Подробнее`),style:{...jn,display:`inline-block`,width:`fit-content`,padding:`12px 20px`,"text-decoration":`none`,"background-color":M(`forest`),color:M(`paper`),"border-radius":M(`radius`)}}),L=e=>({tagName:`div`,style:{display:`grid`,"grid-template-columns":`repeat(auto-fit, minmax(min(100%, 240px), 1fr))`,gap:`24px`},components:e}),R=e=>({tagName:`div`,style:{display:`flex`,"flex-direction":`column`,gap:`16px`},components:e}),z=e=>({tagName:`article`,style:{...jn,display:`flex`,"flex-direction":`column`,gap:`16px`,padding:`24px`,border:`1px solid `+M(`line`),"border-radius":M(`radius`),"background-color":M(`paper`)},components:e}),Nn=(e,t)=>({tagName:`section`,name:e,style:{...jn,display:`flex`,"flex-direction":`column`,gap:`28px`,padding:`56px 6%`,"background-color":M(`canvas`)},components:[N(`h2`,e),...t]}),B=(e,t,n,r,i)=>({id:e,label:t,category:n,description:r,content:i}),V=e=>({type:`text`,tagName:`span`,content:e,style:{...jn,width:`fit-content`,padding:`6px 12px`,"font-size":`12px`,"border-radius":`999px`,border:`1px solid `+M(`line`)}}),H=(e,t,n)=>{let r=Nn(t,n);return r.components.unshift(V(e)),r},Pn=[B(`account-recovery-guide`,`Восстановление доступа`,`Секции`,`Безопасные шаги для восстановления аккаунта и обращения в поддержку`,()=>H(`Безопасность аккаунта`,`Вернуть доступ к аккаунту`,[L([`Проверьте способ входа`,`Восстановите доступ`,`Защитите аккаунт`].map((e,t)=>z([V(`Шаг `+(t+1)),N(`h3`,e),P(`Добавьте проверенную инструкцию для этого шага и ссылку только на официальный канал.`)]))),P(`Не просите присылать пароли, одноразовые коды или секреты в сообщениях. Опишите только реально работающий процесс восстановления.`)])),B(`planned-maintenance`,`Плановые работы`,`Секции`,`Время обслуживания, затронутые функции и временные обходные решения`,()=>H(`Заранее сообщаем`,`Плановое обслуживание`,[z([V(`Укажите дату и часовой пояс`),N(`h3`,`Окно работ`),P(`Заполните начало, окончание и причину работ по подтверждённому расписанию.`),P(`Обновите статус после завершения и укажите время последней проверки.`)]),L([`Что будет недоступно`,`Что продолжит работать`,`Временное решение`].map(e=>z([N(`h3`,e),P(`Перечислите только подтверждённое влияние на сервис и действия пользователя.`)])))])),B(`compatibility-matrix`,`Совместимость платформ`,`Карточки`,`Проверенные операционные системы, браузеры и минимальные версии`,()=>H(`Проверено на практике`,`Поддерживаемые среды`,[L([`Платформа`,`Браузер`,`Мобильное устройство`].map(e=>z([V(`Добавьте проверенную версию`),N(`h3`,e),P(`Укажите версии, известные ограничения и дату последней проверки этой среды.`)]))),P(`Не называйте версию поддерживаемой до тестирования; опубликуйте ссылку на требования, если условия меняются.`)])),B(`data-migration-guide`,`Перенос данных`,`Секции`,`План подготовки, пробного переноса и проверки результата`,()=>H(`Перед переносом`,`Перенесите данные по шагам`,[R([`Сделайте резервную копию`,`Сопоставьте поля и форматы`,`Проведите пробный перенос`,`Проверьте итоговые данные`].map((e,t)=>z([V(`Этап 0`+(t+1)),N(`h3`,e),P(`Опишите ответственного, критерий завершения и безопасное действие при ошибке.`)]))),P(`Сохраняйте исходные данные до успешной проверки переноса. Не включайте секреты и персональные данные в примеры или публичные инструкции.`)])),B(`api-integration-guide`,`Подключение по API`,`Секции`,`Подготовка доступа, отправка запросов и обработка ошибок интеграции`,()=>H(`Для разработчиков`,`Подключите интеграцию`,[L([`Получите доступ`,`Выполните запрос`,`Обработайте ответ`].map((e,t)=>z([V(`Шаг `+(t+1)),N(`h3`,e),P(`Добавьте ссылку на официальную документацию, нужные параметры и ожидаемый результат.`)]))),P(`Укажите актуальную версию API и порядок поддержки. Секретные ключи храните на сервере, не вставляйте их в браузерный код или публичные примеры.`)])),B(`admin-roles-guide`,`Роли и права доступа`,`Секции`,`Описание ролей команды и принципа выдачи минимально необходимых прав`,()=>H(`Для администраторов`,`Кому какие права нужны`,[L([`Владелец`,`Администратор`,`Редактор`,`Наблюдатель`].map(e=>z([N(`h3`,e),P(`Укажите фактические действия, доступные этой роли в вашем продукте.`)]))),P(`Это заготовка: проверьте названия ролей и разрешения по реальным настройкам. Выдавайте только доступ, необходимый для задач участника.`)])),B(`trial-period-guide`,`Условия пробного периода`,`Цены`,`Доступные функции, длительность проверки и условия перехода на тариф`,()=>H(`Перед подключением`,`Как устроен пробный период`,[L([`Начало и срок`,`Что доступно`,`После окончания`].map(e=>z([N(`h3`,e),P(`Заполните точные даты, ограничения, условия оплаты и отмены по действующему тарифу.`)]))),P(`Не обещайте бесплатный период или конкретный срок, если это не закреплено текущими условиями предложения.`)])),B(`service-level-overview`,`Показатели уровня сервиса`,`Секции`,`Метод измерения доступности, целевые показатели и подтверждённые исключения`,()=>H(`Условия сервиса`,`Как измеряется качество работы`,[L([`Доступность`,`Поддержка`,`Обслуживание и исключения`].map(e=>z([N(`h3`,e),P(`Укажите согласованный показатель, период измерения и ссылку на действующие условия.`)]))),P(`Публикуйте только согласованные целевые значения и обязательства; поясните метод расчёта, границы измерения и дату актуальности.`)])),B(`size-fit-guide`,`Таблица размеров и посадка`,`Карточки`,`Рекомендации по выбору размера, меркам и особенностям посадки`,()=>H(`Перед заказом`,`Подберите размер`,[P(`Сверьте параметры с таблицей бренда и укажите, как именно снимать мерки.`),L([`Как снять мерки`,`Особенности посадки`,`Если размер не подошёл`].map(e=>z([N(`h3`,e),P(`Добавьте точные рекомендации и условия обмена из актуальной инструкции продавца.`)]))),P(`Заполните таблицу размеров и единицы измерения по данным производителя; не публикуйте примерные значения как фактические.`)])),B(`product-origin`,`Материалы и происхождение`,`Карточки`,`Состав, происхождение материалов и подтверждающие документы товара`,()=>H(`Сведения о товаре`,`Из чего и где сделано`,[L([F(),R([N(`h3`,`Материалы и состав`),P(`Перечислите подтверждённые материалы, доли и применимые ограничения.`),N(`h3`,`Происхождение`),P(`Укажите страну и этап производства только по документам поставщика.`),I(`Документы и сертификаты`)])]),P(`Добавляйте экологические, этические и сертификационные заявления только при наличии действующего подтверждения.`)])),B(`accommodation-info`,`Информация о проживании`,`Секции`,`Заезд, выезд, оснащение и правила размещения`,()=>H(`Перед бронированием`,`Что важно знать о проживании`,[L([F(),R([N(`h3`,`Заезд и выезд`),P(`Укажите часы, адрес входа и проверенный способ получения ключей.`),N(`h3`,`Оснащение и доступ`),P(`Перечислите фактически доступные удобства и условия доступа.`)])]),L([`Правила проживания`,`Парковка и транспорт`,`Связь с хозяином`].map(e=>z([N(`h3`,e),P(`Добавьте актуальные условия, адреса и контакт для уточнений.`)])))])),B(`reservation-policy`,`Правила бронирования`,`Секции`,`Подтверждение брони, изменения, отмена и опоздание`,()=>H(`До оформления`,`Как работает бронирование`,[L([`Подтверждение`,`Изменить дату или время`,`Отмена и опоздание`].map(e=>z([N(`h3`,e),P(`Опишите точный порядок, сроки, возможные сборы и канал обращения по действующим правилам.`)]))),P(`Проверьте, что условия совпадают с системой бронирования и договором; не добавляйте неподтверждённые штрафы или возвраты.`)])),B(`event-access-guide`,`Доступность события`,`Секции`,`Маршрут, входы, места и помощь посетителям на площадке`,()=>H(`План посещения`,`Как добраться и получить помощь`,[L([`Маршрут и вход`,`Места и удобства`,`Запросить помощь`].map((e,t)=>z([V(`0`+(t+1)),N(`h3`,e),P(`Укажите проверенные ориентиры, доступные условия и контакт организатора.`)]))),P(`Заполните сведения вместе с площадкой; перечисляйте только фактически проверенные условия доступности.`)])),B(`incident-report`,`Обновления об инциденте`,`Секции`,`Хронология события, затронутые функции и проверенные обновления`,()=>H(`Оперативная информация`,`Ход инцидента`,[z([V(`Текущий статус: обновите вручную`),N(`h3`,`Кратко о ситуации`),P(`Укажите подтверждённое влияние, затронутые функции и время последней проверки.`)]),R([`Обнаружено`,`Ведётся работа`,`Решение или следующий шаг`].map((e,t)=>z([V(`Обновление 0`+(t+1)),N(`h3`,e),P(`Добавьте дату и время, подтверждённые факты и следующий ожидаемый шаг.`)]))),P(`Блок статичный: обновляйте его вручную и явно сообщите, когда инцидент закрыт. Не указывайте неподтверждённые сроки восстановления.`)])),B(`security-disclosure`,`Сообщить об уязвимости`,`Секции`,`Безопасный канал для сообщения о проблеме и порядок дальнейшей связи`,()=>H(`Ответственное раскрытие`,`Сообщить о проблеме безопасности`,[L([`Подготовьте сообщение`,`Передайте детали безопасно`,`Ожидайте ответа`].map((e,t)=>z([V(`Шаг `+(t+1)),N(`h3`,e),P(`Опишите затронутый продукт, влияние и безопасный способ связаться с вами.`)]))),P(`Укажите только реально работающий канал и подтверждённые ожидания по срокам; не публикуйте секреты и персональные данные в форме отчёта.`),I(`Контакт для сообщения`)])),B(`membership-benefits`,`Уровни участия и преимущества`,`Цены`,`Условия участия, подтверждённые преимущества и порядок вступления`,()=>H(`Программа участия`,`Выберите формат участия`,[L([`Уровень 1`,`Уровень 2`,`Уровень 3`].map(e=>z([V(`Условия уточняются`),N(`h3`,e),P(`Укажите критерии доступа, период и подтверждённые преимущества.`),I(`Узнать об участии`)]))),P(`Заполните стоимость, срок и правила продления только по утверждённым условиям программы.`)])),B(`return-policy`,`Возврат и обмен`,`Секции`,`Сроки, порядок обращения и доступные решения после покупки`,()=>H(`После покупки`,`Возврат или обмен`,[L([`Проверьте условия`,`Подготовьте сведения`,`Выберите решение`].map(e=>z([N(`h3`,e),P(`Укажите применимые сроки, состояние товара и нужные сведения по действующим правилам.`)]))),P(`Опубликуйте только согласованные с договором и правилами продажи условия; отдельно перечислите исключения.`)])),B(`subscription-management`,`Управление подпиской`,`Цены`,`Период оплаты, продление и способы изменить или отменить подписку`,()=>H(`Управление услугой`,`Платежи и подписка`,[L([`Период и дата списания`,`Изменение плана`,`Отмена и возврат`].map(e=>z([N(`h3`,e),P(`Опишите точные условия, доступные действия и срок, когда изменение вступит в силу.`)]))),P(`Проверьте описание на соответствие тарифу и правилам биллинга до публикации.`)])),B(`privacy-request-guide`,`Запрос на работу с данными`,`Секции`,`Каналы и этапы обработки запроса пользователя о его данных`,()=>H(`Ваши данные`,`Как подать запрос`,[R([`Выберите тип запроса`,`Отправьте обращение`,`Получите ответ`].map((e,t)=>z([V(`Шаг `+(t+1)),N(`h3`,e),P(`Укажите подтверждённый канал связи, нужные сведения и актуальный срок обработки.`)]))),P(`Опишите только реально доступные права, способы проверки личности и исключения из процедуры.`)])),B(`grant-application`,`Подача заявки на грант`,`Секции`,`Критерии, документы и этапы рассмотрения заявок`,()=>H(`Заявителям`,`Как подать заявку`,[L([`Кто может участвовать`,`Что подготовить`,`Как проходит отбор`].map(e=>z([N(`h3`,e),P(`Перечислите актуальные критерии, документы, даты и этапы по официальному положению.`)]))),P(`Укажите версию положения и дату обновления; не обещайте поддержку до решения комиссии.`)])),B(`press-kit`,`Материалы для прессы`,`Статьи`,`Логотипы, сведения о проекте и контакты для редакций`,()=>H(`Для редакций`,`Пресс-кит проекта`,[L([`О проекте`,`Брендовые материалы`,`Связь с редакцией`].map(e=>z([N(`h3`,e),P(`Добавьте утверждённое описание, ссылку на актуальные файлы и условия их использования.`)]))),P(`Проверьте права на изображения, логотипы и цитаты перед публикацией.`)])),B(`conference-session`,`Докладчик и выступление`,`Команда`,`Профиль спикера, тема выступления и расписание сессии`,()=>H(`В программе`,`Выступление на событии`,[L([F(),R([N(`h3`,`Имя докладчика`),P(`Укажите подтверждённую биографию и текущую роль.`),N(`h3`,`Название выступления`),P(`Добавьте тезисы, формат и продолжительность по программе.`),P(`Дата, время, площадка или ссылка на онлайн-сессию.`)])]),P(`Сверьте расписание и сведения об участнике с организаторами перед публикацией.`)])),B(`course-enrollment`,`Поступление на курс`,`Секции`,`Требования к участникам и последовательность записи на обучение`,()=>H(`Запись на обучение`,`Как присоединиться к курсу`,[R([`Проверьте требования`,`Подайте заявку`,`Подтвердите участие`].map((e,t)=>z([V(`Шаг `+(t+1)),N(`h3`,e),P(`Опишите фактические условия, нужные материалы и сроки для этого этапа.`)]))),P(`Уточните места, даты и критерии по актуальному расписанию курса.`)])),B(`service-status`,`Статус сервисов`,`Секции`,`Ручное обновление доступности компонентов и текущих инцидентов`,()=>H(`Состояние системы`,`Доступность сервисов`,[L([`Компонент 1`,`Компонент 2`,`Компонент 3`].map(e=>z([N(`h3`,e),V(`Укажите текущий статус`),P(`Добавьте время последней проверки и ссылку на подтверждённое сообщение об инциденте.`)]))),P(`Это статичный блок: он не получает состояние автоматически. Обновляйте его вручную и явно указывайте время проверки.`)])),B(`property-listing`,`Карточка объекта недвижимости`,`Карточки`,`Характеристики, расположение и актуальность объявления`,()=>H(`Объект`,`Характеристики объекта`,[L([F(),R([N(`h3`,`Название объекта`),P(`Укажите актуальную цену, адрес и статус предложения.`),P(`Опишите расположение и ключевые особенности без неподтверждённых обещаний.`),I(`Запросить подробности`)])]),L([`Площадь и планировка`,`Состояние и оснащение`,`Условия сделки`].map(e=>z([N(`h3`,e),P(`Добавьте точные данные и укажите дату последней проверки.`)])))])),B(`rental-terms`,`Условия аренды`,`Секции`,`Срок, платежи и ответственность сторон в одном блоке`,()=>H(`Перед оформлением`,`Условия аренды`,[L([`Платежи`,`Срок и продление`,`Правила проживания`].map(e=>z([N(`h3`,e),P(`Укажите точные суммы, даты, исключения и порядок согласования.`),I(`Полные условия`)]))),P(`Сверьте описание с актуальным договором и применимыми правилами до публикации.`)])),B(`trip-itinerary`,`Маршрут поездки`,`Секции`,`Дни, точки маршрута и практические детали перемещения`,()=>H(`План поездки`,`Маршрут по дням`,[R([1,2,3].map(e=>z([V(`День `+e),N(`h3`,`Название этапа`),P(`Укажите место старта, точки маршрута и подтверждённое время.`),P(`Добавьте способ переезда, длительность и важные условия доступа.`)]))),P(`Проверьте расписания, часы работы и сезонные ограничения перед поездкой.`)])),B(`menu-allergens`,`Состав блюд и аллергены`,`Секции`,`Ингредиенты, пищевые ограничения и предупреждения о контакте`,()=>H(`Информация о блюдах`,`Состав и аллергены`,[L([`Название блюда 1`,`Название блюда 2`,`Название блюда 3`].map(e=>z([N(`h3`,e),P(`Перечислите ингредиенты по актуальной рецептуре.`),V(`Аллергены: укажите подтверждённые`),P(`Сообщите о возможном перекрёстном контакте, если это применимо.`)]))),P(`Сверьте сведения с кухней и действующими правилами маркировки до публикации.`)])),B(`clinic-visit-prep`,`Подготовка к визиту`,`Секции`,`Организационные инструкции до приёма и в день посещения`,()=>H(`Перед приёмом`,`Как подготовиться к визиту`,[L([`До визита`,`В день приёма`,`Если планы изменились`].map(e=>z([N(`h3`,e),P(`Укажите только актуальные организационные инструкции клиники.`),P(`Добавьте контакты, время прибытия или порядок переноса записи.`)]))),P(`Этот блок предназначен для логистики визита; медицинские рекомендации согласуйте с клиникой.`)])),B(`software-requirements`,`Требования к программному продукту`,`Секции`,`Поддерживаемые среды, доступ и необходимые интеграции`,()=>H(`Перед началом`,`Что понадобится для работы`,[L([`Поддерживаемая среда`,`Доступ и учётная запись`,`Совместимость и интеграции`].map(e=>z([N(`h3`,e),P(`Укажите проверенные версии, роли, ограничения и необходимые настройки.`)]))),P(`Уточните дату проверки и перечислите известные ограничения совместимости.`)])),B(`research-methodology`,`Методология исследования`,`Статьи`,`Вопрос, метод, период сбора данных и ограничения`,()=>H(`О методе`,`Как проводилось исследование`,[L([`Вопрос и источники`,`Метод и период`,`Ограничения`].map(e=>z([N(`h3`,e),P(`Опишите проверяемые источники и принятый способ сбора данных.`),P(`Укажите период, объём выборки или ограничения, если они применимы.`)]))),P(`Не обобщайте выводы за пределы данных и обозначенного периода.`)])),B(`donation-transparency`,`Отчёт о пожертвованиях`,`Статьи`,`Цели сбора, распределение средств и период отчётности`,()=>H(`Отчётность`,`Как используются пожертвования`,[L([`Цель сбора`,`Распределение средств`,`Отчёт и подтверждения`].map(e=>z([N(`h3`,e),P(`Покажите фактические суммы, доли и даты по подтверждённым документам.`)]))),P(`Отдельно раскройте комиссии и нераспределённый остаток, если они есть. Обновите отчётный период.`)])),B(`vacancy-detail`,`Описание вакансии`,`Команда`,`Обязанности, требования и прозрачные условия роли`,()=>H(`Вакансия`,`Название должности`,[L([R([V(`Формат и город`),P(`Укажите занятость, формат работы и локацию.`),N(`h3`,`Задачи`),P(`Опишите основные обязанности и зону ответственности.`),N(`h3`,`Требования`),P(`Перечислите действительно необходимые навыки.`)]),z([N(`h3`,`Условия`),P(`Укажите оформление, оплату и график без общих обещаний.`),P(`Расскажите, как проходит отбор.`),{...I(`Откликнуться`),attributes:{href:`mailto:jobs@example.com`}}])])])),B(`course-outcomes`,`Результаты обучения`,`Секции`,`Навыки, материалы и формат итоговой проверки`,()=>H(`После обучения`,`Что будет в результате`,[L([`Навык 1`,`Навык 2`,`Итоговый материал`].map(e=>z([N(`h3`,e),P(`Опишите конкретный результат и как он проверяется.`)]))),P(`Укажите требования к завершению курса и условия выдачи документа, если он предусмотрен.`)])),B(`event-ticket-options`,`Варианты участия`,`Цены`,`Типы билетов и условия доступа на событие`,()=>H(`Участие`,`Выберите формат посещения`,[L([`Базовый билет`,`Расширенный билет`,`Онлайн-доступ`].map(e=>z([N(`h3`,e),P(`Укажите стоимость и что входит.`),P(`Дата окончания продаж и условия возврата.`),I(`Условия участия`)]))),P(`Блок описывает варианты. Подключите отдельную систему регистрации и оплаты, если она нужна.`)])),B(`venue-guidelines`,`Правила посещения`,`Секции`,`Порядок прибытия, регистрации и участия`,()=>H(`Перед визитом`,`Правила посещения`,[{tagName:`ol`,style:{...jn,display:`flex`,"flex-direction":`column`,gap:`16px`,padding:`0 0 0 24px`},components:[`Когда и куда прибыть`,`Что взять с собой`,`Как связаться с организатором`].map(e=>({tagName:`li`,components:[N(`h3`,e),P(`Добавьте точные инструкции и применимые ограничения.`)]}))},I(`Задать вопрос организатору`)])),B(`volunteer-roles`,`Волонтёрские роли`,`Команда`,`Задачи, график и требования к участникам`,()=>H(`Участие в проекте`,`Нужна помощь команды`,[L([`Роль 1`,`Роль 2`,`Роль 3`].map(e=>z([N(`h3`,e),P(`Опишите конкретные задачи и нужные навыки.`),P(`Укажите даты, часы, место и контакт координатора.`),I(`Связаться с координатором`)])))])),B(`case-results`,`Результаты проекта`,`Статьи`,`Метрики с периодом, базой сравнения и источником`,()=>H(`Проверяемый результат`,`Что изменилось после проекта`,[L([`Показатель 1`,`Показатель 2`,`Показатель 3`].map(e=>z([N(`h3`,`Укажите значение`),V(e),P(`Укажите исходное значение и период сравнения.`),P(`Добавьте источник данных и метод расчёта.`)]))),P(`Публикуйте только подтверждённые цифры с согласованным источником.`)])),B(`project-roadmap`,`План проекта`,`Секции`,`Этапы, результаты и точки согласования`,()=>H(`План работы`,`Этапы проекта`,[R([`Исследование`,`Подготовка решения`,`Проверка и передача`].map((e,t)=>z([V(`Этап `+(t+1)),N(`h3`,e),P(`Укажите срок, ответственного и ожидаемый материал.`),P(`Опишите условие согласования перехода дальше.`)])))])),B(`warranty-care`,`Гарантия и обслуживание`,`Секции`,`Условия поддержки после покупки или завершения работ`,()=>H(`После завершения`,`Поддержка и обслуживание`,[L([z([N(`h3`,`Гарантийные условия`),P(`Укажите срок, покрытие, исключения и порядок обращения.`)]),R([N(`h3`,`Регулярный уход`),P(`Опишите обслуживание, которое требуется и кем оно выполняется.`),N(`h3`,`Нужна помощь?`),P(`Укажите канал и часы работы поддержки.`),I(`Обратиться в поддержку`)])]),P(`Замените текст утверждёнными условиями гарантии и договора.`)])),B(`breadcrumbs`,`Навигационная цепочка`,`Навигация`,`Компактный путь от главной до текущей страницы`,()=>({tagName:`nav`,attributes:{"aria-label":`Навигационная цепочка`},style:{...jn,display:`flex`,"flex-wrap":`wrap`,gap:`10px`,padding:`16px 6%`},components:[I(`Главная`),P(`/`),I(`Раздел`),P(`/`),{type:`text`,tagName:`span`,content:`Текущая страница`,style:{...jn,"font-weight":`700`}}]})),B(`article-byline`,`Автор материала`,`Статьи`,`Автор, дата публикации и краткая биография`,()=>H(`Материал`,`Заголовок публикации`,[P(`Укажите дату публикации и последнего обновления.`),L([F(),R([N(`h3`,`Имя автора`),P(`Профессиональная роль и тема материала.`),P(`Краткая биография, подтверждённые сведения об опыте.`),I(`Другие материалы автора`)])])])),B(`release-notes`,`История обновлений`,`Статьи`,`Список версий с изменениями и датами`,()=>H(`Обновления`,`Что изменилось`,[R([1,2,3].map(e=>({tagName:`article`,style:{display:`flex`,"flex-direction":`column`,gap:`12px`,padding:`24px 0`,"border-bottom":`1px solid `+M(`line`)},components:[V(`Версия и дата`),N(`h3`,`Название обновления `+e),P(`Перечислите изменения, которые действительно вошли в эту версию.`),I(`Подробнее об обновлении`)]})))])),B(`product-variants`,`Варианты товара`,`Карточки`,`Размеры, материалы и особенности вариантов`,()=>H(`Варианты`,`Выберите конфигурацию`,[L([`Вариант 1`,`Вариант 2`,`Вариант 3`].map(e=>z([N(`h3`,e),P(`Размер или формат: укажите значение.`),P(`Материал и комплектация.`),P(`Стоимость и доступность.`),I(`Уточнить детали`)])))])),B(`feature-matrix`,`Сравнение функций`,`Секции`,`Сопоставление возможностей предложений по критериям`,()=>H(`Сопоставление`,`Что входит в каждый вариант`,[L([`Критерий 1`,`Критерий 2`,`Критерий 3`].map(e=>z([V(e),N(`h3`,`Вариант А`),P(`Укажите состав или доступность.`),N(`h3`,`Вариант Б`),P(`Укажите отличие или условие.`)]))),P(`Проверьте, что все сравниваемые условия актуальны.`)])),B(`onboarding-checklist`,`Чек-лист подготовки`,`Секции`,`Список шагов, которые стоит завершить перед началом`,()=>H(`Подготовка`,`Пройдите эти шаги`,[{tagName:`ul`,style:{...jn,display:`flex`,"flex-direction":`column`,gap:`16px`,padding:`0 0 0 24px`},components:[`Соберите исходные материалы`,`Согласуйте участников и сроки`,`Подготовьте вопросы к первой встрече`].map(e=>({tagName:`li`,components:[N(`h3`,e),P(`Добавьте пояснение, документ или срок выполнения.`)]}))},I(`Задать вопрос перед стартом`)])),B(`support-expectations`,`Как работает поддержка`,`Секции`,`Каналы, часы доступности и условия ответа`,()=>H(`Поддержка`,`Чего ожидать от обращения`,[L([`Канал связи`,`Часы работы`,`Срок ответа`].map(e=>z([N(`h3`,e),P(`Укажите актуальные часы, сроки и ограничения обслуживания.`)]))),P(`Уточните, что делать в нерабочее время и какие данные приложить.`),I(`Написать в поддержку`)])),B(`privacy-contacts`,`Вопросы о данных`,`Секции`,`Контакт и утверждённая информация об обработке данных`,()=>H(`Конфиденциальность`,`К кому обратиться по вопросам данных`,[P(`Укажите название ответственного лица или подразделения.`),P(`Добавьте утверждённые сведения о целях обработки, хранении и порядке обращения.`),{...I(`Написать ответственному`),attributes:{href:`mailto:privacy@example.com`}},I(`Политика конфиденциальности`)])),B(`branch-locations`,`Филиалы`,`Секции`,`Филиалы с адресами, временем и контактной ссылкой`,()=>H(`Рядом с вами`,`Наши филиалы`,[L([1,2,3].map(e=>z([N(`h3`,`Филиал `+e),P(`Укажите точный адрес и ориентиры.`),P(`Режим работы и доступность.`),I(`Построить маршрут`)])))])),B(`event-calendar`,`Календарь событий`,`Статьи`,`Несколько дат и анонсов в одном списке`,()=>H(`В календаре`,`Ближайшие события`,[R([1,2,3].map(e=>({tagName:`article`,style:{display:`flex`,"flex-wrap":`wrap`,gap:`20px`,padding:`20px 0`,"border-bottom":`1px solid `+M(`line`)},components:[R([V(`Укажите дату`),P(`Начало и продолжительность`)]),R([N(`h3`,`Название события `+e),P(`Краткое описание темы, формата и аудитории.`),I(`Условия участия`)])]})))])),B(`review-sources`,`Отзывы с источниками`,`Секции`,`Цитаты с именем, датой и ссылкой на исходный отзыв`,()=>H(`Обратная связь`,`Отзывы клиентов`,[L([1,2,3].map(e=>z([P(`Добавьте отзыв с разрешением на публикацию.`),N(`h3`,`Имя автора `+e),P(`Услуга и дата обращения`),I(`Источник отзыва`)])))])),B(`awards-history`,`Награды и достижения`,`Статьи`,`Достижения с годом и подтверждающим источником`,()=>H(`История`,`Наши достижения`,[R([1,2,3].map(e=>({tagName:`article`,style:{display:`flex`,"flex-direction":`column`,gap:`12px`,padding:`24px 0`,"border-bottom":`1px solid `+M(`line`)},components:[V(`Укажите год`),N(`h3`,`Название достижения `+e),P(`Кто присудил и за что — проверьте формулировку.`),I(`Подтверждающий источник`)]})))])),B(`email-updates`,`Обновления по email`,`Секции`,`Короткое приглашение связаться для получения новостей`,()=>H(`Новости проекта`,`Получать обновления`,[P(`Укажите, какие письма и как часто вы отправляете.`),P(`Добавьте адрес для подписки и информацию об обработке данных.`),{...I(`Написать для подписки`),attributes:{href:`mailto:hello@example.com`}}])),B(`accessibility-info`,`Доступность пространства`,`Секции`,`Важная информация о входе и условиях посещения`,()=>H(`Планируйте визит`,`Доступность`,[L([`Вход и передвижение`,`Помещения`,`Дополнительная помощь`].map(e=>z([N(`h3`,e),P(`Укажите проверенные условия и доступные возможности.`)]))),P(`Уточните дату проверки этой информации и контакт для вопросов.`)])),B(`community-participation`,`Участие в сообществе`,`Секции`,`Форматы участия, встречи и контакт организатора`,()=>H(`Сообщество`,`Можно присоединиться`,[L([`Участвовать`,`Предложить тему`,`Помочь проекту`].map(e=>z([N(`h3`,e),P(`Опишите требования, сроки и ожидаемый формат участия.`),I(`Связаться с организаторами`)])))])),B(`newsletter-contact`,`Письмо с обновлениями`,`Обложки`,`Контактная полоса с темой рассылки и ссылкой на email`,()=>H(`На связи`,`Новости без лишнего шума`,[P(`Расскажите о содержании писем и периодичности отправки.`),P(`Укажите, как отказаться от рассылки и где прочитать политику данных.`),{...Mn(),content:`Написать для подписки`,attributes:{href:`mailto:hello@example.com`}}])),B(`credentials`,`Квалификация и документы`,`Секции`,`Лицензии, сертификаты и документы с датами`,()=>H(`Подтверждения`,`Квалификация и документы`,[L([1,2,3].map(e=>z([V(`Укажите тип документа`),N(`h3`,`Название документа `+e),P(`Кем выдан, дата и срок действия — заполните по документу.`),I(`Открыть документ`)])))])),B(`partner-network`,`Партнёры`,`Секции`,`Партнёрские организации и описание сотрудничества`,()=>H(`Сотрудничаем`,`Наши партнёры`,[L([1,2,3,4].map(e=>z([V(`Логотип партнёра`),N(`h3`,`Название организации `+e),P(`Уточните характер сотрудничества и согласуйте упоминание.`),I(`Подробнее о партнёрстве`)])))])),B(`social-channels`,`Мы в сети`,`Навигация`,`Ссылки на официальные страницы в соцсетях`,()=>H(`На связи`,`Следите за обновлениями`,[L([`Telegram`,`ВКонтакте`,`YouTube`].map(e=>z([N(`h3`,e),P(`Добавьте ссылку на официальную страницу.`),I(`Перейти`)])))])),B(`payment-options`,`Способы оплаты`,`Секции`,`Поддерживаемые способы и условия оплаты`,()=>H(`Оплата`,`Как можно оплатить`,[L([`Способ оплаты 1`,`Способ оплаты 2`,`Для организаций`].map(e=>z([N(`h3`,e),P(`Укажите доступность, валюту и ограничения этого способа.`)]))),P(`Укажите порядок выставления счёта и применимые условия.`)])),B(`service-coverage`,`География работы`,`Секции`,`Зона обслуживания и условия выезда`,()=>H(`География`,`Где мы работаем`,[L([z([N(`h3`,`Основные направления`),P(`Перечислите реальные города и районы обслуживания.`),P(`Уточните доступность и часы выезда.`)]),R([N(`h3`,`Удалённая работа`),P(`Опишите, какие задачи можно решить дистанционно.`),I(`Проверить возможность`)])])])),B(`metrics-strip`,`Ключевые показатели`,`Секции`,`Показатели с редактируемыми значениями и пояснениями`,()=>H(`В цифрах`,`Коротко о проекте`,[L([`Показатель 1`,`Показатель 2`,`Показатель 3`,`Показатель 4`].map(e=>R([N(`h3`,`Укажите значение`),V(e),P(`Добавьте источник и период, подтверждающие показатель.`)])))])),B(`question-groups`,`Вопросы по темам`,`Секции`,`Несколько групп ответов без скрытого JavaScript`,()=>H(`Помощь`,`Ответы по темам`,[L([`До обращения`,`В процессе работы`,`После завершения`].map(e=>z([N(`h3`,e),R([1,2].map(e=>R([N(`h3`,`Вопрос `+e),P(`Добавьте проверенный ответ на частый вопрос.`)])))])))])),B(`image-comparison`,`Сравнение изображений`,`Галереи`,`Два изображения с пояснёнными подписями`,()=>H(`Сравнение`,`Два состояния или подхода`,[L([`Первый вариант`,`Второй вариант`].map(e=>R([F(),V(e),P(`Опишите контекст, дату и различия между изображениями.`)])))])),B(`option-comparison`,`Сравнение вариантов`,`Секции`,`Два варианта с одинаковыми критериями сравнения`,()=>H(`Сравните`,`Какой вариант подходит вам`,[L([`Вариант А`,`Вариант Б`].map(e=>z([N(`h3`,e),P(`Подходит для: укажите аудиторию`),P(`Состав: перечислите отличия`),P(`Условия: укажите ограничения`),I(`Изучить вариант`)])))])),B(`before-start`,`Перед началом`,`Секции`,`Требования и подготовка в двух колонках`,()=>H(`Подготовка`,`Что понадобится для старта`,[L([z([N(`h3`,`Подготовьте материалы`),P(`Перечислите необходимые файлы, исходные данные и пожелания.`)]),R([N(`h3`,`Проверьте условия`),P(`Укажите требования к участию или началу работы.`),N(`h3`,`Если остались вопросы`),P(`Расскажите, куда обратиться за уточнениями.`),I(`Задать вопрос`)])])])),B(`download-catalog`,`Каталог файлов`,`Секции`,`Список материалов с форматом и описанием`,()=>H(`Материалы`,`Выберите нужный файл`,[R([1,2,3].map(e=>({tagName:`article`,style:{display:`flex`,"flex-direction":`column`,gap:`12px`,padding:`24px 0`,"border-bottom":`1px solid `+M(`line`)},components:[V(`Укажите формат`),N(`h3`,`Материал `+e),P(`Содержание, версия и размер файла.`),I(`Открыть файл`)]})))])),B(`page-directory`,`Навигатор разделов`,`Навигация`,`Карточки ссылок на важные страницы сайта`,()=>H(`Навигация`,`Быстро найдите нужное`,[L([`О проекте`,`Предложения`,`Полезные материалы`,`Контакты`].map(e=>({...I(),type:`link-block`,tagName:`a`,style:{...z([]).style,"text-decoration":`none`},components:[N(`h3`,e),P(`Кратко опишите содержимое раздела.`)]})))])),B(`service-boundaries`,`Границы услуги`,`Секции`,`Что входит в работу и что согласуется отдельно`,()=>H(`Без неожиданностей`,`Согласуем состав работы`,[L([z([N(`h3`,`Входит в предложение`),P(`Перечислите работы, включённые в основную стоимость.`)]),z([N(`h3`,`Обсуждается отдельно`),P(`Укажите дополнительные работы и условия их согласования.`)])]),P(`Добавьте условия изменения объёма и сроков работы.`)])),B(`appointment-info`,`Запись на встречу`,`Секции`,`Подготовка к встрече и способ записи по ссылке`,()=>H(`Встреча`,`Давайте обсудим задачу`,[L([R([N(`h3`,`Как проходит встреча`),P(`Укажите формат, длительность и стоимость, если она предусмотрена.`),N(`h3`,`Что подготовить`),P(`Опишите, какие вопросы и материалы будут полезны.`)]),z([V(`По предварительной записи`),N(`h3`,`Выберите время`),P(`Укажите доступные часы и способ подтверждения встречи.`),I(`Перейти к записи`)])])])),B(`exhibition-grid`,`Коллекция работ`,`Галереи`,`Вертикальные фотографии и авторские подписи`,()=>H(`Коллекция`,`Работы и их истории`,[L([1,2,3].map(e=>R([{...F(),style:{...F().style,"aspect-ratio":`3/4`}},N(`h3`,`Название работы `+e),P(`Автор, год и техника — укажите реальные данные.`),I(`История работы`)])))])),B(`policy-summary`,`Краткие условия`,`Секции`,`Обзор правил и ссылка на полный документ`,()=>H(`Условия`,`Главное перед обращением`,[R([`Порядок работы`,`Изменения и отмена`,`Использование материалов`].map(e=>R([N(`h3`,e),P(`Добавьте утверждённые условия, действующие для вашего предложения.`)]))),I(`Прочитать полные условия`)])),B(`cover-panorama`,`Обложка-панорама`,`Обложки`,`Вступление, компактный CTA и широкое фото`,()=>H(`Главное`,`Покажите вашу идею`,[P(`Одно предложение о пользе вашего проекта.`),Mn(),{...F(),style:{...F().style,"aspect-ratio":`16/7`,"min-height":`220px`}}])),B(`feature-spotlight`,`Акцент на возможности`,`Секции`,`Большое изображение и пояснение в отдельной колонке`,()=>H(`В деталях`,`Одна возможность — больше пользы`,[L([F(),R([V(`Особенность`),N(`h3`,`Что меняется для клиента`),P(`Объясните конкретную возможность на понятном примере.`),I(`Изучить подробнее`)])])])),B(`destination-grid`,`Направления`,`Галереи`,`Фотографии направлений с короткими пояснениями`,()=>H(`Направления`,`Откройте новые места`,[L([1,2,3].map(e=>R([F(),V(`Направление `+e),N(`h3`,`Название места`),P(`Сезон, формат и особенности поездки.`),I(`Посмотреть направление`)])))])),B(`event-announcement`,`Анонс события`,`Секции`,`Афиша рядом с датой, местом и описанием`,()=>H(`Событие`,`Название предстоящего события`,[L([R([V(`Укажите дату`),P(`Укажите место и формат проведения.`),P(`Расскажите, что ждёт участников и кому будет интересно.`),I(`Условия участия`)]),F()])])),B(`case-timeline`,`Кейс по этапам`,`Статьи`,`Обложка кейса и последовательное раскрытие работы`,()=>H(`История работы`,`От задачи к решению`,[F(),R([`Исходная ситуация`,`Принятые решения`,`Что получилось`].map((e,t)=>({tagName:`article`,style:{display:`flex`,"flex-wrap":`wrap`,gap:`24px`,padding:`24px 0`,"border-bottom":`1px solid `+M(`line`)},components:[V(`0`+(t+1)),R([N(`h3`,e),P(`Добавьте проверенные детали этого этапа без вымышленных результатов.`)])]})))])),B(`offer-inclusions`,`Состав предложения`,`Цены`,`Краткое предложение рядом с подробным составом`,()=>H(`Предложение`,`Всё необходимое в одном месте`,[L([z([N(`h3`,`Название предложения`),P(`Укажите стоимость и период действия.`),Mn()]),R([`Что входит`,`Что понадобится от вас`,`Дополнительные условия`].map(e=>R([N(`h3`,e),P(`Уточните состав и реальные ограничения предложения.`)])))])])),B(`photo-story`,`Фотоистория`,`Галереи`,`Два снимка с общим описанием и подписями`,()=>H(`За кадром`,`История в фотографиях`,[P(`Кратко расскажите, что объединяет эти фотографии.`),L([1,2].map(e=>({tagName:`div`,style:{margin:`0`,display:`flex`,"flex-direction":`column`,gap:`12px`},components:[F(),{type:`text`,tagName:`p`,content:`Описание кадра `+e,style:jn}]})))])),B(`founder-letter`,`Письмо основателя`,`Команда`,`Портрет, личное обращение и подпись`,()=>H(`Личное обращение`,`Несколько слов от основателя`,[L([F(),R([P(`Добавьте авторское обращение о ценностях, подходе и причинах создания проекта.`),P(`Расскажите, что вы хотите изменить для ваших клиентов.`),N(`h3`,`Имя основателя`),P(`Роль в проекте`)])])])),B(`press-feature`,`Публикация о проекте`,`Статьи`,`Выделенный материал с фото и ссылкой на источник`,()=>H(`Публикация`,`Название материала`,[L([R([V(`Укажите издание и дату`),P(`Добавьте точное краткое описание опубликованного материала.`),I(`Читать в источнике`)]),F()])])),B(`opening-hours`,`Часы работы`,`Секции`,`Режим работы и контактная информация рядом`,()=>H(`Время встречи`,`Когда мы открыты`,[L([z([N(`h3`,`Режим работы`),...[`Будни`,`Суббота`,`Воскресенье`].map(e=>P(e+`: укажите часы`))]),R([N(`h3`,`Перед визитом`),P(`Укажите условия записи, выходные и праздничные изменения.`),P(`Адрес и доступные контакты`),I(`Связаться перед визитом`)])])])),B(`course-program`,`Программа курса`,`Секции`,`Модули курса с темами и описанием практики`,()=>H(`Программа`,`Чему посвящено обучение`,[R([1,2,3].map(e=>z([V(`Модуль `+e),N(`h3`,`Название модуля`),P(`Перечислите темы и навыки, которые будут разобраны.`),P(`Практика: опишите задание.`)])))])),B(`learning-format`,`Формат обучения`,`Секции`,`Занятия, практика и обратная связь`,()=>H(`Как учимся`,`Обучение в удобном формате`,[L([`Занятия`,`Практика`,`Обратная связь`].map(e=>z([N(`h3`,e),P(`Опишите реальный формат, длительность и условия участия.`)])))])),B(`instructor-grid`,`Преподаватели`,`Команда`,`Фото, специализация и темы преподавателей`,()=>H(`Преподаватели`,`Кто ведёт занятия`,[L([1,2].map(()=>z([F(),N(`h3`,`Имя преподавателя`),P(`Специализация и подтверждённый опыт`),P(`Темы и модули, которые ведёт преподаватель.`)])))])),B(`audience-fit`,`Для кого`,`Секции`,`Группы аудитории и подходящие задачи`,()=>H(`Для кого`,`Найдите свою задачу`,[L([`Начинающим`,`Практикующим`,`Командам`].map(e=>z([N(`h3`,e),P(`Уточните исходный опыт и задачи этой группы.`),P(`Расскажите, чем предложение будет полезно.`)])))])),B(`project-deliverables`,`Что вы получите`,`Секции`,`Конкретные материалы и результаты работы`,()=>H(`Состав работы`,`Что входит в результат`,[L([`Материалы`,`Готовое решение`,`Инструкции`].map(e=>z([N(`h3`,e),P(`Перечислите конкретные материалы и границы передачи результата.`)])))])),B(`collaboration-steps`,`Начало сотрудничества`,`Секции`,`Первое обращение, согласование и старт`,()=>H(`Начнём с простого`,`Как начать работу`,[L([`Расскажите о задаче`,`Согласуем условия`,`Начнём работу`].map((e,t)=>z([V(`Шаг `+(t+1)),N(`h3`,e),P(`Опишите действия, необходимые на этом шаге.`)]))),Mn()])),B(`job-openings`,`Вакансии`,`Карточки`,`Открытые роли с условиями и ссылками`,()=>H(`Карьера`,`Присоединяйтесь к команде`,[R([1,2].map(e=>z([N(`h3`,`Название вакансии `+e),V(`Укажите формат работы`),P(`Опишите задачи, требования и реальные условия.`),I(`Подробнее о вакансии`)])))])),B(`resource-library`,`База знаний`,`Статьи`,`Подборки руководств и полезных материалов`,()=>H(`База знаний`,`Материалы для вашей работы`,[L([`Руководства`,`Разборы`,`Чек-листы`].map(e=>z([N(`h3`,e),P(`Кратко расскажите, что посетитель найдёт в этой подборке.`),I(`Перейти к материалам`)])))])),B(`office-grid`,`Наши пространства`,`Галереи`,`Фото и адреса офисов или филиалов`,()=>H(`Наши пространства`,`Где мы работаем`,[L([1,2].map(e=>z([F(),N(`h3`,`Название пространства `+e),P(`Укажите реальный адрес и часы работы.`),I(`Подробнее о месте`)])))])),B(`support-channels`,`Помощь и поддержка`,`Секции`,`Каналы связи с описанием назначения`,()=>H(`Поддержка`,`Поможем разобраться`,[L([`Общие вопросы`,`Помощь клиентам`,`Сотрудничество`].map(e=>z([N(`h3`,e),P(`Укажите, какие вопросы решает этот канал и когда он доступен.`),I(`Связаться`)])))])),B(`product-catalog`,`Каталог товаров`,`Карточки`,`Карточки товаров с фото, ценой и ссылкой`,()=>H(`Каталог`,`Выберите свой вариант`,[L([1,2,3].map(e=>z([F(),N(`h3`,`Товар `+e),P(`Материал, размер и ключевые особенности.`),P(`Укажите цену`),I(`Открыть товар`)])))])),B(`product-detail`,`Описание товара`,`Карточки`,`Крупное фото, характеристики и действие`,()=>H(`Подробнее`,`Название товара`,[L([F(),R([P(`Расскажите о назначении и особенностях товара.`),N(`h3`,`Характеристики`),P(`Материал: укажите значение`),P(`Размер: укажите значение`),P(`Цена: укажите актуальную стоимость`),I(`Уточнить наличие`)])])])),B(`restaurant-menu`,`Меню заведения`,`Цены`,`Блюда, состав и цены в двух группах`,()=>H(`Меню`,`Вкус вашего дня`,[L([`Основные блюда`,`Напитки`].map(e=>z([N(`h3`,e),...[`Первая позиция`,`Вторая позиция`].map(e=>R([N(`h3`,e),P(`Укажите состав и размер порции.`),P(`Укажите цену`)]))])))])),B(`weekly-schedule`,`Расписание занятий`,`Секции`,`Дни, время и описание занятий`,()=>H(`Расписание`,`Выберите удобное время`,[L([`Понедельник`,`Среда`,`Пятница`].map(e=>z([V(e),N(`h3`,`Название занятия`),P(`Укажите время и продолжительность.`),P(`Формат и место проведения`),I(`Узнать подробнее`)])))])),B(`document-links`,`Документы и файлы`,`Секции`,`Ссылки на документы с пояснениями`,()=>H(`Документы`,`Полезные материалы`,[L([`Презентация`,`Реквизиты`,`Условия работы`].map(e=>z([N(`h3`,e),P(`Опишите содержимое и укажите формат файла.`),I(`Открыть документ`)])))])),B(`service-detail`,`Услуга подробно`,`Секции`,`Состав услуги, этапы и следующий шаг`,()=>H(`Услуга`,`Решение для вашей задачи`,[P(`Опишите, кому подходит услуга и какую задачу она решает.`),L([R([N(`h3`,`Что входит`),P(`Перечислите конкретные работы и границы услуги.`),N(`h3`,`Сроки и условия`),P(`Укажите реальные условия и порядок взаимодействия.`)]),z([N(`h3`,`Обсудим детали`),P(`Расскажите, что нужно подготовить для первого обращения.`),Mn()])])])),B(`delivery-info`,`Доставка и оплата`,`Секции`,`Условия получения, оплаты и возврата`,()=>H(`Условия`,`Как получить заказ`,[L([`Доставка`,`Оплата`,`Возврат`].map(e=>z([N(`h3`,e),P(`Укажите действующие условия, сроки и ограничения.`)])))])),B(`location-card`,`Как добраться`,`Секции`,`Фото места, адрес и маршрут по ссылке`,()=>H(`Расположение`,`Ждём вас в гости`,[L([F(),R([N(`h3`,`Название места`),P(`Укажите точный адрес.`),P(`Ориентиры, вход и доступность.`),P(`Укажите часы работы.`),I(`Открыть маршрут`)])])])),B(`editorial-intro`,`Вступление с цитатой`,`Статьи`,`Вводный текст и выделенная авторская цитата`,()=>H(`История`,`Идея, с которой всё началось`,[L([R([P(`Расскажите о предпосылках и главной идее проекта.`),P(`Добавьте детали, которые помогут читателю понять ваш подход.`)]),z([N(`h3`,`Главная мысль`),P(`Добавьте реальную цитату с разрешением на использование.`),P(`Имя автора и его роль`)])])])),B(`gallery-captions`,`Фото с подписями`,`Галереи`,`Четыре фотографии с редактируемыми описаниями`,()=>H(`В деталях`,`Посмотрите ближе`,[L([1,2,3,4].map(e=>R([F(),N(`h3`,`Подпись `+e),P(`Кратко опишите, что изображено на фото.`)])))])),B(`about-split`,`О проекте с фото`,`Секции`,`Фото, история проекта и компактное действие`,()=>H(`О проекте`,`Познакомимся ближе`,[L([F(),R([N(`h3`,`Что для нас важно`),P(`Расскажите о своём подходе, команде и задачах, которые помогаете решать.`),Mn()])])])),B(`services-list`,`Список услуг`,`Секции`,`Услуги с описаниями и ссылками`,()=>H(`Услуги`,`Чем мы можем помочь`,[R([`Первая услуга`,`Вторая услуга`,`Третья услуга`].map(e=>z([N(`h3`,e),P(`Опишите состав услуги и для кого она подходит.`),I(`Обсудить задачу`)])))])),B(`benefits-split`,`Преимущества с фото`,`Секции`,`Фотография и три тезиса об отличиях`,()=>H(`Наш подход`,`Почему выбирают нас`,[L([R([`Внимание к задаче`,`Понятный процесс`,`Поддержка`].map(e=>R([N(`h3`,e),P(`Добавьте конкретную особенность вашего подхода.`)]))),F()])])),B(`portfolio-grid`,`Портфолио`,`Галереи`,`Три проекта с фото и описаниями`,()=>H(`Наши работы`,`Избранные проекты`,[L([1,2,3].map(e=>z([F(),N(`h3`,`Проект `+e),P(`Опишите задачу и реально выполненную работу.`),I(`Смотреть проект`)])))])),B(`case-study`,`Кейс проекта`,`Статьи`,`Задача, подход и результат без выдуманных метрик`,()=>H(`Кейс`,`История проекта`,[F(),L([`Задача`,`Решение`,`Результат`].map(e=>R([N(`h3`,e),P(`Добавьте проверенные сведения об этом этапе проекта.`)])))])),B(`faq-grid`,`Вопросы в колонках`,`Секции`,`Открытые ответы без скрытого JavaScript`,()=>H(`Вопросы и ответы`,`Что важно знать`,[L([1,2,3,4].map(e=>R([N(`h3`,`Вопрос `+e),P(`Добавьте краткий и полезный ответ для посетителя.`)])))])),B(`price-list`,`Прайс-лист`,`Цены`,`Перечень услуг и редактируемых цен`,()=>H(`Стоимость`,`Услуги и цены`,[R([1,2,3].map(e=>z([N(`h3`,`Услуга `+e),P(`Что входит в услугу`),P(`Укажите актуальную стоимость`)])))])),B(`event-program`,`Программа события`,`Секции`,`Последовательность этапов с редактируемым временем`,()=>H(`Программа`,`План мероприятия`,[R([`Открытие`,`Основная часть`,`Завершение`].map(e=>z([V(`Укажите время`),N(`h3`,e),P(`Расскажите, что будет происходить на этом этапе.`)])))])),B(`team-profile`,`Профиль специалиста`,`Команда`,`Фото, биография и контактная ссылка`,()=>H(`Специалист`,`Познакомьтесь с экспертом`,[L([F(),R([N(`h3`,`Имя и фамилия`),P(`Должность и специализация`),P(`Расскажите о подтверждённом опыте и подходе к работе.`),I(`Связаться`)])])])),B(`cta-split`,`Контактный акцент`,`Секции`,`Выделенная карточка с призывом и ссылкой`,()=>H(`Следующий шаг`,`Обсудим вашу задачу`,[z([P(`Опишите, с каким вопросом к вам можно обратиться и что будет дальше.`),Mn()])])),B(`heading`,`Заголовок`,`Элементы`,`Редактируемый H2`,()=>N(`h2`,`Ваш заголовок`)),B(`paragraph`,`Абзац`,`Элементы`,`Основной текст без секции`,()=>P(`Добавьте содержательный текст для вашей аудитории.`)),B(`text-link`,`Ссылка`,`Элементы`,`Текстовая ссылка с редактируемым адресом`,()=>I()),B(`link-block`,`Ссылка-контейнер`,`Элементы`,`Кликабельная область с вложенными элементами`,()=>({type:`link-block`,tagName:`a`,attributes:{href:`https://example.com`},style:{display:`block`,padding:`24px`,"text-decoration":`none`,border:`1px solid `+M(`line`),"border-radius":M(`radius`)},components:[N(`h3`,`Открыть материал`),P(`Измените адрес в свойствах ссылки.`)]})),B(`bullet-list`,`Список`,`Элементы`,`Маркированные редактируемые пункты`,()=>({tagName:`ul`,style:{...jn,padding:`0 0 0 24px`},components:[`Первый пункт`,`Второй пункт`,`Третий пункт`].map(e=>({type:`text`,tagName:`li`,content:e}))})),B(`divider`,`Разделитель`,`Элементы`,`Горизонтальная линия`,()=>({tagName:`hr`,style:{width:`100%`,border:`0`,"border-top":`1px solid `+M(`line`),margin:`24px 0`}})),B(`spacer`,`Отступ`,`Компоновка`,`Пустая область с изменяемой высотой`,()=>({tagName:`div`,name:`Отступ`,style:{height:`48px`,width:`100%`}})),B(`quote`,`Цитата`,`Элементы`,`Текст и подпись автора без вымышленных отзывов`,()=>z([P(`Добавьте цитату, которую вы вправе использовать.`),P(`Автор цитаты`)])),B(`content-card`,`Карточка`,`Карточки`,`Заголовок, описание и действие`,()=>z([N(`h3`,`Название карточки`),P(`Опишите содержание или пользу предложения.`),Mn()])),B(`image-card`,`Карточка с фото`,`Карточки`,`Фотография, заголовок и текст`,()=>z([F(),N(`h3`,`Название карточки`),P(`Выберите фото и добавьте описание.`)])),B(`card-grid`,`Сетка карточек`,`Карточки`,`Три карточки с адаптивными колонками`,()=>Nn(`Наши предложения`,[L([1,2,3].map(e=>z([N(`h3`,`Предложение `+e),P(`Замените этот текст описанием предложения.`),Mn()])))])),B(`article`,`Статья`,`Статьи`,`Заголовок, вводный текст и разделы`,()=>Nn(`Название статьи`,[P(`Кратко расскажите, о чём этот материал и кому он полезен.`),N(`h3`,`Первый раздел`),P(`Добавьте основной текст статьи.`),N(`h3`,`Второй раздел`),P(`Продолжите раскрывать тему и завершите материал выводом.`)])),B(`article-grid`,`Лента статей`,`Статьи`,`Адаптивные карточки публикаций`,()=>Nn(`Материалы`,[L([1,2,3].map(e=>z([F(),N(`h3`,`Название материала `+e),P(`Краткое описание статьи.`),I(`Читать материал`)])))])),B(`gallery`,`Галерея`,`Галереи`,`Четыре изображения; выберите фото в свойствах`,()=>Nn(`Галерея`,[L([1,2,3,4].map(()=>F()))])),B(`pricing`,`Тарифы`,`Цены`,`Сравнение предложений без выдуманных цен`,()=>Nn(`Выберите предложение`,[L([`Базовый`,`Расширенный`,`Индивидуальный`].map(e=>z([N(`h3`,e),P(`Укажите стоимость`),P(`Перечислите, что входит в предложение.`),Mn()])))])),B(`team`,`Команда`,`Команда`,`Карточки сотрудников с заменяемыми фото`,()=>Nn(`Наша команда`,[L([1,2,3].map(()=>z([F(),N(`h3`,`Имя сотрудника`),P(`Должность и область ответственности`)])))])),B(`cover-centered`,`Обложка по центру`,`Обложки`,`Заголовок, описание и компактный CTA`,()=>({tagName:`section`,name:`Обложка по центру`,style:{...jn,display:`flex`,"flex-direction":`column`,"align-items":`center`,"text-align":`center`,gap:`24px`,padding:`80px 6%`,"background-color":M(`forest`),"border-radius":M(`radius`)},components:[{...N(`h1`,`Расскажите о главном`),style:{...N(`h1`,``).style,color:M(`paper`),"max-width":`900px`}},{...P(`Объясните, что вы предлагаете и почему это важно.`),style:{...jn,color:M(`paper`),"max-width":`640px`}},{...Mn(),style:{...Mn().style,"background-color":M(`paper`),color:M(`forest`)}}]})),B(`cover-split`,`Обложка с фото`,`Обложки`,`Текст перед фото; колонки складываются на узком экране`,()=>Nn(`Ваше главное предложение`,[L([R([P(`Кратко представьте проект и его пользу.`),Mn()]),F()])])),B(`contact-details`,`Контактные данные`,`Секции`,`Адрес, часы работы и контактные ссылки`,()=>Nn(`Свяжитесь с нами`,[L([R([N(`h3`,`Адрес`),P(`Укажите реальный адрес и часы работы.`)]),R([{...I(`Email`),attributes:{href:`mailto:hello@example.com`}},{...I(`Телефон`),attributes:{href:`tel:+70000000000`}}])])])),B(`footer-columns`,`Подвал с колонками`,`Навигация`,`Описание проекта и группы ссылок`,()=>({tagName:`footer`,style:{...jn,padding:`40px 6%`,"background-color":M(`paper`)},components:[L([R([N(`h3`,`Название проекта`),P(`Краткое описание проекта.`)]),R([N(`h3`,`Разделы`),I(`Первая ссылка`),I(`Вторая ссылка`)]),R([N(`h3`,`Контакты`),I(`Контактная страница`)])])]}))],Fn=`jzcc1.`,In=Object.freeze({html:`<section class="custom-code-example"><h2>Ваш HTML</h2><p>Отредактируйте этот блок в свойствах страницы.</p></section>`,css:`.custom-code-example{padding:24px;border:1px solid #d8dfda;border-radius:12px;font:16px/1.5 system-ui,sans-serif}.custom-code-example h2{margin:0 0 8px}`,js:``}),Ln=Object.freeze({html:`<fieldset class="jz-tabs"><legend>Информационные вкладки</legend><input class="jz-tab-toggle" type="radio" id="jz-tab-about" name="jz-tab" checked><label for="jz-tab-about">Описание</label><input class="jz-tab-toggle" type="radio" id="jz-tab-details" name="jz-tab"><label for="jz-tab-details">Детали</label><input class="jz-tab-toggle" type="radio" id="jz-tab-terms" name="jz-tab"><label for="jz-tab-terms">Условия</label><div class="jz-tab-panels"><section class="jz-tab-panel"><h3>Описание</h3><p>Добавьте информацию о проекте или услуге.</p></section><section class="jz-tab-panel"><h3>Детали</h3><p>Уточните характеристики и важные особенности.</p></section><section class="jz-tab-panel"><h3>Условия</h3><p>Укажите подтверждённые условия и ограничения.</p></section></div></fieldset>`,css:`.jz-tabs{display:flex;flex-wrap:wrap;gap:8px;border:0;padding:0;margin:0;font:16px/1.5 system-ui,sans-serif;color:#17231d}.jz-tab-toggle{position:absolute;width:1px;height:1px;opacity:0}.jz-tab-toggle+label{display:inline-flex;align-items:center;min-height:42px;padding:8px 16px;border:1px solid #c9d2cb;border-radius:999px;cursor:pointer}.jz-tab-toggle:checked+label{border-color:#44755c;background:#e8f2eb;color:#214c35}.jz-tab-toggle:focus-visible+label{outline:3px solid #78ac8a;outline-offset:2px}.jz-tab-panels{width:100%;margin-top:10px;padding:20px;border:1px solid #d8dfda;border-radius:12px}.jz-tab-panel{display:none}.jz-tab-panel h3{margin:0 0 8px}.jz-tab-panel p{margin:0}.jz-tab-toggle:nth-of-type(1):checked~.jz-tab-panels .jz-tab-panel:nth-child(1),.jz-tab-toggle:nth-of-type(2):checked~.jz-tab-panels .jz-tab-panel:nth-child(2),.jz-tab-toggle:nth-of-type(3):checked~.jz-tab-panels .jz-tab-panel:nth-child(3){display:block}`,js:``});function Rn(e){let t=JSON.stringify({html:String(e?.html??``),css:String(e?.css??``),js:String(e?.js??``)}),n=new TextEncoder().encode(t),r=``;for(let e=0;e<n.length;e+=32768)r+=String.fromCharCode(...n.subarray(e,e+32768));return Fn+btoa(r).replace(/\+/g,`-`).replace(/\//g,`_`).replace(/=+$/,``)}function zn(e){try{if(typeof e!=`string`||!e.startsWith(Fn))return{...In};let t=e.slice(6).replace(/-/g,`+`).replace(/_/g,`/`),n=atob(t+`=`.repeat((4-t.length%4)%4)),r=Uint8Array.from(n,e=>e.charCodeAt(0)),i=JSON.parse(new TextDecoder().decode(r));return!i||typeof i!=`object`||Array.isArray(i)||Object.keys(i).sort().join(`,`)!==`css,html,js`?{...In}:{html:String(i.html),css:String(i.css),js:String(i.js)}}catch{return{...In}}}var Bn=new WeakMap;async function Vn({iframe:e,projectId:t,csrf:n,kind:r=`custom-code`,payload:i={}}){let a=(Bn.get(e)||0)+1;Bn.set(e,a),e.setAttribute(`sandbox`,`allow-scripts`),e.referrerPolicy=`no-referrer`;try{let o=new URLSearchParams({csrf:n,kind:r,...i}),s=await fetch(`/api/projects/${encodeURIComponent(t)}/custom-code/sandbox`,{method:`POST`,credentials:`same-origin`,cache:`no-store`,redirect:`error`,headers:{"Content-Type":`application/x-www-form-urlencoded;charset=UTF-8`},body:o}),c=await s.json();if(!s.ok)throw Error(c.error||`Не удалось подготовить изолированный предпросмотр.`);if(Bn.get(e)!==a||!e.isConnected)return!1;let l=new URL(c.url,location.origin),u=`/api/projects/${encodeURIComponent(t)}/custom-code/sandbox/`;if(l.origin!==location.origin||!l.pathname.startsWith(u))throw Error(`Сервер вернул недопустимый адрес предпросмотра.`);return e.src=l.href,!0}catch(t){return Bn.get(e)!==a||!e.isConnected||(e.srcdoc=`<!doctype html><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'"><style>body{font:14px/1.5 system-ui,sans-serif;color:#823d32;padding:16px}</style><p>${String(t?.message||`Ошибка предпросмотра`).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}</p>`),!1}}function Hn(e){e&&(Bn.set(e,(Bn.get(e)||0)+1),e.src=`about:blank`)}var Un=(e,t,n)=>({init({model:e}){this.listenTo(e,`change:content change:attributes`,()=>this.render())},removed(){Hn(this.el?.querySelector(`iframe`))},onRender(){if(!this.el||!this.el.ownerDocument)return;let r=this.el.querySelector(`iframe`);r&&Hn(r);let i=this.el.ownerDocument.createElement(`iframe`);i.title=n===`countdown`?`Обратный отсчёт`:`Пользовательский код в изолированной песочнице`,i.style.cssText=`display:block;width:100%;height:320px;border:0;pointer-events:none`,this.el.replaceChildren(i);let a=n===`countdown`?{deadline:this.model.getAttributes()[`data-countdown-end`]||`2027-01-01T00:00:00Z`}:zn(this.model.get(`content`));Vn({iframe:i,projectId:e,csrf:t(),kind:n,payload:a})}});function Wn(e,{projectId:t,csrf:n}){e.Components.addType(`custom-code`,{extendView:`default`,model:{defaults:{tagName:`div`,name:`Custom Code`,content:Rn(In),attributes:{class:`jz-custom-code`},style:{width:`100%`,"min-height":`180px`}}},view:Un(t,n,`custom-code`)}),e.Components.addType(`countdown`,{extendView:`default`,model:{defaults:{tagName:`div`,name:`Countdown`,attributes:{class:`jz-countdown`,"data-countdown-end":`2027-01-01T00:00:00Z`},traits:[{type:`text`,name:`data-countdown-end`,label:`Дата окончания (UTC)`}],style:{width:`100%`,"min-height":`72px`}}},view:Un(t,n,`countdown`)})}var U=Object.freeze({ink:M(`ink`),forest:M(`forest`),canvas:M(`canvas`),paper:M(`paper`),body:M(`body`),muted:M(`muted`),line:M(`line`),accent:M(`accent`),font:M(`bodyFontFamily`),headingFont:M(`headingFontFamily`),bodySize:M(`baseFontSize`),bodyWeight:M(`bodyFontWeight`),headingWeight:M(`headingFontWeight`),bodyLineHeight:M(`bodyLineHeight`),headingLineHeight:M(`headingLineHeight`),letterSpacing:M(`letterSpacing`),h1:M(`fontSizeH1`),h2:M(`fontSizeH2`),h3:M(`fontSizeH3`),h4:M(`fontSizeH4`),h5:M(`fontSizeH5`),h6:M(`fontSizeH6`),radius:M(`radius`)}),W=(e,t,n={})=>({type:`text`,tagName:e,content:t,style:n}),Gn=(e,t,n={})=>({type:`link`,content:e,attributes:{href:t},style:n}),Kn=[{id:`hero`,label:`Hero`,description:`Первый экран · Flex`,content:()=>({tagName:`section`,name:`Hero`,style:{display:`flex`,"flex-direction":`column`,gap:`24px`,padding:`80px 8%`,"min-height":`480px`,"background-color":U.canvas,color:U.ink,"font-family":U.font},components:[W(`p`,`ВАША ИДЕЯ. ВАШЕ ПРОСТРАНСТВО.`,{"font-size":`11px`,"letter-spacing":`2px`,color:U.body}),W(`h1`,`Место для
нового начала.`,{"font-family":U.headingFont,"font-size":U.h1,"font-weight":U.headingWeight,"line-height":U.headingLineHeight,"letter-spacing":U.letterSpacing,margin:`0`,"max-width":`700px`}),W(`p`,`Расскажите о том, что вы создаёте. Добавьте свой текст, выберите цвета и сделайте эту страницу своей.`,{"font-size":U.bodySize,"font-weight":U.bodyWeight,"max-width":`440px`,"line-height":U.bodyLineHeight,color:U.body}),Gn(`Начать знакомство`,`#contact`,{padding:`16px 24px`,"background-color":U.forest,color:`#fff`,"border-radius":U.radius,"text-decoration":`none`,"align-self":`flex-start`})]})},{id:`features`,label:`Возможности`,description:`Три карточки · Grid`,content:()=>({tagName:`section`,name:`Возможности`,attributes:{id:`about`},style:{padding:`56px 8%`,display:`grid`,"grid-template-columns":`repeat(auto-fit, minmax(min(100%, 180px), 1fr))`,gap:`24px`,"font-family":U.font},components:[`Продумано до деталей`,`Создано для людей`,`Готово к переменам`].map((e,t)=>({tagName:`article`,style:{padding:`24px`,"border-top":`1px solid `+U.line},components:[W(`p`,`0`+(t+1),{color:U.body,"font-size":`12px`}),W(`h3`,e,{"font-family":U.headingFont,"font-size":U.h3,"font-weight":U.headingWeight,"line-height":U.headingLineHeight,color:U.ink}),W(`p`,`Добавьте описание вашей услуги или преимущества.`,{"font-size":U.bodySize,"font-weight":U.bodyWeight,"line-height":U.bodyLineHeight,color:U.muted})]}))})},{id:`cta`,label:`Призыв к действию`,description:`Контактная секция · Flex`,content:()=>({tagName:`section`,name:`Контакты`,attributes:{id:`contact`},style:{display:`flex`,"flex-direction":`column`,gap:`16px`,padding:`56px 8%`,"background-color":U.ink,color:U.paper,"font-family":U.font},components:[W(`h2`,`Давайте создадим что-то вместе.`,{"font-family":U.headingFont,"font-size":U.h2,"font-weight":U.headingWeight,"line-height":U.headingLineHeight,margin:`0`}),W(`p`,`Оставьте здесь свой email или ссылку для связи.`),Gn(`Написать нам`,`mailto:hello@example.com`,{color:U.accent})]})},{id:`text`,label:`Текст`,description:`Редактируемый абзац`,content:()=>W(`p`,`Нажмите дважды, чтобы изменить этот текст.`,{padding:`24px`,"font-family":U.font,"font-size":U.bodySize,"font-weight":U.bodyWeight,"line-height":U.bodyLineHeight,color:U.ink})},{id:`image`,label:`Изображение`,description:`Загрузите файл или укажите URL`,content:()=>({type:`image`,style:{width:`100%`,"max-width":`640px`,"min-height":`160px`}})},{id:`navigation`,label:`Навигация`,description:`Логотип и ссылки · Flex`,content:()=>({tagName:`header`,name:`Навигация`,style:{display:`flex`,"align-items":`center`,"justify-content":`space-between`,"flex-wrap":`wrap`,gap:`18px`,padding:`20px 8%`,"background-color":U.paper,color:U.ink,"font-family":U.font},components:[W(`span`,`Название проекта`,{"font-size":`18px`,"font-weight":`700`,color:U.ink}),{tagName:`nav`,name:`Ссылки`,attributes:{"aria-label":`Основная навигация`},style:{display:`flex`,"align-items":`center`,"flex-wrap":`wrap`,gap:`18px`},components:[Gn(`О проекте`,`#about`,{color:U.body,"text-decoration":`none`}),Gn(`Услуги`,`#services`,{color:U.body,"text-decoration":`none`}),Gn(`Контакты`,`#contact`,{color:U.body,"text-decoration":`none`})]},Gn(`Обсудить проект`,`#contact`,{padding:`11px 16px`,"background-color":U.forest,color:`#fff`,"border-radius":U.radius,"text-decoration":`none`})]})},{id:`process`,label:`Этапы работы`,description:`Три шага · Grid`,content:()=>({tagName:`section`,name:`Этапы работы`,attributes:{id:`services`},style:{padding:`64px 8%`,"background-color":U.canvas,color:U.ink,"font-family":U.font},components:[W(`p`,`ПОНЯТНО ОТ ИДЕИ ДО ЗАПУСКА`,{"font-size":`11px`,"letter-spacing":`1.8px`,color:U.body}),W(`h2`,`Как устроена работа`,{"font-family":U.headingFont,"font-size":U.h2,"font-weight":U.headingWeight,"line-height":U.headingLineHeight,"max-width":`620px`}),{tagName:`div`,name:`Шаги`,style:{display:`grid`,"grid-template-columns":`repeat(auto-fit, minmax(min(100%, 180px), 1fr))`,gap:`16px`},components:[[`01`,`Знакомство`,`Расскажите о задаче и о том, для кого создаётся сайт.`],[`02`,`Структура`,`Соберите содержание страницы из готовых секций.`],[`03`,`Запуск`,`Проверьте адаптивность и подготовьте страницу к публикации.`]].map(([e,t,n])=>({tagName:`article`,style:{padding:`22px`,"background-color":U.paper,"border-radius":U.radius},components:[W(`p`,e,{color:U.forest,"font-size":`12px`,"letter-spacing":`1px`}),W(`h3`,t,{"font-family":U.headingFont,"font-size":U.h3,"font-weight":U.headingWeight,"line-height":U.headingLineHeight,color:U.ink}),W(`p`,n,{"font-size":U.bodySize,"font-weight":U.bodyWeight,"line-height":U.bodyLineHeight,color:U.muted})]}))}]})},{id:`testimonial`,label:`Отзыв`,description:`Цитата клиента · Flex`,content:()=>({tagName:`section`,name:`Отзыв`,style:{display:`flex`,"flex-direction":`column`,gap:`18px`,padding:`64px 8%`,"background-color":U.paper,color:U.ink,"font-family":U.font},components:[W(`p`,`ОТЗЫВ КЛИЕНТА`,{"font-size":`11px`,"letter-spacing":`1.8px`,color:U.body}),W(`p`,`«Добавьте сюда короткий отзыв о совместной работе и её результате».`,{"max-width":`760px`,"font-size":`clamp(22px, 3.5vw, 34px)`,"line-height":`1.35`,color:U.ink}),W(`strong`,`Имя клиента`,{"font-size":`14px`}),W(`p`,`Роль или название компании`,{"font-size":`12px`,color:U.muted})]})},{id:`faq`,label:`Вопросы и ответы`,description:`Ответы посетителям · Stack`,content:()=>({tagName:`section`,name:`Вопросы и ответы`,style:{padding:`64px 8%`,color:U.ink,"font-family":U.font},components:[W(`p`,`ВОПРОСЫ И ОТВЕТЫ`,{"font-size":`11px`,"letter-spacing":`1.8px`,color:U.body}),W(`h2`,`Что важно знать`,{"font-family":U.headingFont,"font-size":U.h2,"font-weight":U.headingWeight,"line-height":U.headingLineHeight}),{tagName:`div`,name:`Список ответов`,style:{display:`flex`,"flex-direction":`column`,"max-width":`820px`},components:[[`С чего начать?`,`Опишите задачу, выберите секции и замените примерный текст своим содержанием.`],[`Можно ли менять секции?`,`Да. Каждый блок можно редактировать на холсте и настраивать в инспекторе.`],[`Как проверить мобильную версию?`,`Переключите устройство в редакторе и проверьте страницу на узком экране.`]].map(([e,t])=>({tagName:`article`,style:{padding:`18px 0`,"border-bottom":`1px solid `+U.line},components:[W(`h3`,e,{"font-family":U.headingFont,"font-size":U.h3,"font-weight":U.headingWeight,"line-height":U.headingLineHeight,color:U.ink}),W(`p`,t,{"font-size":U.bodySize,"font-weight":U.bodyWeight,"line-height":U.bodyLineHeight,color:U.muted})]}))}]})},{id:`footer`,label:`Подвал`,description:`Навигация и подпись · Flex`,content:()=>({tagName:`footer`,name:`Подвал`,style:{display:`flex`,"justify-content":`space-between`,"align-items":`center`,"flex-wrap":`wrap`,gap:`16px`,padding:`28px 8%`,"background-color":U.ink,color:U.paper,"font-family":U.font},components:[W(`p`,`Название проекта · 2026`,{"font-size":`12px`,color:U.paper}),{tagName:`nav`,name:`Ссылки подвала`,attributes:{"aria-label":`Дополнительная навигация`},style:{display:`flex`,"flex-wrap":`wrap`,gap:`16px`},components:[Gn(`О проекте`,`#about`,{"font-size":`12px`,color:U.accent,"text-decoration":`none`}),Gn(`Связаться`,`#contact`,{"font-size":`12px`,color:U.accent,"text-decoration":`none`})]}]})},{id:`container`,label:`Контейнер`,description:`Область для вложенных элементов · Flex`,content:()=>({tagName:`div`,name:`Контейнер`,style:{display:`flex`,"flex-direction":`column`,gap:`12px`,"min-height":`120px`,padding:`20px`,border:`1px dashed `+U.line,"border-radius":U.radius},components:[]})},{id:`button`,label:`Кнопка`,description:`Редактируемая кнопка-ссылка`,content:()=>({tagName:`button`,name:`Кнопка`,attributes:{type:`button`},content:`Нажмите здесь`,style:{padding:`12px 18px`,"background-color":U.forest,color:`#fff`,border:`0`,"border-radius":U.radius,"font-family":U.font,"font-size":`14px`,cursor:`pointer`}})},{id:`navbar`,label:`Navbar`,category:`Навигация`,description:`Адаптивная шапка с редактируемыми ссылками`,content:()=>({tagName:`header`,name:`Navbar`,attributes:{role:`banner`},style:{display:`flex`,"align-items":`center`,"justify-content":`space-between`,"flex-wrap":`wrap`,gap:`16px`,padding:`18px 6%`,"background-color":U.paper,color:U.ink,"font-family":U.font},components:[W(`strong`,`Название сайта`,{color:U.ink,"font-size":`18px`}),{tagName:`nav`,name:`Навигация`,attributes:{"aria-label":`Основная навигация`},style:{display:`flex`,"align-items":`center`,"flex-wrap":`wrap`,gap:`16px`},components:[Gn(`О проекте`,`#about`,{color:U.body,"text-decoration":`none`}),Gn(`Услуги`,`#services`,{color:U.body,"text-decoration":`none`}),Gn(`Контакты`,`#contact`,{color:U.body,"text-decoration":`none`})]},Gn(`Связаться`,`#contact`,{padding:`10px 16px`,"background-color":U.forest,color:`#fff`,"border-radius":U.radius,"text-decoration":`none`})]})},{id:`countdown`,label:`Countdown`,category:`Интерактивные`,description:`Живой отсчёт в отдельной песочнице без доступа к странице`,content:()=>({type:`countdown`,tagName:`div`,name:`Countdown`,attributes:{class:`jz-countdown`,"data-countdown-end":`2027-01-01T00:00:00Z`},style:{width:`100%`,"min-height":`72px`}})},{id:`slider`,label:`Slider`,category:`Интерактивные`,description:`Лента карточек с прокруткой и привязкой к слайдам`,content:()=>({tagName:`section`,name:`Slider`,style:{display:`flex`,"flex-direction":`column`,gap:`18px`,padding:`32px 6%`,"font-family":U.font},components:[W(`h2`,`Избранное`,{color:U.ink,"font-size":U.h2}),{tagName:`div`,name:`Слайды`,attributes:{"aria-label":`Слайды; прокручивайте по горизонтали`},style:{display:`flex`,gap:`16px`,"overflow-x":`auto`,"scroll-snap-type":`x mandatory`,"padding-bottom":`12px`},components:[1,2,3].map(e=>({tagName:`article`,name:`Слайд `+e,style:{display:`flex`,"flex-direction":`column`,gap:`10px`,flex:`0 0 min(82%, 420px)`,"scroll-snap-align":`start`,padding:`24px`,border:`1px solid `+U.line,"border-radius":U.radius,"background-color":U.paper},components:[W(`p`,`0`+e,{color:U.forest,"font-size":`12px`}),W(`h3`,`Заголовок слайда `+e,{color:U.ink,"font-size":U.h3}),W(`p`,`Добавьте описание и замените этот текст своим содержанием.`,{color:U.muted,"font-size":U.bodySize})]}))}]})},{id:`tabs`,label:`Tabs`,category:`Интерактивные`,description:`Переключаемые панели на radio и CSS без JavaScript`,content:()=>({type:`custom-code`,tagName:`div`,name:`Tabs`,content:Rn(Ln),attributes:{class:`jz-tabs-block`},style:{width:`100%`,"min-height":`180px`}})},{id:`tooltip`,label:`Tooltip`,category:`Интерактивные`,description:`Подсказка браузера при наведении или фокусе`,content:()=>({type:`button`,tagName:`button`,name:`Tooltip`,content:`Наведите курсор или перейдите клавиатурой`,attributes:{type:`button`,title:`Текст всплывающей подсказки`},style:{display:`inline-flex`,width:`fit-content`,padding:`12px 16px`,border:`1px solid `+U.line,"border-radius":U.radius,color:U.ink,"font-family":U.font,"text-decoration":`none`}})},{id:`custom-code`,label:`Custom Code`,category:`Интерактивные`,description:`HTML, CSS и JavaScript в изолированной песочнице`,content:()=>({type:`custom-code`,tagName:`div`,name:`Custom Code`,content:Rn(In),attributes:{class:`jz-custom-code`},style:{width:`100%`,"min-height":`180px`}})},...Pn];function qn(e){for(let t of Kn)e.Blocks.add(t.id,{label:t.label,content:t.content()})}var Jn=new Set([`aria-labelledby`,`aria-describedby`,`aria-controls`,`aria-owns`,`aria-flowto`,`aria-details`,`aria-errormessage`,`aria-activedescendant`,`for`,`form`,`list`,`headers`,`itemref`]);function Yn(e){return e?.components?.()?.models||[]}function Xn(e){return e?.get?.(`type`)===`wrapper`}function Zn(e,t,n){if(!e||!t)return;let r=new Map,i=(e,t)=>{let n=e?.getId?.(),a=t?.getId?.();typeof n==`string`&&typeof a==`string`&&n!==a&&r.set(n,a);let o=Yn(e),s=Yn(t);o.forEach((e,t)=>i(e,s[t]))};if(i(e,t),!r.size)return;let a=e=>e.split(/\s+/).map(e=>r.get(e)||e).join(` `),o=e=>e.replace(/url\(\s*(["']?)#([^"'()\s]+)\1\s*\)/gi,(e,t,n)=>{let i=r.get(n);return i?`url(${t}#${i}${t})`:e}),s=(e,t)=>{if(typeof t!=`string`)return t;if(e===`href`||e===`xlink:href`||e===`usemap`){if(!t.startsWith(`#`))return t;let e=r.get(t.slice(1));return e?`#${e}`:t}return Jn.has(e)?a(t):o(t)},c=e=>{if(typeof e==`string`){let t=o(e);return{value:t,changed:t!==e}}if(Array.isArray(e)){let t=!1,n=e.map(e=>{let n=c(e);return t||=n.changed,n.value});return{value:t?n:e,changed:t}}if(!e||typeof e!=`object`||![Object.prototype,null].includes(Object.getPrototypeOf(e)))return{value:e,changed:!1};let t=!1,n={};for(let[r,i]of Object.entries(e)){let e=c(i);n[r]=e.value,t||=e.changed}return{value:t?n:e,changed:t}},l=e=>{let t=e?.getStyle?.(``,{withNested:!0,skipResolve:!0})||{},n={};for(let[e,r]of Object.entries(t)){if(r&&typeof r.getStyle==`function`&&typeof r.addStyle==`function`){l(r);continue}let t=c(r);t.changed&&(n[e]=t.value)}Object.keys(n).length&&e.addStyle?.(n)},u=e=>{let t=e.get?.(`attributes`)||{},n={};for(let[e,r]of Object.entries(t)){let t=s(e,r);t!==r&&(n[e]=t)}Object.keys(n).length&&e.addAttributes(n);let r=e.getStyle?.()||{},i={};for(let[e,t]of Object.entries(r)){if(typeof t!=`string`)continue;let n=o(t);n!==t&&(i[e]=n)}Object.keys(i).length&&e.addStyle(i),Yn(e).forEach(u)};if(u(t),n?.getRules){let e=new Set;for(let t of r.values())for(let r of n.getRules(`#${t}`)||[])e.has(r)||(e.add(r),l(r))}}function Qn(e){return e.getModel?.().get?.(`clipboard`)||[]}function $n(e,t){let n=e=>{for(let t of Yn(e)){let e=n(t);if(e)return e}let r=e?.viewLayer?.el;return r&&(r===t||r.contains?.(t))?e:null};return n(e)}function er(e,t,n=`paste-component`){let r=[],i=e=>r.push(e);e.on(`component:paste`,i);try{e.runCommand(`core:paste`,{action:n})}finally{e.off(`component:paste`,i)}r.forEach((n,r)=>Zn(t[r],n,e.Css));let a=r.at(-1);return a&&e.select(a),r}function tr({editor:e,confirmDelete:t,notify:n}){let r=document.createElement(`button`);r.type=`button`,r.id=`component-actions-trigger`,r.className=`panel-close component-actions-trigger`,r.textContent=`⋯`,r.title=`Действия с элементом`,r.setAttribute(`aria-label`,`Действия с выбранным элементом`),r.setAttribute(`aria-haspopup`,`menu`),r.setAttribute(`aria-expanded`,`false`),document.querySelector(`.editor-right .panel-heading-with-close`)?.insertBefore(r,document.querySelector(`#close-inspector`));let i=document.createElement(`div`);i.id=`component-context-menu`,i.className=`component-context-menu`,i.setAttribute(`role`,`menu`),i.setAttribute(`aria-label`,`Действия с элементом`),i.hidden=!0;for(let[e,t,n]of[[`cut`,`Вырезать`,`⌘/Ctrl+X`],[`copy`,`Копировать`,`⌘/Ctrl+C`],[`paste`,`Вставить рядом`,`⌘/Ctrl+V`],[`duplicate`,`Дублировать`,``],[`separator`,``,``],[`move-up`,`Переместить выше`,``],[`move-down`,`Переместить ниже`,``],[`select-parent`,`Выбрать родителя`,``],[`separator`,``,``],[`delete`,`Удалить`,``]]){if(e===`separator`){let e=document.createElement(`div`);e.setAttribute(`role`,`separator`),i.append(e);continue}let r=document.createElement(`button`);if(r.type=`button`,r.dataset.componentAction=e,r.setAttribute(`role`,`menuitem`),r.textContent=t,n){let e=document.createElement(`span`);e.textContent=n,r.append(e)}e===`delete`&&r.classList.add(`danger-action`),i.append(r)}document.body.append(i);let a=!1,o=({restoreFocus:e=!1}={})=>{a&&(a=!1,i.hidden=!0,r.setAttribute(`aria-expanded`,`false`),e&&r.focus())},s=t=>{let n=Xn(t),r=t?.parent?.(),i=t?.index?.()??-1,a=r?.components?.().length??0,o=!!t&&!n,s=Qn(e).length>0;return{cut:o&&t.get(`removable`)!==!1,copy:o&&t.get(`copyable`)!==!1,paste:s,duplicate:o&&t.get(`copyable`)!==!1&&t.get(`removable`)!==!1,"move-up":o&&!!r&&i>0,"move-down":o&&!!r&&i>=0&&i<a-1,"select-parent":!!r,delete:o&&t.get(`removable`)!==!1}},c=()=>{let t=e.getSelected(),n=s(t);for(let e of i.querySelectorAll(`[data-component-action]`))e.disabled=!n[e.dataset.componentAction];r.disabled=!t},l=(t,n,o=e.getSelected(),s=!0)=>{if(o&&o!==e.getSelected()&&e.select(o),!e.getSelected())return;c(),i.hidden=!1,a=!0,r.setAttribute(`aria-expanded`,`true`);let l=i.offsetWidth,u=i.offsetHeight;i.style.left=`${Math.max(8,Math.min(t,window.innerWidth-l-8))}px`,i.style.top=`${Math.max(8,Math.min(n,window.innerHeight-u-8))}px`,s&&i.querySelector(`[data-component-action]:not(:disabled)`)?.focus({preventScroll:!0})},u=async r=>{let i=e.getSelected();if(i){switch(o(),r){case`copy`:e.runCommand(`core:copy`),n(`Скопировано в буфер редактора`);break;case`cut`:e.runCommand(`core:copy`),i.remove(),n(`Элемент вырезан · вставьте его в другом месте или отмените действие`);break;case`paste`:er(e,Qn(e).slice()).length&&n(`Элемент вставлен рядом`);break;case`duplicate`:e.runCommand(`core:copy`),er(e,Qn(e).slice(),`clone-component`).length&&n(`Копия создана`);break;case`move-up`:case`move-down`:{let t=i.parent(),a=i.index()+(r===`move-up`?-1:2);i.move(t,{at:a}),e.select(i),n(r===`move-up`?`Элемент перемещён выше`:`Элемент перемещён ниже`);break}case`select-parent`:{let t=i.parent();t&&e.select(t),o();break}case`delete`:if(!await t(`Удалить «${i.getName?.()||`элемент`}»? Это действие можно отменить через Undo.`,`Удалить`))break;i.remove(),n(`Элемент удалён · отмените действие через Undo`)}c()}};i.addEventListener(`click`,e=>{let t=e.target.closest(`[data-component-action]`);t&&!t.disabled&&u(t.dataset.componentAction)}),r.addEventListener(`click`,e=>{if(e.stopPropagation(),a)return o();let t=r.getBoundingClientRect();l(t.left,t.bottom+6)});let d=e=>{a&&!i.contains(e.target)&&e.target!==r&&o()},f=e=>{if(!a)return;if(e.key===`Escape`){e.preventDefault(),e.stopPropagation(),o({restoreFocus:!0});return}let t=[...i.querySelectorAll(`[data-component-action]:not(:disabled)`)],n=t.indexOf(document.activeElement),r=null;e.key===`ArrowDown`?r=t[(n+1+t.length)%t.length]:e.key===`ArrowUp`?r=t[(n-1+t.length)%t.length]:e.key===`Home`?r=t[0]:e.key===`End`&&(r=t.at(-1)),r&&(e.preventDefault(),r.focus())};document.addEventListener(`pointerdown`,d,!0),document.addEventListener(`keydown`,f,!0);let p=new WeakSet,m=document.querySelector(`#layer-manager`),h=t=>{let n=$n(e.getWrapper(),t.target);n&&!Xn(n)&&(t.preventDefault(),t.stopPropagation(),l(t.clientX,t.clientY,n))};m?.addEventListener(`contextmenu`,h,!0);let g=t=>{let n=t?.window,r=n?.document,i=n?.frameElement;r?.body&&i&&!p.has(r)&&(p.add(r),r.body.addEventListener(`contextmenu`,t=>{let n=t.target.closest?.(`[data-gjs-type][id]`),r=n?.id?e.DomComponents.getById(n.id):null;if(!r)return;t.preventDefault(),t.stopPropagation();let a=i.getBoundingClientRect(),o=a.width/(i.clientWidth||a.width),s=a.height/(i.clientHeight||a.height);l(a.left+t.clientX*o,a.top+t.clientY*s,r)},!0),r.addEventListener(`pointerdown`,()=>o(),!0))};return e.on(`component:selected component:deselected component:add component:remove`,c),e.on(`canvas:frame:load:body`,g),e.on(`canvas:frame:load`,g),r.disabled=!e.getSelected(),{close:o,destroy(){o(),e.off(`component:selected component:deselected component:add component:remove`,c),e.off(`canvas:frame:load:body`,g),e.off(`canvas:frame:load`,g),document.removeEventListener(`pointerdown`,d,!0),document.removeEventListener(`keydown`,f,!0),m?.removeEventListener(`contextmenu`,h,!0),r.remove(),i.remove()}}}function nr(e){let t=e;for(let e=t.parentElement;e&&!(e.tagName!==`DIV`||e.id||e.hasAttribute(`role`)||e.hasAttribute(`aria-label`)||e.children.length!==1||e.firstElementChild!==t||e.textContent.trim()!==``);e=t.parentElement)t=e;t.remove()}function rr({editor:e,component:t,pageId:n,baseVersion:r,currentVersion:i,snapshot:a,dirty:o,conflicted:s}){return!o&&!s&&i===r&&e.getSelected()===t&&e.Pages.getSelected()?.get(`id`)===n&&JSON.stringify(e.getProjectData())===a}function ir({proposal:e,currentProposal:t,editor:n,component:r,componentId:i,pageId:a,currentVersion:o,conflicted:s}){return!!e&&t===e&&!s&&o===e.baseVersion&&r===e.componentModel&&i===e.requestedComponentId&&a===e.pageId&&JSON.stringify(n.getProjectData())===e.editorSnapshot}var ar=Object.freeze({tag_allowlist:`найден тег, который нельзя использовать`,attribute_allowlist:`найден атрибут или встроенный стиль вне списка разрешённых`,contrast_quality:`контраст текста ниже WCAG AA`,section_count_low:`найдено меньше 3 секций`,section_count_high:`превышен максимум в 9 секций`,hero_count:`должен быть ровно один Hero с классом ai-hero`,image_slot_count:`превышен лимит фото-слотов`,fragment_target:`ссылка ведёт на отсутствующий элемент страницы`,aria_labelledby_target:`aria-labelledby ссылается на отсутствующий ID`,aria_labelledby_value:`некорректный список ID в aria-labelledby`,class_tokens:`имена CSS-классов не соответствуют формату генератора`,icon_marker:`маркер иконки имеет недопустимый формат`,photo_query:`некорректный поисковый запрос для фото`,markup_structure:`нарушена структура или другое ограничение HTML-разметки`}),or=Object.freeze({copy_duplicate:`повторяется заголовок или абзац`,copy_mixed_language:`текст содержит слова не на языке брифа`,copy_grammar:`нужна проверка грамматики и формулировки`,copy_scarcity:`есть неподтверждённое заявление о срочности или количестве мест`,copy_business_claim:`есть неподтверждённое условие работы или услуги`,copy_inventory_status:`не подтверждена доступность или наличие товара`,copy_unconfirmed_product:`есть неподтверждённая характеристика товара`,copy_unconfirmed_credential:`есть неподтверждённая квалификация или достижение`,copy_lesson_claim:`есть неподтверждённое описание процесса или результата`,copy_inert_form:`кнопка обещает отправку формы или обратную связь`,copy_contact_placeholder:`обнаружена заглушка контактных данных`,copy_in_person_visit:`личный визит не подтверждён в брифе`,copy_empty_contact_section:`раздел контактов не содержит подтверждённого способа связи`,copy_repeated_facts:`факты повторяются в разных разделах`,copy_pricing_hero_fact:`цена или условие тарифа повторяется в нескольких разделах`,copy_rule_missing:`сервер не передал конкретное правило проверки текста`,copy_rule_unrecognized:`код проверки текста не входит в безопасный список`}),sr=Object.freeze({css_empty:`CSS пустой`,css_unsafe_syntax:`обнаружен запрещённый CSS-синтаксис`,css_nesting:`вложенность CSS превышает допустимый уровень`,css_media_rule:`некорректное или неподдерживаемое media-правило`,css_rule_syntax:`CSS-блок имеет некорректный формат`,"css_rule_syntax:unclosed_media":`у media-блока нет закрывающей скобки`,"css_rule_syntax:missing_open_brace":`у CSS-блока нет открывающей скобки`,"css_rule_syntax:unclosed_rule":`у CSS-блока нет закрывающей скобки`,"css_rule_syntax:nested_rule":`селектор содержит вложенное CSS-правило`,css_selector_syntax:`селектор имеет некорректный формат`,css_rule_limit:`превышено допустимое количество CSS-правил`,css_no_valid_rules:`не найдено ни одного допустимого CSS-правила`,css_declaration_limit:`превышено допустимое количество свойств в правиле`}),cr=Object.freeze({hero_heading:`нужен один H1 внутри Hero`,section_headings:`у каждой секции должен быть заголовок`,section_copy:`в каждой секции нужно не менее 32 видимых символов`,hero_action:`действие в Hero не добавляется без подходящей цели`,responsive_css:`нужно адаптивное правило для узкого экрана`}),lr=Object.freeze({project_check:`Проверка проекта`,payload_load:`Загрузка параметров задачи`,provider_setup:`Подготовка AI-профиля`,design_context:`Подготовка дизайн-контекста`,open_design_reference:`Поиск структурного примера`,open_design_pipeline:`Контракт Open Design`,documentation_css_fallback:`Безопасная раскладка документации`,design_model_request:`Запрос дизайна к модели`,response_parse:`Разбор ответа модели`,markup_validation:`Проверка структуры и HTML/CSS`,copy_validation:`Проверка текста`,hero_validation:`Проверка композиции Hero`,contrast_validation:`Проверка контраста`,contact_validation:`Проверка контактов`,skill_validation:`Проверка правил Skill`,repair_decision:`Решение об исправлении`,repair_model_request:`Запрос исправления к модели`,contrast_repair:`Исправление контраста`,photo_catalog:`Подбор фотографий`,photo_model_request:`Выбор фото по содержанию`,result_persistence:`Сохранение результата задачи`,model_request:`Запрос к модели`}),ur=Object.freeze({started:`начат`,completed:`готово`,failed:`ошибка`,skipped:`пропущен`}),dr=Object.freeze({"saas-landing":`Open Design · SaaS Landing`,"web-prototype":`Open Design · Web Prototype`,"blog-post":`Open Design · Blog Post`,"docs-page":`Open Design · Docs Page`,"pricing-page":`Open Design · Pricing Page`,"waitlist-page":`Open Design · Waitlist Page`,dashboard:`Open Design · Dashboard`}),fr=Object.freeze({loaded:`источник загружен`,unavailable:`источник недоступен; использована резервная инструкция`,not_matched:`подходящий источник не выбран`});function pr(e){return Object.hasOwn(lr,e)?lr[e]:`Этап генерации`}function mr(e){return Object.hasOwn(ur,e)?ur[e]:`обновлён`}function hr(e){return Object.hasOwn(dr,e)?dr[e]:``}function gr(e){return Object.hasOwn(fr,e)?fr[e]:``}function _r(e){if(!Array.isArray(e))return null;let t=e.slice().reverse().find(e=>e&&typeof e==`object`&&e.stage===`open_design_reference`);if(!t)return null;let n=Object.hasOwn(dr,t.templateId)?t.templateId:``,r=Object.hasOwn(fr,t.referenceStatus)?t.referenceStatus:``;return n&&r?{templateId:n,referenceStatus:r}:null}function vr(e,t=18){if(!Array.isArray(e))return[];let n=Number.isInteger(t)&&t>0?Math.min(t,50):18,r=e.slice(-n),i=e.slice().reverse().find(e=>e&&typeof e==`object`&&e.stage===`open_design_reference`);i&&!r.includes(i)&&r.unshift(i);let a=e.filter(e=>e?.stage===`open_design_pipeline`&&[`loaded`,`no_match`,`ambiguous`,`unavailable`,`source_unavailable`,`blueprint_extracted`,`blueprint_in_prompt`].includes(e.pipelineStage));for(let e of a.slice().reverse())r.includes(e)||r.unshift(e);return r}function yr(e){if(typeof e==`string`&&/^composition_(hero|order|collection|records|docs|rail|article|waitlist|scope|blueprint)$/.test(e))return`нарушен контракт композиции Open Design (${e})`;if(typeof e==`string`&&e.startsWith(`fragment_target:`))return ar.fragment_target;if(typeof e==`string`&&e.startsWith(`tag_allowlist:`)){let t=e.slice(14);return/^[a-z][a-z0-9-]{0,31}$/.test(t)?`тег ${t} не входит в список разрешённых`:ar.tag_allowlist}if(typeof e==`string`&&e.startsWith(`attribute_allowlist:`)){let t=e.slice(20);return/^[a-z][a-z0-9:_-]{0,31}$/.test(t)?`атрибут ${t} не входит в список разрешённых`:ar.attribute_allowlist}return Object.hasOwn(ar,e)?ar[e]:`другое ограничение безопасной HTML-разметки`}function br(e){return Object.hasOwn(or,e)?or[e]:`требуется проверить текст на точность и грамотность`}function xr(e){return Object.hasOwn(sr,e)?sr[e]:`другое ограничение безопасного CSS`}function Sr(e){if(typeof e!=`string`||!e.startsWith(`taste:`))return`нарушено правило профиля Taste`;let t=e.slice(6).split(`,`);return t.length<1||t.length>5||t.some(e=>!Object.hasOwn(cr,e))?`нарушено правило профиля Taste`:[...new Set(t)].map(e=>cr[e]).join(`; `)}function Cr(e){let t=e?.validationRule,n=e?.reasonCode===`copy_quality`||typeof t==`string`&&t.startsWith(`copy_`),r=e?.reasonCode===`invalid_css`||typeof t==`string`&&t.startsWith(`css_`);return e?.reasonCode===`skill_requirements`&&typeof t==`string`&&t.startsWith(`taste:`)?`Skill: ${Sr(t)}`:r?`CSS: ${xr(t)}`:`${n?`текст`:`разметка`}: ${n?br(t):yr(t)}`}function wr(e){if(e?.validationRule===`copy_duplicate`){let t=e?.validationEvidence;if(t?.kind===`exact`&&[`heading`,`paragraph`].includes(t.copyType)&&Number.isInteger(t.firstIndex)&&t.firstIndex>=1&&t.firstIndex<=100&&Number.isInteger(t.duplicateIndex)&&t.duplicateIndex>=2&&t.duplicateIndex<=100&&t.firstIndex!==t.duplicateIndex)return`${t.copyType===`heading`?`заголовки`:`абзацы`} №${t.firstIndex} и №${t.duplicateIndex} совпадают`;if(t?.kind===`overlap`&&t.copyType===`heading_paragraph`&&Number.isInteger(t.sectionIndex)&&t.sectionIndex>=1&&t.sectionIndex<=9&&Number.isInteger(t.headingIndex)&&t.headingIndex>=1&&t.headingIndex<=24&&Number.isInteger(t.paragraphIndex)&&t.paragraphIndex>=1&&t.paragraphIndex<=24){let e=t.overlapType===`near_duplicate`?`близкое совпадение`:`повтор текста`;return`секция №`+t.sectionIndex+`, заголовок №`+t.headingIndex+`, абзац №`+t.paragraphIndex+`: `+e}return``}if(e?.validationRule!==`copy_repeated_facts`)return``;let t=e?.validationEvidence,n=t?.sectionIndexes,r=t?.paragraphIndexes;if(!Array.isArray(n)||n.length!==2||!n.every(e=>Number.isInteger(e)&&e>=1&&e<=9)||n[0]===n[1]||!Array.isArray(r)||r.length!==2||!r.every(e=>Number.isInteger(e)&&e>=1&&e<=24))return``;let i={near_duplicate:`близкие абзацы`,ordered_run:`общая последовательность`,both:`оба типа перекрытия`},a=Object.hasOwn(i,t.overlapType)?i[t.overlapType]:``,o=Number.isInteger(t.orderedRunLength)&&t.orderedRunLength>=0&&t.orderedRunLength<=100?t.orderedRunLength:null;return`секции `+n[0]+` и `+n[1]+`, абзацы `+r[0]+` и `+r[1]+(a?`; `+a:``)+(a&&[`ordered_run`,`both`].includes(t.overlapType)&&o!==null?`; подряд `+o:``)}var Tr=Object.freeze({no_match:`источник не выбран`,ambiguous:`неоднозначный выбор`,unavailable:`источник недоступен`,source_unavailable:`источник недоступен`,loaded:`pinned источник проверен`,blueprint_extracted:`структура извлечена`,blueprint_in_prompt:`контракт передан модели`,output_conforms:`структурная проверка пройдена`,validation_rejected:`результат отклонён`,preview_ready:`кандидат готов к превью`});function Er(e){return Object.hasOwn(Tr,e)?Tr[e]:``}function Dr(e={}){return{type:`wrapper`,style:{...e,display:e.display||`flex`,"flex-direction":e[`flex-direction`]||`column`},components:[]}}var Or={name:`juzimder-ai`,version:`0.1.371`,private:!0,type:`module`,scripts:{dev:`vite --host 127.0.0.1`,build:`vite build`,"package:shared-hosting":`sh scripts/build-shared-hosting-package.sh`,"test:ui-theme":`node --test tests/ui-theme.test.mjs`,"test:session-policy":`php tests/session-policy.php && php tests/trusted-proxy-policy.php`,"test:updates":`php tests/updates.php`,pretest:`php tests/trusted-proxy-policy.php && php tests/account-recovery.php && php tests/updates.php`,serve:`sh scripts/serve-local.sh`,test:`node --test tests/color-picker.test.mjs tests/photo-credit.test.mjs tests/zero.test.mjs tests/shared-sections.test.mjs tests/ai-skill-preview.test.mjs tests/ai-component-edit-guards.test.mjs tests/ai-job-diagnostics.test.mjs tests/updates-ui.test.mjs && php tests/zero.php && php tests/zero-ai.php && node --test tests/flex-icons.test.mjs tests/editor-background.test.mjs tests/component-identity.test.mjs && php tests/background-image.php && php tests/generated-design-defaults.php && php tests/ai-photo-selection.php && php tests/stock-photos.php && php tests/ai-contacts.php && php tests/ai-jobs.php && php tests/domain.php && php tests/schema.php && php tests/project-settings.php && php tests/backup.php && php tests/form-mail.php && php tests/ai-skills.php && php tests/skill-analyzer.php && php tests/open-design-template-source.php && php tests/open-design-composition.php && php tests/mcp.php && php tests/mcp-personal-tokens.php && php tests/mcp-ingress-probe.php && php tests/ai.php && php tests/operations.php && php tests/static-export.php && node --test tests/schema.test.mjs && node --test tests/api.test.mjs && node --test tests/blocks.test.mjs && node --test tests/design-tokens.test.mjs && node --test tests/ai-plan.test.mjs && node --test tests/component-actions.test.mjs && node --test tests/page-root.test.mjs && node --test tests/ai-transport.test.mjs`,"serve:install":`sh scripts/install-local-service.sh`},dependencies:{grapesjs:`^0.23.8`,"grapesjs-blocks-basic":`1.0.2`,"grapesjs-blocks-flexbox":`1.0.1`,"grapesjs-component-countdown":`1.0.2`,"grapesjs-custom-code":`1.0.2`,"grapesjs-lory-slider":`0.1.5`,"grapesjs-navbar":`1.0.2`,"grapesjs-plugin-ckeditor":`1.0.1`,"grapesjs-plugin-export":`1.0.12`,"grapesjs-plugin-filestack":`0.1.1`,"grapesjs-plugin-forms":`2.0.6`,"grapesjs-style-filter":`1.0.2`,"grapesjs-style-gradient":`3.0.3`,"grapesjs-tabs":`1.0.6`,"grapesjs-tooltip":`0.1.8`,"grapesjs-touch":`0.1.1`,"grapesjs-tui-image-editor":`1.0.2`},devDependencies:{ajv:`^8.20.0`,vite:`^8.3.4`},productVersion:`00.00.371`},kr=`modulepreload`,Ar=function(e){return`/`+e},jr={},Mr=function(e){return e.pathname.endsWith(`.css`)},Nr=function(e,t,n){if(t in e)return e[t];let r=n();if(!r){e[t]=void 0;return}let i=r.then(()=>{e[t]=void 0},n=>{throw e[t]=void 0,n});return e[t]=i,i},Pr=function(e,t,n){let r=Promise.resolve();if(t&&t.length>0){let e,i=document.querySelector(`meta[property=csp-nonce]`),a=i?.nonce||i?.getAttribute(`nonce`);function o(e){return Promise.all(e.map(e=>Promise.resolve(e).then(e=>({status:`fulfilled`,value:e}),e=>({status:`rejected`,reason:e}))))}function s(e){return import.meta.resolve?new URL(import.meta.resolve(e)):new URL(e,import.meta.url)}r=o(t.map(t=>{t=Ar(t,n);let r=s(t),i=Mr(r);return Nr(jr,r.href,()=>{if(e===void 0){e={all:new Set,styles:new Set};let t=document.getElementsByTagName(`link`);for(let n=t.length-1;n>=0;n--){let r=t[n];e.all.add(r.href),r.rel===`stylesheet`&&e.styles.add(r.href)}}if((i?e.styles:e.all).has(r.href))return;let t=document.createElement(`link`);if(t.rel=i?`stylesheet`:kr,i||(t.as=`script`),t.crossOrigin=``,t.href=r.href,a&&t.setAttribute(`nonce`,a),document.head.appendChild(t),i)return new Promise((e,n)=>{t.addEventListener(`load`,e),t.addEventListener(`error`,()=>n(Error(`Unable to preload CSS for ${r}`)))})})}).filter(e=>e!==void 0))}function i(e){let t=new Event(`vite:preloadError`,{cancelable:!0});if(t.payload=e,window.dispatchEvent(t),!t.defaultPrevented)throw e}return r.then(t=>{for(let e of t||[])e.status===`rejected`&&i(e.reason);return e().catch(i)})},G=e=>document.querySelector(e),Fr=G(`#app`);A(document.body);var Ir=Or.productVersion,K=e=>String(e).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]),Lr=`<span class="brand-mark"><i></i><i></i><i></i><i></i></span>`,Rr=vn.filter(e=>e.type===`color`).map(e=>`<label>${e.label}<input type="color" name="${e.name}" aria-label="${e.label}"></label>`).join(``),zr=gn.map(e=>`<option value="${K(e)}">${e.startsWith(`Georgia`)?`Georgia`:e.startsWith(`system-ui`)?`Системный`:`Arial`}</option>`).join(``),Br=Object.freeze([`1`,`1.1`,`1.15`,`1.2`,`1.25`,`1.3`,`1.4`,`1.5`,`1.6`,`1.7`,`1.8`,`1.9`,`2`]),Vr=Object.freeze([`-2px`,`-1px`,`-0.5px`,`0px`,`0.25px`,`0.5px`,`1px`,`1.5px`,`2px`]),Hr=Object.freeze({baseFontSize:[12,24,1],fontSizeH1:[28,80,4],fontSizeH2:[22,64,2],fontSizeH3:[18,48,2],fontSizeH4:[16,40,2],fontSizeH5:[14,32,2],fontSizeH6:[12,28,2]}),Ur=[{property:`flex-direction`,label:`Направление`,options:[[`row`,`Строка`],[`column`,`Колонка`],[`row-reverse`,`Строка в обратном порядке`],[`column-reverse`,`Колонка в обратном порядке`]]},{property:`justify-content`,label:`Распределение`,options:[[`flex-start`,`По началу`],[`center`,`По центру`],[`flex-end`,`По концу`],[`space-between`,`Между элементами`],[`space-around`,`Вокруг элементов`],[`space-evenly`,`Равномерно`]]},{property:`align-items`,label:`Выравнивание`,options:[[`flex-start`,`По началу`],[`center`,`По центру`],[`flex-end`,`По концу`],[`stretch`,`Растянуть`],[`baseline`,`По базовой линии`]]},{property:`flex-wrap`,label:`Перенос`,options:[[`nowrap`,`Без переноса`],[`wrap`,`Переносить`],[`wrap-reverse`,`Переносить в обратном порядке`]]}].map(e=>`<div class="flex-control-group"><span class="flex-control-label">${e.label}</span><div class="flex-option-row">${e.options.map(([t,n])=>`<button type="button" class="flex-option" data-flex-property="${e.property}" data-flex-value="${t}" title="${e.property}: ${t}" aria-label="${e.label}: ${n}" aria-pressed="false"><span class="flex-glyph" data-property="${e.property}" data-value="${t}" aria-hidden="true"><i></i><i></i><i></i></span></button>`).join(``)}</div></div>`).join(``),Wr=e=>Kn.find(t=>t.id===e)?.category||{text:`Элементы`,image:`Медиа`,button:`Элементы`,container:`Компоновка`,navigation:`Навигация`}[e]||`Секции`,Gr=null,q,J,Y,X=!1,Kr=!1,qr=!1,Jr=!1,Z=!1,Yr,Xr,Zr=null,Qr=new Map,$r=(e,t=``)=>`/projects/${encodeURIComponent(Qr.get(e)||e)}${t}`;async function Q(e,t=`GET`,n){try{return await p({path:e,method:t,body:n,getSession:()=>q,setSession:e=>{q=e}})}catch(n){throw n.status===401&&q?.user&&e===`/projects`&&t===`POST`&&(q=null,location.assign(`/?session=expired`)),n}}function $(e,t=!1){let n=G(`#notice`);n&&(n.textContent=e,n.classList.toggle(`error`,t))}function ei(e){let t=G(`.editor-shell`);if(!t)return;t.dataset.openPanel=e===`library`||e===`layers`?e:`none`,e===`inspector`?t.dataset.inspectorOpen=`true`:window.matchMedia(`(max-width: 800px)`).matches&&(t.dataset.inspectorOpen=`false`);for(let t of document.querySelectorAll(`.mobile-workspace-tabs [data-mobile-panel]`))t.setAttribute(`aria-pressed`,String(t.dataset.mobilePanel===e));for(let t of document.querySelectorAll(`.editor-floating-tools [data-open-panel]`))t.setAttribute(`aria-pressed`,String(t.dataset.openPanel===e));let n=G(`#library`),r=G(`#layers`);n&&(n.hidden=e!==`library`),r&&(r.hidden=e!==`layers`)}function ti(e,t,n=`application/json`){let r=URL.createObjectURL(new Blob([t],{type:n})),i=document.createElement(`a`);i.href=r,i.download=e,i.click(),setTimeout(()=>URL.revokeObjectURL(r),1e3)}function ni(e=`import`){return new Promise(t=>{let n=e===`export`,r=document.createElement(`dialog`);r.className=`backup-passphrase-dialog`,r.innerHTML=`<form><p class="eyebrow">ЗАЩИТА БЭКАПА</p><h2>${n?`Пароль-фраза для переноса`:`Откройте переносимые ключи`}</h2><p class="muted">${n?`Задайте фразу не короче 16 символов и сохраните её отдельно. Она шифрует AI-ключи внутри файла. При импорте на другом сервере введите ту же фразу.`:`Введите фразу, использованную при экспорте. После импорта ключи будут повторно зашифрованы ключом этого сервера. Если на сервере уже есть профили, но утерян прежний .ai-key, этот файл восстановит включённые в него профили; прежние шифротексты останутся недоступны.`}</p><label class="settings-field">Пароль-фраза<input id="backup-passphrase-value" type="password" minlength="16" maxlength="1024" autocomplete="${n?`new-password`:`current-password`}" required></label>${n?`<label class="settings-field">Повторите фразу<input id="backup-passphrase-confirm" type="password" minlength="16" maxlength="1024" autocomplete="new-password" required></label>`:``}<p class="backup-passphrase-error" role="alert"></p><div class="dialog-actions"><button type="button" data-backup-cancel>Отмена</button><button class="primary" type="submit">${n?`Скачать защищённый бэкап`:`Продолжить импорт`}</button></div></form>`;let i=r.querySelector(`form`),a=r.querySelector(`#backup-passphrase-value`),o=r.querySelector(`.backup-passphrase-error`);i.onsubmit=e=>{e.preventDefault(),a.value.length<16?o.textContent=`Введите не менее 16 символов.`:n&&a.value!==r.querySelector(`#backup-passphrase-confirm`).value?o.textContent=`Фразы не совпадают.`:r.close(`confirm`)},r.querySelector(`[data-backup-cancel]`).onclick=()=>r.close(`cancel`),r.addEventListener(`close`,()=>{let e=r.returnValue===`confirm`?a.value:null;r.remove(),t(e)},{once:!0}),document.body.append(r),r.showModal(),a.focus()})}async function ri(e,t){let n=await fetch(`/api/projects/${encodeURIComponent(e)}/backup`,{method:`POST`,headers:{"Content-Type":`application/json`,...q?{"X-CSRF-Token":q.csrf}:{}},body:JSON.stringify({action:`export`,portablePassphrase:t})});if(!n.ok){let e=await n.json().catch(()=>({}));throw Error(e.error||`HTTP ${n.status}`)}let r=await n.blob();ti((n.headers.get(`Content-Disposition`)||``).match(/filename="([^"]+)"/)?.[1]||`juzimder-backup-${e}.json`,r,`application/json`)}function ii(e,t=`Продолжить`){let n=G(`#confirm-dialog`);return n||(n=document.createElement(`dialog`),n.id=`confirm-dialog`,n.innerHTML=`<form method="dialog"><p id="confirm-message"></p><div class="dialog-actions"><button value="cancel">Отмена</button><button id="confirm-submit" class="primary" value="confirm">Продолжить</button></div></form>`,Fr.append(n)),n.returnValue=``,G(`#confirm-message`).textContent=e,G(`#confirm-submit`).textContent=t,new Promise(e=>{n.addEventListener(`close`,()=>e(n.returnValue===`confirm`),{once:!0}),n.showModal()})}function ai(e,t=``){let n=K(e.id),r=K(e.name),i=$r(e.id);return`<details class="page-menu project-menu ${t}"><summary aria-label="Действия проекта: ${r}" title="Действия проекта">⋯</summary><div class="page-menu-popover"><a href="${i}">Страницы проекта</a><a href="${i}/settings">Настройки сайта</a><button data-project-action="rename" data-project-id="${n}">Переименовать</button><button data-project-action="backup" data-project-id="${n}">Скачать бэкап</button><button data-project-action="duplicate" data-project-id="${n}">Дублировать проект</button><button class="danger-action" data-project-action="delete" data-project-id="${n}">Удалить проект</button></div></details>`}function oi(e,t){let n=document.createElement(`dialog`);n.id=`project-name-dialog`,n.innerHTML=`<form id="project-name-form"><p class="eyebrow">ПРОЕКТ</p><h2>Переименовать проект</h2><label>Новое название<input name="name" required maxlength="100"></label><p id="project-name-error" role="alert"></p><div class="dialog-actions"><button type="button" id="cancel-project-name">Отмена</button><button class="primary" type="submit">Сохранить</button></div></form>`,Fr.append(n);let r=null,i=G(`#project-name-form`),a=i.elements.name,o=G(`#project-name-error`);G(`#cancel-project-name`).onclick=()=>n.close(),i.onsubmit=async e=>{if(e.preventDefault(),!r)return;let s=i.querySelector(`[type="submit"]`);s.disabled=!0,o.textContent=``;try{let e=await Q(`/projects/${encodeURIComponent(r.id)}/name`,`PUT`,{version:r.version,expectedName:r.name,name:a.value});r.name=e.name,r.version=e.version,e.slug&&Qr.set(e.id,e.slug),n.close(),$(`Название проекта сохранено.`),await t(r)}catch(e){o.textContent=e.message}finally{s.disabled=!1}};for(let i of document.querySelectorAll(`[data-project-action]`))i.onclick=async()=>{let s=e.find(e=>e.id===i.dataset.projectId),c=i.dataset.projectAction;if(s){if(i.closest(`details`)?.removeAttribute(`open`),c===`rename`)r=s,a.value=s.name,o.textContent=``,n.showModal(),a.focus(),a.select();else if(c===`delete`){if(!await ii(`Удалить проект «${s.name}» вместе со страницами, настройками, медиа и публикацией? Это действие нельзя отменить.`,`Удалить проект`))return;i.disabled=!0;try{await Q(`/projects/${encodeURIComponent(s.id)}`,`DELETE`,{version:s.version,expectedName:s.name}),Qr.delete(s.id),$(`Проект удалён.`),await t(s,!0)}catch(e){$(e.message,!0),i.disabled=!1}}else if(c===`backup`){let e=await ni(`export`);if(e===null)return;i.disabled=!0;try{await ri(s.id,e),$(`Переносимый бэкап скачан. Сохраните пароль-фразу отдельно.`)}catch(e){$(e.message,!0)}finally{i.disabled=!1}}else if(c===`duplicate`){if(!await ii(`Создать копию проекта «${s.name}» со страницами и настройками?`,`Дублировать проект`))return;i.disabled=!0;try{let e=await Q(`/projects/restore-from-backup`,`POST`,{backup:await Q(`/projects/${encodeURIComponent(s.id)}/backup`)});e.slug&&Qr.set(e.id,e.slug),location.assign($r(e.id))}catch(e){$(e.message,!0)}finally{i.disabled=!1}}}}}function si(){let e=G(`#save`);e&&(e.dataset.saveState=Z?`conflict`:qr?`saving`:X?`unsaved`:`saved`,e.setAttribute(`aria-busy`,String(qr)),ci())}function ci(){let e=G(`#publish-editor`);if(!e)return;let t=!(!Zr||!Y||X||qr||Zr.sourceProjectVersion!==Y.version);e.dataset.publishState=t?`published`:`unpublished`,e.title=t?`Опубликована текущая версия · ревизия ${Y.version}`:`Есть изменения для публикации`,e.setAttribute(`aria-label`,t?`Опубликовано`:`Опубликовать`)}function li(e=1400){clearTimeout(Yr),Yr=setTimeout(()=>{Yr=void 0,ui(!0)},e)}async function ui(e=!1){if(clearTimeout(Yr),Yr=void 0,!X||Z)return;if(qr)return Jr=!0,!e&&(await Xr,X&&!Z)?ui(!1):void 0;qr=!0;let t=G(`#save`);t&&(t.disabled=!0),si();let n=J.getProjectData(),r=JSON.stringify(n),i=Y.version,a=null;G(`#save-status`).textContent=e?`Автосохранение…`:`Сохранение…`;let o=(async()=>{try{Y=await Q(`/projects/${Y.id}`,`PUT`,{version:i,document:{schemaVersion:1,engine:`grapesjs`,data:n},settings:{designTokens:Y.settings.designTokens}}),Gr=r,X=JSON.stringify(J.getProjectData())!==r,G(`#save-status`).textContent=X?`Изменения продолжаются`:`${e?`Автосохранено`:`Сохранено`} · ревизия ${Y.version}`,$(``)}catch(e){if(e.status===409)Z=!0,G(`#save-status`).textContent=`Версия изменилась в другой вкладке`,G(`#reload-server`).hidden=!1,$(`Экспортируйте локальные изменения или загрузите серверную версию.`,!0);else{let t=!e.status||e.status>=500;G(`#save-status`).textContent=t?`Не удалось сохранить · повторим автоматически`:`Не удалось сохранить · проверьте изменения`,$(e.message,!0),t&&(a=5e3)}}finally{qr=!1,t&&(t.disabled=Z),si();let e=Jr;Jr=!1,e&&X&&!Z?await ui(!0):X&&!Z&&!Yr&&a!==null&&li(a)}})();return Xr=o,o}function di(){let e=document.createElement(`span`);return e.id=`project-name`,e.className=`project-name`,e.setAttribute(`role`,`button`),e.tabIndex=0,e.textContent=Y.name,e.title=`Дважды щёлкните, чтобы изменить название проекта`,e.setAttribute(`aria-label`,`Переименовать проект: ${Y.name}`),fi(e)}function fi(e){return e.addEventListener(`dblclick`,()=>pi(e)),e.addEventListener(`keydown`,t=>{(t.key===`Enter`||t.key===` `||t.key===`F2`)&&(t.preventDefault(),pi(e))}),e}function pi(e){if(!e.isConnected)return;let t=Y.id,n=Y.name,r=document.createElement(`input`),i=!1,a=!1;r.className=`project-name-input`,r.type=`text`,r.maxLength=100,r.value=n,r.setAttribute(`aria-label`,`Новое название проекта`);let o=()=>{r.isConnected&&r.replaceWith(di())},s=()=>{a||i||(a=!0,o(),$(``))},c=async()=>{if(a||i)return;let e=r.value.trim();if(!e)$(`Название проекта не может быть пустым.`,!0),r.focus();else if(e===n)a=!0,o(),$(``);else{i=!0,r.disabled=!0;try{Y=await Q(`/projects/${t}/name`,`PUT`,{version:Y.version,expectedName:n,name:e}),a=!0,o(),$(`Название проекта сохранено`)}catch(e){i=!1,r.disabled=!1,$(e.message,!0),r.focus(),r.select()}}};r.addEventListener(`keydown`,e=>{e.key===`Enter`?(e.preventDefault(),c()):e.key===`Escape`&&(e.preventDefault(),s())}),r.addEventListener(`blur`,()=>{!a&&!i&&c()}),e.replaceWith(r),r.focus(),r.select()}function mi(e=!1,t=!1){let n=q?.devAuth===!0,r=n&&!e&&!t,i=q?.sessionExpired||new URLSearchParams(location.search).get(`session`)===`expired`,a=t?`Восстановление доступа`:e?`Создайте своё пространство`:`С возвращением`,o=t?`Используйте один из заранее сохранённых резервных кодов.`:e?`Начните с первой страницы.`:`Войдите, чтобы продолжить работу над сайтом.`,s=t?`<label>Email аккаунта<input name="email" type="email" autocomplete="username" required maxlength="254" placeholder="${n?`admin@localhost.test`:`you@studio.kz`}"></label><label>Резервный код<input name="code" autocomplete="one-time-code" autocapitalize="characters" spellcheck="false" required maxlength="40" placeholder="XXXXXX-XXXXXX-XXXXXX-XXXXXX"></label><label>Новый пароль<input name="password" type="password" autocomplete="new-password" minlength="10" maxlength="72" required placeholder="Не менее 10 символов"></label><button class="primary" type="submit">Восстановить доступ <span>→</span></button>`:`<label>${r?`Email или локальный логин`:`Email`}<input name="email" type="${r?`text`:`email`}" autocomplete="${e?`email`:`username`}" required ${e||!q?.devAuth?`minlength="10"`:``} maxlength="254" placeholder="${r?`admin или you@studio.kz`:`you@studio.kz`}"></label><label>Пароль<input name="password" type="password" autocomplete="${e?`new-password`:`current-password`}" required ${e||!q?.devAuth?`minlength="10"`:``} maxlength="72" placeholder="${r?`admin или не менее 10 символов`:`Не менее 10 символов`}"></label><button class="primary" type="submit">${e?`Создать аккаунт`:`Войти в пространство`} <span>→</span></button>`;Fr.innerHTML=`<main class="auth"><div class="auth-story"><a class="brand" href="/">${Lr} Juzimder <span>AI</span></a><div><p class="eyebrow">ВАШ СЛЕДУЮЩИЙ ПРОЕКТ НАЧИНАЕТСЯ ЗДЕСЬ</p><h1>Из идеи —<br>в живой сайт.</h1><p class="intro">Пространство, где дизайн складывается.<br>Одна секция, одна страница, одна идея за раз.</p></div><p class="muted">На базе GrapesJS Core · Открытая платформа</p></div><section class="auth-form"><p class="eyebrow">JUZIMDER WORKSPACE / 01</p><h2>${a}</h2><p class="muted">${o}</p>${!t&&i?`<p class="muted" role="status">Сессия не относится к текущей локальной базе. Войдите снова.</p>`:``}<form id="auth-form">${s}<p id="notice" role="status"></p></form>${r?`<p class="muted small">Локальный тестовый вход: <strong>admin / admin</strong></p>`:``}${t?`<button class="text-button" id="toggle-auth" type="button">Вернуться ко входу</button>`:`<button class="text-button" id="toggle-auth" type="button">${e?`Уже есть аккаунт? Войти`:`Первый раз здесь? Создать аккаунт`}</button>${e?``:`<button class="text-button" id="recover-auth" type="button">Есть резервный код? Восстановить доступ</button>`}`}<p class="auth-foot">Ранняя версия · Визуальное редактирование и сохранение</p></section></main>`,G(`#toggle-auth`).onclick=()=>mi(!t&&!e),G(`#recover-auth`)?.addEventListener(`click`,()=>mi(!1,!0)),G(`#auth-form`).onsubmit=async n=>{n.preventDefault();let r=n.target.querySelector(`button`);r.disabled=!0;try{let r=Object.fromEntries(new FormData(n.target));if(t){let e=await Q(`/recover`,`POST`,r);q=await Q(`/session`),mi(!1),G(`#notice`).textContent=e.message;return}q=await Q(e?`/register`:`/login`,`POST`,r),history.replaceState(null,``,`/`),await _i()}catch(e){$(e.message,!0)}finally{r.isConnected&&(r.disabled=!1)}}}function hi(){let e=G(`.dash-user`);if(!e)return;let t=document.createElement(`button`);t.type=`button`,t.className=`secondary-link`,t.textContent=`Доступ для AI`,e.append(t),t.onclick=async()=>{let e=document.createElement(`dialog`);e.className=`recovery-dialog`,e.innerHTML=`<h2>Доступ для AI · MCP</h2><p class="muted">Выберите проекты и права подключения. Токен показывается только при создании.</p><form><label>Название<input name="name" required maxlength="80" placeholder="Мой Codex"></label><fieldset><legend>Разрешённые проекты</legend><div class="mcp-projects"></div></fieldset><label><input name="write" type="checkbox"> Разрешить редактирование</label><label>Срок<select name="days"><option value="7">7 дней</option><option value="30" selected>30 дней</option><option value="90">90 дней</option></select></label><button class="primary" type="submit">Создать токен</button></form><p class="mcp-status" role="status"></p><pre class="mcp-secret" hidden></pre><div class="mcp-tokens"></div><button type="button" class="mcp-close">Закрыть</button>`,Fr.append(e),e.showModal(),e.onclose=()=>e.remove(),e.querySelector(`.mcp-close`).onclick=()=>e.close();let t=e.querySelector(`.mcp-status`),n=e.querySelector(`.mcp-tokens`);if(q?.canManageUpdates){let t=document.createElement(`section`),n=document.createElement(`button`),r=document.createElement(`button`),i=document.createElement(`pre`),a=document.createElement(`a`);n.type=r.type=`button`,n.textContent=`Запустить диагностику входа MCP`,r.textContent=`Обновить диагностику`,a.textContent=`Открыть контрольный GET`,a.target=`_blank`,a.rel=`noopener`,a.hidden=!0,i.style.whiteSpace=`pre-wrap`;let o=e=>{let t=e.probe;t?(a.href=location.origin+`/mcp?diagnostic_id=`+t.id,a.hidden=!1,i.textContent=`ID: `+t.id+`
Действует до: `+new Date(t.expiresAt*1e3).toLocaleTimeString()+`
Входы в PHP: `+JSON.stringify(t.hits)):i.textContent=`Активной диагностики нет.`};n.onclick=async()=>{try{o(await Q(`/system/mcp-ingress-probe`,`POST`,{}))}catch(e){i.textContent=e.message}},r.onclick=async()=>{try{o(await Q(`/system/mcp-ingress-probe`))}catch(e){i.textContent=e.message}},t.append(n,r,a,i),e.append(t)}let r=async()=>{let e=await Q(`/account/mcp-tokens`);n.replaceChildren();for(let i of e.items){let e=document.createElement(`p`),a=document.createElement(`span`);if(a.textContent=i.name+` · `+(i.can_write?`чтение и запись`:`чтение`)+` · `+new Date(i.expires_at*1e3).toLocaleDateString(),e.append(a),!i.revoked_at&&i.expires_at*1e3>Date.now()){let n=document.createElement(`button`);n.type=`button`,n.textContent=`Отозвать`,n.onclick=async()=>{try{await Q(`/account/mcp-tokens/`+i.id,`DELETE`),await r()}catch(e){t.textContent=e.message}},e.append(n)}else e.append(document.createTextNode(` · недействителен`));n.append(e)}};try{let t=await Q(`/projects`);for(let n of t){let t=document.createElement(`label`),r=document.createElement(`input`);r.type=`checkbox`,r.name=`projectIds`,r.value=n.id,t.append(r,document.createTextNode(n.name)),e.querySelector(`.mcp-projects`).append(t)}await r()}catch(e){t.textContent=e.message}e.querySelector(`form`).onsubmit=async n=>{n.preventDefault();let i=n.currentTarget,a=i.querySelector(`[type="submit"]`);a.disabled=!0;try{let n=await Q(`/account/mcp-tokens`,`POST`,{name:i.elements.name.value,projectIds:[...i.querySelectorAll(`[name="projectIds"]:checked`)].map(e=>e.value),write:i.elements.write.checked,days:Number(i.elements.days.value)}),a=e.querySelector(`.mcp-secret`);a.hidden=!1,a.textContent=`URL: `+location.origin+`/mcp
Authorization: Bearer `+n.token,t.textContent=`Сохраните токен: после закрытия окна он больше не показывается. Передавайте его только выбранному MCP-клиенту.`,await r()}catch(e){t.textContent=e.message}finally{a.disabled=!1}}}}function gi(){let e=G(`.dash-user`);if(!e)return;let t=document.createElement(`button`);t.id=`manage-recovery-codes`,t.type=`button`,t.className=`secondary-link`,t.textContent=`Коды восстановления`,t.setAttribute(`aria-label`,`Настроить одноразовые коды восстановления аккаунта`);let n=e.querySelector(`.version-label`);e.insertBefore(t,n||null);let r=document.createElement(`dialog`);r.id=`recovery-dialog`,r.className=`recovery-dialog`,r.innerHTML=`<form id="recovery-code-form"><p class="eyebrow">БЕЗОПАСНОСТЬ АККАУНТА</p><h2>Резервные коды</h2><p class="muted">Создайте восемь одноразовых кодов. Предыдущий набор будет заменён. Сохраните их вне браузера: повторно посмотреть значения будет нельзя.</p><label>Текущий пароль<input name="password" type="password" autocomplete="current-password" required maxlength="72"></label><p id="recovery-code-status" class="muted small" role="status"></p><div class="dialog-actions"><button id="cancel-recovery-codes" type="button">Отмена</button><button class="primary" type="submit">Создать новые коды</button></div></form><section id="recovery-codes-result" hidden><h2>Сохраните эти коды</h2><p class="muted">Каждый код можно применить один раз. После закрытия окна значения исчезнут.</p><pre id="recovery-codes-list" class="recovery-codes-list"></pre><div class="dialog-actions"><button id="recovery-copy" type="button">Скопировать</button><button id="recovery-finish" class="primary" type="button">Готово</button></div></section>`,Fr.append(r);let i=G(`#recovery-code-form`),a=G(`#recovery-codes-result`),o=G(`#recovery-codes-list`),s=G(`#recovery-code-status`),c=G(`#recovery-copy`);t.onclick=()=>{i.hidden=!1,a.hidden=!0,i.reset(),s.textContent=``,r.showModal()},i.onsubmit=async e=>{e.preventDefault();let t=i.querySelector(`[type="submit"]`);t.disabled=!0,s.textContent=`Проверяем пароль и создаём коды…`;try{let e=await Q(`/account/recovery-codes`,`POST`,Object.fromEntries(new FormData(i)));o.textContent=e.codes.join(`
`),i.elements.password.value=``,i.hidden=!0,a.hidden=!1}catch(e){s.textContent=e.message}finally{t.disabled=!1}},G(`#cancel-recovery-codes`).onclick=()=>r.close(),G(`#recovery-finish`).onclick=()=>r.close(),c.onclick=async()=>{try{await navigator.clipboard.writeText(o.textContent),c.textContent=`Скопировано`}catch{s.textContent=`Не удалось скопировать автоматически. Выделите коды и скопируйте их вручную.`}},r.addEventListener(`close`,()=>{o.textContent=``,i.reset(),i.hidden=!1,a.hidden=!0,s.textContent=``,c.textContent=`Скопировать`})}async function _i(){let e=await Q(`/projects`);for(let t of e)t.slug&&Qr.set(t.id,t.slug);Fr.innerHTML=`<div class="dashboard"><aside class="dash-sidebar"><a class="brand" href="/">${Lr} Juzimder <span>AI</span></a><div class="workspace-label">ЛИЧНОЕ ПРОСТРАНСТВО</div><div class="nav-active">▦ <span>Мои проекты</span><small>${e.length}</small></div><div class="sidebar-note"><span class="status-dot"></span> FOUNDATION<div class="version-label">Версия продукта <strong>${Ir}</strong></div><p>От первой идеи<br>до первой страницы.</p></div><button id="logout" class="text-button">Выйти из аккаунта ↗</button></aside><main class="dash-main"><header class="dash-top"><span>Workspace <span class="slash">/</span> Мои проекты</span><span class="dash-user"><span>${K(q.user.email)}</span><span class="version-label">Версия ${Ir}</span></span></header><section class="project-intro"><p class="eyebrow">СОЗДАВАЙТЕ В СВОЁМ РИТМЕ</p><div class="title-row"><div><h1>Мои проекты<span class="accent">.</span></h1><p class="muted">Хорошие сайты начинаются с чистого листа.</p></div><button id="new-project" class="primary">+ Новый проект</button></div></section><section class="project-list">${e.map(e=>`<article class="project-card project-entry"><a class="project-card-link" data-project-open="${K(e.id)}" href="${$r(e.id)}"><div class="project-art"><div class="mini-window"><div></div><i></i><i></i><span></span></div><span class="project-arrow">↗</span></div><div class="project-info"><h3>${K(e.name)}</h3><p>${e.version?`Ревизия `+e.version:`Новый проект`} <span>Страницы →</span></p></div></a>${ai(e,`project-card-menu`)}</article>`).join(``)}<button class="project-card new-card" id="empty-create"><span class="plus">+</span><strong>Новая идея</strong><span>Создайте сайт с нуля</span></button></section><p id="notice" role="status"></p><footer class="dash-footer"><span>YOUR IDEAS, TAKING SHAPE.</span><span>GrapesJS Core · PHP · SQLite</span></footer></main></div><dialog id="create-dialog"><form id="create-form"><p class="eyebrow">НОВОЕ ПРОСТРАНСТВО</p><h2>Как назовём проект?</h2><label>Название проекта<input name="name" required maxlength="100" placeholder="Например, Сайт студии"></label><p class="muted">Начнём с пустой главной страницы.</p><p id="create-error" role="alert"></p><div class="dialog-actions"><button type="button" id="cancel-create">Отмена</button><button class="primary">Создать проект →</button></div></form></dialog>`,gi(),hi(),oi(e,async()=>_i());let t=()=>G(`#create-dialog`).showModal();G(`#new-project`).onclick=t,G(`#empty-create`).onclick=t,G(`#cancel-create`).onclick=()=>G(`#create-dialog`).close(),G(`#create-form`).onsubmit=async e=>{e.preventDefault();let t=e.target.querySelector(`.primary`);t.disabled=!0;try{let t=await Q(`/projects`,`POST`,{name:new FormData(e.target).get(`name`)});Qr.set(t.id,t.slug),location.assign($r(t.id))}catch(e){G(`#create-error`).textContent=e.message,t.disabled=!1}};let n=G(`#new-project`),r=document.createElement(`div`),i=document.createElement(`button`),a=document.createElement(`input`);if(r.className=`project-actions dashboard-project-actions`,i.type=`button`,i.className=`secondary-link`,i.textContent=`Восстановить из бэкапа`,a.type=`file`,a.accept=`application/json,.json`,a.hidden=!0,a.setAttribute(`aria-label`,`Файл резервной копии проекта`),n.replaceWith(r),r.append(n,i),G(`.project-intro`).append(a),q?.canManageUpdates===!0){let e=document.createElement(`button`),t=document.createElement(`button`),n=document.createElement(`p`);e.type=`button`,e.className=`secondary-link`,e.textContent=`Проверить обновления`,t.type=`button`,t.className=`primary`,t.textContent=`Установить обновление`,t.hidden=!0,n.className=`muted small app-update-status`,n.setAttribute(`role`,`status`),n.setAttribute(`aria-live`,`polite`),r.append(e,t),G(`.project-intro`).append(n);let i=null,a=null,o=null;e.onclick=async()=>{e.disabled=!0,t.hidden=!0,n.textContent=`Проверяем выпуск и последнюю сборку репозитория…`;try{let e=await Q(`/system/updates`);i=e.latestVersion,a=e.source,o=e.sourceCommit,e.updateAvailable?(n.textContent=`Доступна версия `+e.latestVersion+` из `+e.sourceLabel+(e.currentVersion?` · установлена `+e.currentVersion:``)+`. Перед заменой файлов приложение сохранит SQLite-базу и ключи в закрытом var/.`,t.textContent=`Обновить до `+e.latestVersion,t.hidden=!1):n.textContent=`Установлена последняя версия `+e.currentVersion+`. Новейший источник: `+e.sourceLabel+`.`}catch(e){i=null,a=null,o=null,n.textContent=e.message}finally{e.disabled=!1}},t.onclick=async()=>{if(!i||!a)return;let r=a===`repository`?`последней успешной сборки репозитория main`:`стабильного GitHub Release`,s=document.createElement(`dialog`);s.id=`update-install-confirm`,s.innerHTML=`<form method="dialog"><p class="eyebrow">ОБНОВЛЕНИЕ</p><p id="update-install-message"></p><div class="dialog-actions"><button value="cancel">Отмена</button><button class="primary" value="confirm">Установить</button></div></form>`,s.querySelector(`#update-install-message`).textContent=`Установить Juzimder AI `+i+` из `+r+`? Перед заменой будет сохранена база и ключи приложения.`,Fr.append(s);let c=await new Promise(e=>{s.addEventListener(`close`,()=>e(s.returnValue===`confirm`),{once:!0}),s.showModal()});if(s.remove(),c){e.disabled=!0,t.disabled=!0,n.textContent=`Скачиваем, проверяем архив и устанавливаем…`;try{let e=await Q(`/system/updates/install`,`POST`,{expectedVersion:i,expectedSource:a,expectedCommit:o});n.textContent=e.message,setTimeout(()=>location.reload(),900)}catch(e){n.textContent=e.message,t.disabled=!1}finally{e.disabled=!1}}}}i.onclick=()=>a.click(),a.onchange=async()=>{let e=a.files?.[0];if(e){i.disabled=!0;try{if(e.size>33554432)throw Error(`Файл превышает допустимый размер 32 МБ.`);let t=JSON.parse(await e.text());if(t?.format!==`juzimder-project-backup`||![1,2,3].includes(t?.backupVersion)||!t?.project||typeof t.project.name!=`string`)throw Error(`Файл не является резервной копией Juzimder поддерживаемого формата.`);let n=t.backupVersion===3?await ni(`import`):null;if(t.backupVersion===3&&n===null)return;$(`Восстанавливаем «${t.project.name}» как новый проект…`);let r=await Q(`/projects/restore-from-backup`,`POST`,{backup:t,...n===null?{}:{portablePassphrase:n}});Qr.set(r.id,r.slug),location.assign($r(r.id))}catch(e){$(e.message,!0)}finally{i.disabled=!1,a.value=``}}},G(`#logout`).onclick=async()=>{await Q(`/logout`,`POST`,{}),q=await Q(`/session`),mi()}}async function vi(e){let t=await Q(`/projects/${e}/pages`),n=t.project,r=t.pages;n.slug&&Qr.set(e,n.slug);let i=await Q(`/projects/${e}/publication`),a=i.publication,o=i.publicUrl,s=null,c=fn(n.settings,n.document),l=r.map(t=>`<tr><td class="page-select-cell"><input type="checkbox" class="page-select" data-page-select="${K(t.id)}" aria-label="Выбрать страницу ${K(t.name)}"></td><td><a class="page-title" href="${$r(e)}/pages/${encodeURIComponent(t.id)}/edit">${K(t.name)}</a><small class="page-revision-link">Изменить содержимое →</small></td><td><button class="url-value" data-page-action="slug" data-page="${K(t.id)}" aria-label="Изменить URL ${K(t.name)}">${K(t.path)}</button></td><td><span class="home-state ${t.isHome?`is-home`:``}">${t.isHome?`⌂ Главная`:`Обычная`}</span></td><td><details class="page-menu"><summary aria-label="Действия: ${K(t.name)}">⋯</summary><div class="page-menu-popover"><a href="${$r(e)}/pages/${encodeURIComponent(t.id)}/edit">Редактировать</a><button data-page-action="rename" data-page="${K(t.id)}">Переименовать</button><button data-page-action="slug" data-page="${K(t.id)}">Изменить URL</button><button data-page-action="duplicate" data-page="${K(t.id)}">Дублировать</button><button data-page-action="home" data-page="${K(t.id)}" ${t.isHome?`disabled`:``}>Сделать главной</button><button data-page-action="page-settings" data-page="${K(t.id)}">Настройки страницы</button><button class="danger-action" data-page-action="delete" data-page="${K(t.id)}">Удалить</button></div></details></td></tr>`).join(``),u=(t,n,r,i)=>`<div><span class="system-icon">${n}</span><span><strong>${t}</strong><small>${r.configured?`${K(r.name)} · ${r.pageCount} стр.`:`Не настроена`}</small></span><span class="status-pill ${r.configured?`is-configured`:``}">${r.configured?`Подключена`:`Не выбрана`}</span><a class="system-settings-link" href="${$r(e)}/settings?section=header-footer">Настроить</a></div>`;Fr.innerHTML=`<div class="dashboard project-dashboard"><aside class="dash-sidebar"><a class="brand" href="/">${Lr} Juzimder <span>AI</span></a><div class="workspace-label">ПРОЕКТ</div><a class="nav-active" href="${$r(e)}">▦ <span>Страницы</span><small>${r.length}</small></a><a class="project-side-link" href="${$r(e)}/settings">⚙ <span>Настройки сайта</span></a><div class="sidebar-note"><span class="status-dot"></span> FOUNDATION<div class="version-label">Версия продукта <strong>${Ir}</strong></div><p>${K(n.name)}</p></div><a class="text-button" href="/">← Все проекты</a><button id="logout" class="text-button">Выйти из аккаунта ↗</button></aside><main class="dash-main"><header class="dash-top"><span><a href="/">Мои проекты</a><span class="slash">/</span>${K(n.name)}</span><span class="version-label">Версия ${Ir}</span></header><section class="project-intro"><p class="eyebrow">УПРАВЛЕНИЕ САЙТОМ</p><div class="title-row project-title-row"><div><h1>${K(n.name)}<span class="accent">.</span></h1><p class="muted">Страницы сайта · ревизия ${n.version}</p></div><div class="project-actions"><a class="secondary-link" href="${$r(e)}/settings">Настройки сайта</a><button id="create-page" class="primary">+ Создать страницу</button></div></div></section><section class="project-pages-section publication-panel" aria-labelledby="publication-title"><div class="section-title-row"><div><h2 id="publication-title">Публикация сайта</h2><p class="muted">Публичный адрес обслуживает только сохранённый статический снимок.</p></div><span id="publication-status" class="status-pill" role="status" aria-live="polite">Проверка…</span></div><div class="publication-actions"><button id="preview-site" class="secondary-link">Предпросмотр</button><button id="publish-site" class="primary">Опубликовать сайт</button><button id="unpublish-site" class="secondary-link" hidden>Снять с публикации</button><a id="publication-link" class="secondary-link" target="_blank" rel="noopener noreferrer" hidden>Открыть сайт ↗</a></div></section><section class="project-pages-section"><div class="section-title-row"><div><h2>Страницы</h2><p class="muted">URL-адреса не меняют внутренние идентификаторы страниц.</p></div><span class="page-count">${r.length} из 30</span></div><div class="bulk-page-actions"><label class="visually-hidden" for="bulk-page-action">Действия с выбранными страницами</label><select id="bulk-page-action" disabled><option value="">Действия с выбранными…</option><option value="duplicate">Дублировать выбранные</option><option value="home">Сделать главной</option><option value="delete">Удалить выбранные</option></select><span id="bulk-page-selection" class="muted small" role="status" aria-live="polite">Страницы не выбраны</span></div>${r.length?`<div class="pages-table-wrap"><table class="pages-table"><thead><tr><th class="page-select-cell"><input type="checkbox" id="select-all-pages" aria-label="Выбрать все страницы"></th><th>Название страницы</th><th>URL страницы</th><th>Главная</th><th><span class="visually-hidden">Действия</span></th></tr></thead><tbody>${l}</tbody></table></div>`:`<div class="empty-pages"><h3>Здесь появится первая страница</h3><p>Создайте страницу, затем откройте её в редакторе.</p><button class="primary" id="empty-create-page">Создать первую страницу</button></div>`}</section><section class="project-pages-section system-items-section"><div class="section-title-row"><div><h2>Сквозные блоки и системные страницы</h2><p class="muted">Общие секции проекта используются на выбранных страницах при публикации, предпросмотре и экспорте.</p></div></div><div class="system-items">${u(`Шапка сайта`,`↥`,c.header,`header`)}${u(`Подвал сайта`,`↧`,c.footer,`footer`)}<div><span class="system-icon">404</span><span><strong>Страница 404</strong><small>Системная страница для опубликованного сайта</small></span><span class="status-pill">Настраивается в настройках сайта</span><a class="system-settings-link" href="${$r(e)}/settings?section=not-found">Настроить</a></div></div></section><p id="notice" role="status"></p><footer class="dash-footer"><span>YOUR IDEAS, TAKING SHAPE.</span><span>GrapesJS Core · PHP · SQLite</span></footer></main></div><dialog id="page-dialog"><form id="project-page-form"><p class="eyebrow" id="page-dialog-eyebrow">СТРАНИЦА ПРОЕКТА</p><h2 id="page-dialog-title"></h2><label id="page-dialog-label">Название<input id="page-dialog-input" name="value" required maxlength="100"></label><p class="muted small" id="page-dialog-help"></p><p id="page-dialog-error" role="alert"></p><div class="dialog-actions"><button type="button" id="cancel-page-dialog">Отмена</button><button class="primary" id="submit-page-dialog">Сохранить</button></div></form></dialog><dialog id="confirm-dialog"><form method="dialog"><p id="confirm-message"></p><div class="dialog-actions"><button value="cancel">Отмена</button><button id="confirm-submit" class="primary" value="confirm">Продолжить</button></div></form></dialog><dialog id="site-preview-dialog" class="site-preview-dialog" aria-labelledby="site-preview-title"><div class="site-preview-header"><div><p class="eyebrow">ПРЕДПРОСМОТР</p><h2 id="site-preview-title">Сохранённый сайт</h2></div><button id="close-site-preview" type="button" aria-label="Закрыть предпросмотр">×</button></div><label class="site-preview-selector">Страница<select id="site-preview-page" aria-label="Страница предпросмотра"></select></label><p id="site-preview-status" role="status" aria-live="polite">Подготовка…</p><iframe id="site-preview-frame" title="Предпросмотр страницы сайта" sandbox=""></iframe></dialog>`,G(`.project-title-row .project-actions`)?.insertAdjacentHTML(`beforeend`,ai(n,`project-title-menu`)),oi([n],async(t,n)=>{n?location.assign(`/`):await vi(e)}),kt(e,Q);let d=()=>{let e=G(`#publication-status`),t=G(`#publication-link`),r=G(`#publish-site`),i=G(`#unpublish-site`),s=a&&a.sourceProjectVersion!==n.version,c=!(!a||s);e.textContent=a?s?`Устарела · версия ${a.version}, ревизия ${a.sourceProjectVersion}`:`Опубликована · версия ${a.version}, ревизия ${a.sourceProjectVersion}`:`Не опубликован`,e.classList.toggle(`publication-stale`,!!s),r.dataset.publicationState=c?`published`:`unpublished`,r.textContent=a?`Опубликовать ревизию ${n.version}`:`Опубликовать сайт`,i.hidden=!a,t.hidden=!a,a&&(t.href=o)};d();let f=new Set,p=G(`#select-all-pages`),m=G(`#bulk-page-action`),h=G(`#bulk-page-selection`),g=()=>[...f].filter(e=>r.some(t=>t.id===e)),_=()=>{let e=[...document.querySelectorAll(`[data-page-select]`)],t=g();for(let t of e)t.checked=f.has(t.dataset.pageSelect);p.checked=e.length>0&&t.length===e.length,p.indeterminate=t.length>0&&t.length<e.length,m.disabled=t.length===0,h.textContent=t.length?`Выбрано: ${t.length}`:`Страницы не выбраны`};p.onchange=()=>{if(f.clear(),p.checked)for(let e of r)f.add(e.id);_()};for(let e of document.querySelectorAll(`[data-page-select]`))e.onchange=()=>{e.checked?f.add(e.dataset.pageSelect):f.delete(e.dataset.pageSelect),_()};m.onchange=async()=>{let t=m.value,i=g();if(!t||!i.length)return;if(m.value=``,t===`home`&&i.length!==1){$(`Чтобы выбрать главную, отметьте ровно одну страницу.`,!0);return}if(t===`delete`&&i.length>=r.length){$(`Нельзя удалить все страницы проекта. Оставьте хотя бы одну.`,!0);return}if(t===`duplicate`&&r.length+i.length>30){$(`В проекте можно иметь не более 30 страниц.`,!0);return}if(t===`delete`){let e=i.map(e=>r.find(t=>t.id===e)?.name).filter(Boolean);if(!await ii(`Удалить ${i.length} страниц: ${e.map(e=>`«${e}»`).join(`, `)}? Это действие создаст новые ревизии проекта.`,`Удалить выбранные`))return}m.disabled=!0;let a=0;try{for(let r of i){let i=await Q(`/projects/${e}/pages/${encodeURIComponent(r)}`,`POST`,{version:n.version,action:t});n.version=i.version,a++}await vi(e),$(t===`delete`?`Удалено страниц: ${a}.`:t===`duplicate`?`Создано копий: ${a}.`:`Главная страница обновлена.`)}catch(t){$(a?`Выполнено ${a} из ${i.length}. Остальные действия не завершены: ${t.message}`:t.message,!0),await vi(e)}finally{m.disabled=!1}},_();let v=null,y=G(`#site-preview-dialog`),b=G(`#site-preview-frame`),x=G(`#site-preview-page`),S=G(`#site-preview-status`),C=()=>{let e=v?.pages.find(e=>e.path===x.value);if(!e)return;let t=new DOMParser().parseFromString(e.html,`text/html`),n=t.querySelector(`link[rel="stylesheet"]`);if(n){let e=t.createElement(`style`);e.textContent=v.css,n.replaceWith(e)}if(!t.body.children.length&&!t.body.textContent.trim()){let e=t.createElement(`div`);e.textContent=`Страница пока пустая. Откройте редактор и добавьте секции, чтобы увидеть сайт.`,e.style.cssText=`margin:24px;padding:22px;border:1px dashed #a8b7aa;border-radius:8px;color:#526457;background:#f5f8f5;font:14px/1.6 system-ui,sans-serif;text-align:center`,t.body.append(e)}b.srcdoc=`<!doctype html>`+t.documentElement.outerHTML};G(`#preview-site`).onclick=async()=>{let t=G(`#preview-site`);t.disabled=!0,S.textContent=`Подготовка предпросмотра…`,y.showModal();try{if(v=await Q(`/projects/${e}/preview/static`),!Array.isArray(v.pages)||!v.pages.length)throw Error(`В проекте пока нет страниц для предпросмотра.`);x.replaceChildren(...v.pages.map(e=>{let t=document.createElement(`option`);return t.value=e.path,t.textContent=`${e.name} · ${e.path}`,t})),x.value=v.pages[0].path,C(),S.textContent=`Сохранённая ревизия ${v.version}. Изменения и публикация не затронуты.`}catch(e){S.textContent=e.message}finally{t.disabled=!1}},x.onchange=C,G(`#close-site-preview`).onclick=()=>y.close(),y.addEventListener(`close`,()=>{b.srcdoc=``,v=null}),G(`#publish-site`).onclick=async()=>{if(!await ii(`Будет опубликована сохранённая ревизия ${n.version}. Сайт станет доступен без входа на отдельном публичном адресе. Продолжить?`,`Опубликовать`))return;let t=G(`#publish-site`);t.disabled=!0;try{let t=await Q(`/projects/${e}/publish`,`POST`,{version:n.version});a=t.publication,o=t.publicUrl,d(),$(`Сохранённая ревизия опубликована.`)}catch(e){$(e.message,!0)}finally{t.disabled=!1}},G(`#unpublish-site`).onclick=async()=>{if(!await ii(`Отключить публичный сайт? История публикаций сохранится.`,`Снять с публикации`))return;let t=G(`#unpublish-site`);t.disabled=!0;try{a=(await Q(`/projects/${e}/unpublish`,`POST`,{version:n.version})).publication,o=null,d(),$(`Публичный сайт отключён. История публикаций сохранена.`)}catch(e){$(e.message,!0)}finally{t.disabled=!1}};let w=(e,t=null)=>{s={action:e,pageId:t?.id??null};let n=e===`slug`;G(`#page-dialog-eyebrow`).textContent=e===`create`?`НОВАЯ СТРАНИЦА`:`ИЗМЕНИТЬ СТРАНИЦУ`,G(`#page-dialog-title`).textContent=e===`create`?`Создать страницу`:n?`Изменить URL страницы`:`Переименовать страницу`,G(`#page-dialog-label`).firstChild.textContent=n?`URL страницы`:`Название`;let r=G(`#page-dialog-input`);r.value=n?t?.slug||``:e===`create`?``:t?.name||``,r.maxLength=n?80:100,r.placeholder=n?`about-us`:`Например, О компании`,G(`#page-dialog-help`).textContent=n?`Введите один адресный сегмент. Кириллица автоматически преобразуется в латиницу. Для главной страницы публичный адрес остаётся /.`:``,G(`#page-dialog-error`).textContent=``,G(`#page-dialog`).showModal(),r.focus(),r.select()};G(`#create-page`).onclick=()=>w(`create`),G(`#empty-create-page`)?.addEventListener(`click`,()=>w(`create`)),G(`#cancel-page-dialog`).onclick=()=>G(`#page-dialog`).close(),G(`#project-page-form`).onsubmit=async t=>{if(t.preventDefault(),!s)return;let r=G(`#submit-page-dialog`);r.disabled=!0;try{let t=s.action,r={version:n.version,action:t};(t===`create`||t===`rename`)&&(r.name=G(`#page-dialog-input`).value),t===`slug`&&(r.slug=G(`#page-dialog-input`).value),await Q(s.pageId?`/projects/${e}/pages/${encodeURIComponent(s.pageId)}`:`/projects/${e}/pages`,`POST`,r),G(`#page-dialog`).close(),await vi(e)}catch(e){G(`#page-dialog-error`).textContent=e.message}finally{r.disabled=!1}};for(let t of document.querySelectorAll(`[data-page-action]`))t.onclick=async()=>{let i=t.dataset.pageAction,a=r.find(e=>e.id===t.dataset.page);if(i===`rename`||i===`slug`)w(i,a),t.closest(`details`)?.removeAttribute(`open`);else if(i===`page-settings`)$(`Настройки отдельных страниц появятся вместе с разделом SEO.`,!0),t.closest(`details`)?.removeAttribute(`open`);else if(i!==`delete`||await ii(`Удалить страницу «${a.name}»?${a.isHome?` Главной станет первая оставшаяся страница.`:``} Это действие сохранит новую ревизию.`,`Удалить страницу`))try{await Q(`/projects/${e}/pages/${encodeURIComponent(a.id)}`,`POST`,{version:n.version,action:i}),await vi(e)}catch(e){$(e.message,!0)}};G(`#logout`).onclick=async()=>{await Q(`/logout`,`POST`,{}),q=await Q(`/session`),mi()}}async function yi(e){let t=await Q(`/projects/${e}`);t.slug&&Qr.set(e,t.slug);let n=[[`domain`,`Домен`],[`fonts`,`Шрифты`],[`design`,`Цвета и стили`],[`seo`,`SEO`],[`analytics`,`Аналитика`],[`forms`,`Формы`],[`header-footer`,`Шапка и подвал`],[`not-found`,`Страница 404`],[`code`,`Вставка кода`],[`ai`,`AI Engine`],[`backup`,`Бэкап`]],r=new URLSearchParams(location.search).get(`section`)||`domain`,i=n.find(([e])=>e===r)||n[0],a=`<nav class="settings-nav sidebar-settings-nav" aria-label="Разделы настроек">${n.map(([t,n])=>`<a href="${$r(e)}/settings?section=${t}" class="${i[0]===t?`active`:``}" ${i[0]===t?`aria-current="page"`:``}>${n}</a>`).join(``)}</nav>`,o=wn(t.settings?.designTokens||hn),s=(e,t,n,r=e=>e)=>`<label class="settings-field">${K(t)}<select name="${e}">${n.map(t=>`<option value="${K(t)}" ${o[e]===t?`selected`:``}>${K(r(t))}</option>`).join(``)}</select></label>`,c=(e,t)=>{let[n,r,i]=Hr[e],a=Array.from({length:Math.floor((r-n)/i)+1},(e,t)=>`${n+t*i}px`);return s(e,t,a)},l=``,u=null,d=null,f=null,p=t.settings?.sharedSections||{headerComponentId:``,footerComponentId:``,pages:{}},m=(t.document?.data?.pages||[]).flatMap(e=>(e.frames?.[0]?.component?.components||[]).flatMap(t=>{let n=t?.attributes?.id;if(typeof n!=`string`||!n)return[];let r=t.name||t.attributes?.[`aria-label`]||t.type||`Секция`;return[{id:n,pageName:e.name,name:r}]}));if(i[0]===`design`)l=`<form id="design-tokens-form" class="settings-form"><p class="muted settings-form-intro">Основные цвета и скругление хранятся в настройках проекта, применяются ко всем страницам и доступны редактору и AI.</p><div class="settings-color-grid">${vn.filter(e=>e.type===`color`).map(e=>`<label>${K(e.label)}<input type="color" name="${e.name}" value="${K(o[e.name])}" aria-label="${K(e.label)}"></label>`).join(``)}</div><label class="settings-field">Скругление карточек<select name="radius">${[0,4,6,8,12,16,24,32].map(e=>`<option value="${e}px" ${o.radius===`${e}px`?`selected`:``}>${e} px</option>`).join(``)}</select></label><p class="muted small">Локальные стили элементов остаются самостоятельными. Токены сохраняются отдельной ревизией и включаются в CSS предпросмотра, ZIP-экспорта и опубликованного сайта.</p><div class="settings-form-actions"><button class="primary" type="submit">Сохранить цвета и стили</button><span id="settings-save-status" class="muted small" role="status"></span></div></form>`;else if(i[0]===`fonts`)l=`<form id="font-tokens-form" class="settings-form"><p class="muted settings-form-intro">Задайте шрифты, веса, размеры и интервалы проекта. H1–H3 адаптируются к ширине холста; значения, заданные непосредственно элементу, сохраняют приоритет.</p><div class="typography-grid">${s(`headingFontFamily`,`Шрифт заголовков`,gn,e=>e.startsWith(`Georgia`)?`Georgia`:e.startsWith(`system-ui`)?`Системный`:`Arial`)}${s(`bodyFontFamily`,`Шрифт основного текста`,gn,e=>e.startsWith(`Georgia`)?`Georgia`:e.startsWith(`system-ui`)?`Системный`:`Arial`)}${s(`headingFontWeight`,`Вес заголовков`,_n)}${s(`bodyFontWeight`,`Вес основного текста`,_n)}${c(`baseFontSize`,`Базовый размер текста`)}${c(`fontSizeH1`,`Размер H1`)}${c(`fontSizeH2`,`Размер H2`)}${c(`fontSizeH3`,`Размер H3`)}${c(`fontSizeH4`,`Размер H4`)}${c(`fontSizeH5`,`Размер H5`)}${c(`fontSizeH6`,`Размер H6`)}${s(`headingLineHeight`,`Интервал заголовков`,Br)}${s(`bodyLineHeight`,`Интервал основного текста`,Br)}${s(`letterSpacing`,`Межбуквенный интервал`,Vr)}</div><p class="muted small">Настройки сохраняются новой ревизией и используются редактором и AI-секциями. Типографические токены входят в предпросмотр, ZIP-экспорт и опубликованный сайт.</p><div class="settings-form-actions"><button class="primary" type="submit">Сохранить типографику</button><span id="settings-save-status" class="muted small" role="status"></span></div></form>`;else if(i[0]===`seo`){let e=t.document.data.pages||[],n=new URLSearchParams(location.search).get(`page`),r=e.find(e=>e.id===n)||e[0],i=t.settings?.pages?.[r?.id]?.seo||{title:``,description:``,robots:`index`,socialImage:``};l=`<label class="settings-field">Страница<select id="seo-page-select">${e.map(e=>`<option value="${K(e.id)}" ${e.id===r?.id?`selected`:``}>${K(e.name)}</option>`).join(``)}</select></label><form id="seo-settings-form" class="settings-form"><input type="hidden" name="pageId" value="${K(r?.id||``)}"><p class="muted settings-form-intro">SEO-метаданные сохраняются для каждой страницы вместе с ревизиями проекта и используются в предпросмотре, ZIP-экспорте и опубликованном сайте.</p><label class="settings-field">Заголовок страницы<input name="title" maxlength="70" value="${K(i.title||``)}" placeholder="Пустое поле использует название страницы"><span class="muted small">До 70 символов.</span></label><label class="settings-field">Описание страницы<textarea name="description" rows="4" maxlength="160" placeholder="Кратко опишите содержание страницы">${K(i.description||``)}</textarea><span class="muted small">До 160 символов.</span></label><label class="settings-field">Индексация<select name="robots"><option value="index" ${i.robots===`index`?`selected`:``}>Разрешить индексацию</option><option value="noindex" ${i.robots===`noindex`?`selected`:``}>Запретить индексацию</option></select></label><label class="settings-field">Изображение для соцсетей<input name="socialImage" type="url" value="${K(i.socialImage||``)}" maxlength="2048" pattern="https://.*" placeholder="https://example.com/preview.jpg"><span class="muted small">Необязательно. Используется HTTPS-адрес.</span></label><div class="settings-form-actions"><button class="primary" type="submit">Сохранить SEO</button><span id="seo-save-status" class="muted small" role="status"></span></div></form>`}else if(i[0]===`forms`){try{f=await Q(`/projects/${e}/form-mail`)}catch(e){f={configured:!1,host:``,port:587,security:`starttls`,username:``,hasPassword:!1,version:0,error:e.message}}let n=t.settings?.forms||{notificationsEnabled:!1,recipients:[],senderName:``,senderEmail:``,subject:`Новая заявка с сайта {{site}}`,body:`Новая заявка

{{fields}}`,autoresponderEnabled:!1,autoresponderEmailField:`email`,autoresponderSubject:`Мы получили вашу заявку`,autoresponderBody:`Здравствуйте!

Мы получили вашу заявку и свяжемся с вами.

{{site}}`};l=`<section class="form-delivery-settings"><p class="muted settings-form-intro">Заявки продолжают сохраняться отдельно в разделе «Заявки» проекта. Здесь настраивается только доставка писем с опубликованных форм.</p><form id="forms-settings-form" class="settings-form" aria-labelledby="forms-settings-title"><h3 id="forms-settings-title">Уведомления о заявках</h3><label class="settings-check"><input type="checkbox" name="notificationsEnabled" ${n.notificationsEnabled?`checked`:``}> Отправлять уведомление при новой заявке</label><label class="settings-field">Получатели · по одному email в строке<textarea name="recipients" rows="3" placeholder="owner@example.com">${K((n.recipients||[]).join(`
`))}</textarea></label><div class="typography-grid"><label class="settings-field">Имя отправителя<input name="senderName" maxlength="100" value="${K(n.senderName||``)}" placeholder="Название компании"></label><label class="settings-field">Email отправителя<input name="senderEmail" type="email" maxlength="254" value="${K(n.senderEmail||``)}" placeholder="forms@example.com"></label></div><label class="settings-field">Тема письма<input name="subject" maxlength="200" value="${K(n.subject||``)}"></label><label class="settings-field">Текст письма<textarea name="body" rows="7" maxlength="10000">${K(n.body||``)}</textarea></label><div class="settings-template-help muted small"><strong>Переменные шаблона:</strong> <code>{{site}}</code>, <code>{{form}}</code>, <code>{{page}}</code>, <code>{{date}}</code>, <code>{{fields}}</code> и поля формы, например <code>{{field:name}}</code> или <code>{{field:email}}</code>.</div><hr><h3>Автоответ посетителю</h3><label class="settings-check"><input type="checkbox" name="autoresponderEnabled" ${n.autoresponderEnabled?`checked`:``}> Отправлять автоответ на email из формы</label><label class="settings-field">Имя email-поля<input name="autoresponderEmailField" maxlength="64" value="${K(n.autoresponderEmailField||`email`)}" placeholder="email"></label><label class="settings-field">Тема автоответа<input name="autoresponderSubject" maxlength="200" value="${K(n.autoresponderSubject||``)}"></label><label class="settings-field">Текст автоответа<textarea name="autoresponderBody" rows="5" maxlength="10000">${K(n.autoresponderBody||``)}</textarea></label><div class="settings-form-actions"><button class="primary" type="submit">Сохранить настройки писем</button><span id="forms-settings-status" class="muted small" role="status">${K(f.error||``)}</span></div></form><form id="smtp-settings-form" class="settings-form" aria-labelledby="smtp-settings-title"><h3 id="smtp-settings-title">Почтовый сервер SMTP</h3><p class="muted small">Пароль шифруется отдельным закрытым ключом на сервере и не попадает в настройки проекта или историю ревизий. TLS и SSL проверяют сертификат сервера.</p><div class="typography-grid"><label class="settings-field">SMTP host<input name="host" required maxlength="253" value="${K(f.host||``)}" placeholder="smtp.example.com"></label><label class="settings-field">Порт<input name="port" type="number" min="1" max="65535" required value="${K(f.port||587)}"></label></div><div class="typography-grid"><label class="settings-field">Защита соединения<select name="security"><option value="starttls" ${f.security===`starttls`?`selected`:``}>STARTTLS</option><option value="ssl" ${f.security===`ssl`?`selected`:``}>SSL/TLS</option><option value="none" ${f.security===`none`?`selected`:``}>Без шифрования</option></select></label><label class="settings-field">Логин<input name="username" autocomplete="username" value="${K(f.username||``)}"></label></div><label class="settings-field">Пароль SMTP<input name="password" type="password" autocomplete="new-password" maxlength="1024" placeholder="${f.hasPassword?`Сохранён · пустое поле оставит его без изменений`:`Пароль SMTP`}"></label><div class="settings-form-actions"><button class="primary" type="submit">Сохранить SMTP</button><button id="smtp-test" class="secondary-link" type="button" ${f.configured?``:`disabled`}>Отправить тестовое письмо</button><span id="smtp-settings-status" class="muted small" role="status">${K(f.error||`SMTP · версия ${f.version}`)}</span></div><label class="settings-field">Email для теста<input id="smtp-test-to" type="email" required maxlength="254" placeholder="you@example.com"></label></form></section>`}else if(i[0]===`ai`){try{u=await Q(`/projects/`+e+`/ai/settings`)}catch(e){u={configured:!1,model:null,activeProfileId:null,profiles:[],version:0,error:e.message}}try{d=await Q(`/projects/${e}/ai/skills`)}catch(e){d={version:0,activeSkillId:null,skills:[],limit:10,error:e.message}}let n=u.activeProfileId||u.profiles[0]?.id||``,r=u.profiles.find(e=>e.id===n),i=u.profiles.map(e=>`<button type="button" data-ai-profile-id="`+K(e.id)+`" class="ai-profile-card`+(e.id===n?` selected`:``)+`" aria-pressed="`+(e.id===n?`true`:`false`)+`"><span><strong>`+K(e.name)+`</strong><small>`+K(e.model)+(e.fallbackModel?` · запасная: `+K(e.fallbackModel):``)+`</small></span><span class="status-pill">`+(e.active?`Активен`:`Редактировать`)+`</span></button>`).join(``);l=`<section class="ai-engine-settings"><div class="settings-notice"><span class="settings-notice-icon">✳</span><div><strong id="ai-settings-heading">`+(u.configured?`Активный профиль: `+K(u.profiles.find(e=>e.id===u.activeProfileId)?.name||`OpenRouter`):`Добавьте профиль OpenRouter`)+`</strong><p id="ai-settings-intro">`+(u.configured?`AI-запросы начинают с выбранного профиля и модели «`+K(u.model||``)+`»`+(u.fallbackModel?` · запасная модель «`+K(u.fallbackModel)+`».`:`.`):`Сохраните несколько профилей с разными API-ключами и моделями. Один профиль будет активным для AI-запросов.`)+`</p></div></div><p class="muted small ai-profile-security">При таймауте, лимите, временном сбое, отказе ключа или модели запрос автоматически перейдёт к другим сохранённым профилям. Активный профиль не изменится. Каждая попытка может расходовать токены. «Проверить профиль» отправляет только короткий служебный запрос в сохранённую основную модель (до 256 токенов, 20 секунд), без fallback и без изменения настроек. Ключи шифруются на сервере и не возвращаются в браузер. Чтобы заменить ключ профиля, введите новый; пустое поле сохранит прежний.</p><p class="muted small ai-profile-security"><strong>О модели openrouter/free:</strong> это динамический маршрутизатор, который выбирает бесплатную модель случайным образом. Между запросами могут меняться фактическая модель, задержка и формат ответа. Для более воспроизводимой генерации укажите конкретные ID основной и резервной моделей.</p><div class="ai-profile-manager"><div class="ai-profile-list-column"><div class="ai-profile-list-heading"><h3>Профили OpenRouter</h3><button id="ai-profile-add" class="secondary-link" type="button">+ Новый профиль</button></div><div id="ai-profile-list" class="ai-profile-list">`+(i||`<p class="muted small">Профилей пока нет. Создайте первый профиль справа.</p>`)+`</div></div><form id="ai-settings-form" class="settings-form ai-profile-form"><input type="hidden" name="profileId" value="`+K(r?.id||``)+`"><label class="settings-field">Название профиля<input name="profileName" required maxlength="64" value="`+K(r?.name||``)+`" placeholder="Например, Основной"></label><label class="settings-field">API-ключ OpenRouter<input type="password" name="apiKey" autocomplete="off" maxlength="512" placeholder="`+(r?`Ключ сохранён · пустое поле оставит его без изменений`:`sk-or-v1-…`)+`" spellcheck="false" `+(r?``:`required`)+`></label><label class="settings-field">ID основной модели<input type="text" name="model" required maxlength="128" value="`+K(r?.model||``)+`" placeholder="provider/model-slug" autocomplete="off" spellcheck="false"></label><label class="settings-field">ID резервной модели · необязательно<input type="text" name="fallbackModel" maxlength="128" value="`+K(r?.fallbackModel||``)+`" placeholder="provider/fallback-model" autocomplete="off" spellcheck="false"></label><p class="muted small">При временной ошибке или лимите основной модели запрос повторится через резервную. OpenRouter может начислить стоимость за каждый запрос. Пустое поле отключает резервную модель.</p><p class="muted small">Ключ передаётся серверу вашего проекта (на production — по HTTPS), шифруется и не попадает в Project Data или историю ревизий.</p><div class="settings-form-actions"><button id="ai-profile-save" class="primary" type="submit">`+(r?`Сохранить изменения`:`Создать профиль`)+`</button><button id="ai-profile-activate" class="secondary-link" type="button" `+(!r||r.active?`hidden`:``)+`>Использовать для AI</button><button id="ai-profile-test" class="secondary-link" type="button">Проверить профиль</button><button id="ai-profile-delete" class="secondary-link danger-action" type="button" `+(r?``:`hidden`)+`>Удалить профиль</button><span id="ai-settings-status" class="muted small" role="status">`+K(u.error||`Профили AI · версия `+u.version)+`</span></div></form></div><a class="secondary-link ai-editor-link" href="/projects/`+e+`/pages/`+encodeURIComponent(t.document.data.pages[0].id)+`/edit">Перейти к редактору AI-плана</a></section>`,l+=`<section class="ai-skill-library" aria-labelledby="ai-skills-title"><div class="section-title-row"><div><h3 id="ai-skills-title">Пользовательские Skills</h3><p class="muted">До ${d.limit} Markdown-файлов или вставленных инструкций на проект.</p></div><span id="ai-skills-version" class="version-label">Библиотека · версия ${d.version}</span></div><p class="muted small ai-skill-disclosure">Текст хранится только в проекте. Он отправится в OpenRouter после нажатия «Разобрать Skill с AI» либо при генерации дизайна с выбранным Skill. Skill не исполняет команды и не гарантирует безошибочное выполнение: перед импортом вы вручную отметите его пункты проверки.</p><details class="ai-skill-rules-help"><summary>Автоматические правила Skill</summary><p class="muted small">Добавьте этот блок в текст Skill. Сервер проверит правила и выполнит одну исправляющую попытку при нарушении. Остальные требования остаются ручными.</p><pre>\`\`\`juzimder-rules
{"schemaVersion":1,"requirements":[
  {"id":"single-title","label":"Один H1","type":"heading_count","tag":"h1","count":1},
  {"id":"responsive","label":"Адаптивное CSS-правило","type":"responsive_css"}
]}
\`\`\`</pre><p class="muted small">Также доступны section_count (min/max от 3 до 9), text_present и text_absent (text до 200 символов). До 20 правил; каждый id уникален. Текст проверяется в DOM, адаптация — по наличию CSS-правила.</p></details><div class="ai-skill-manager"><div class="ai-profile-list-column"><div class="ai-profile-list-heading"><h4>Сохранённые Skills</h4><button id="ai-skill-add" class="secondary-link" type="button">+ Добавить Skill</button></div><div id="ai-skill-list" class="ai-profile-list"></div></div><form id="ai-skill-form" class="settings-form ai-skill-form"><input type="hidden" name="skillId" value=""><label class="settings-field">Название<input name="skillName" required maxlength="64" placeholder="Например, фирменный стиль"></label><label class="settings-field">Загрузить Markdown-файл<input id="ai-skill-file" type="file" accept=".md,.markdown,text/markdown,text/plain"></label><label class="settings-field">Текст Skill<textarea name="content" rows="12" maxlength="16000" required placeholder="# Название Skill&#10;&#10;Опишите правила и ограничения дизайна"></textarea><small class="muted">UTF-8 · максимум 16 000 символов</small></label><label class="settings-field">Пункты ручной проверки<textarea name="manualChecks" rows="4" maxlength="3000" required placeholder="Проверь адаптивность на телефоне&#10;Убедись, что CTA заметна"></textarea><small class="muted">По одному пункту в строке · от 1 до 12 пунктов</small></label><p class="muted small">«Разобрать Skill» отправит текущий текст (до 15 000 символов) в OpenRouter через активный профиль. При нарушении формата или цитат возможна одна исправляющая попытка с дополнительным расходом токенов. Ответ — черновик: проверьте полноту и точность извлечённых требований.</p><button id="ai-skill-analyze" type="button">Разобрать Skill с AI</button><section id="ai-skill-analysis" hidden aria-label="Черновик требований Skill"></section><div class="settings-form-actions"><button id="ai-skill-save" class="primary" type="submit">Сохранить Skill</button><button id="ai-skill-activate" class="secondary-link" type="button" hidden>Использовать в редакторе</button><button id="ai-skill-delete" class="secondary-link danger-action" type="button" hidden>Удалить Skill</button><span id="ai-skill-status" class="muted small" role="status">${K(d.error||`Библиотека Skills · версия ${d.version}`)}</span></div></form></div></section>`}else if(i[0]===`backup`)l=`<section class="settings-backup"><p class="muted settings-form-intro">Переносимый файл содержит страницы, настройки проекта, AI Skills и медиатеку. API-ключи AI защищены выбранной пароль-фразой и будут зашифрованы ключом целевого сервера после импорта.</p><div class="settings-notice"><div class="settings-notice-icon" aria-hidden="true">↧</div><div><strong>Скачать переносимый бэкап</strong><p>Сохраните файл и пароль-фразу раздельно. Используйте ту же фразу на целевом сервере. Потерянную фразу восстановить нельзя.</p><button id="backup-download" class="primary" type="button">Скачать бэкап</button></div></div><div class="settings-notice settings-backup-restore"><div class="settings-notice-icon" aria-hidden="true">↥</div><div><strong>Восстановить из файла</strong><p>Этот раздел восстанавливает бэкап в текущий проект. Для переноса на другой сервер используйте «Восстановить из бэкапа» на главной странице.</p><label class="settings-field">Файл бэкапа<input id="backup-file" type="file" accept="application/json,.json"></label><label id="backup-passphrase-wrap" class="settings-field" hidden>Пароль-фраза из бэкапа<input id="backup-passphrase" type="password" autocomplete="current-password" minlength="16" maxlength="1024"></label><button id="backup-restore" type="button" disabled>Восстановить проект</button></div></div><p class="muted small">Бэкапы версии 1 и 2 остаются совместимы на исходной установке. Ключи в этих старых файлах нельзя расшифровать на другом сервере. Переносимый бэкап версии 3 шифрует их пароль-фразой длиной не менее 16 символов с Argon2id и XChaCha20-Poly1305; при импорте Juzimder повторно шифрует их закрытым ключом целевого сервера. Пароль SMTP не экспортируется. Заявки, история ревизий и опубликованный снимок остаются на сервере.</p><p id="backup-status" class="muted small" role="status" aria-live="polite"></p></section>`;else if(i[0]===`code`)l=`<form id="custom-css-form" class="settings-form"><p class="muted settings-form-intro">Дополнительный CSS применяется только к страницам опубликованного сайта и ZIP-экспорта. Он не загружается в редактор и не меняет его интерфейс. JavaScript и произвольный HTML здесь не исполняются.</p><label class="settings-field">CSS сайта<textarea name="customCss" id="custom-css-input" rows="16" maxlength="12000" spellcheck="false" placeholder=".hero { background-color: #222629; color: white; }&#10;.card { box-sizing: border-box; min-height: 240px; }&#10;img { object-fit: cover; }&#10;.cta:hover { background-color: #61892f; }&#10;.field:focus-visible { outline: 2px solid #86c232; }">${K(t.settings?.customCss||``)}</textarea><span class="muted small">До 12 000 символов и 100 правил. Классы/теги, типографика, размеры, flex/grid, изображения, состояния hover/focus-visible/active и min-width/max-width 320–2560 px. Без URL, скриптов, вложенных @-правил и позиционирования.</span></label><div class="settings-form-actions"><button class="primary" type="submit">Сохранить CSS</button><button id="custom-css-preview" type="button">Предпросмотр</button><span id="custom-css-status" class="muted small" role="status"></span></div><iframe id="custom-css-preview-frame" sandbox="" title="Изолированный предпросмотр опубликованной страницы" hidden></iframe></form>`;else if(i[0]===`header-footer`){let e=e=>`<option value="">Не выбрано</option>${m.map(t=>`<option value="${K(t.id)}" ${e===t.id?`selected`:``}>${K(t.pageName)} · ${K(t.name)}</option>`).join(``)}`,n=p.pages||{};l=`<form id="shared-sections-form" class="settings-form"><p class="muted settings-form-intro">Выберите верхнеуровневые секции из страниц проекта. Они будут переиспользованы как общие шапка и подвал на публикации, в preview и ZIP. Выбранные исходные секции не будут дублироваться в содержимом своей страницы.</p><label class="settings-field">Секция шапки<select name="headerComponentId">${e(p.headerComponentId||``)}</select></label><label class="settings-field">Секция подвала<select name="footerComponentId">${e(p.footerComponentId||``)}</select></label><fieldset class="shared-page-list"><legend>Показывать на страницах</legend>${(t.document?.data?.pages||[]).map(e=>{let t=n[e.id]||{header:!0,footer:!0};return`<div class="shared-page-row"><strong>${K(e.name)}</strong><label><input type="checkbox" name="header:${K(e.id)}" ${t.header===!1?``:`checked`}> Шапка</label><label><input type="checkbox" name="footer:${K(e.id)}" ${t.footer===!1?``:`checked`}> Подвал</label></div>`}).join(``)}</fieldset><p class="muted small">Чтобы назначить секцию, добавьте её как отдельный верхнеуровневый блок на любой странице. Идентификатор секции проверяется сервером. Изменения самой исходной секции остаются редактируемыми в основном редакторе.</p><div class="settings-form-actions"><button class="primary" type="submit">Сохранить шапку и подвал</button><span id="shared-sections-status" class="muted small" role="status"></span></div></form>`}else if(i[0]===`not-found`){let e=t.settings?.notFound||{title:`404`,message:`Страница не найдена или была перемещена.`,homeLabel:`Вернуться на главную`};l=`<form id="not-found-form" class="settings-form"><p class="muted settings-form-intro">Настройте текст системной страницы 404. Она будет включаться в следующую публикацию и ZIP-экспорт; неизвестные адреса сохраняют настоящий HTTP-статус 404.</p><label class="settings-field">Заголовок страницы<input name="title" required maxlength="100" value="${K(e.title||``)}" placeholder="Например: Страница не найдена"></label><label class="settings-field">Описание<textarea name="message" required maxlength="400" rows="4">${K(e.message||``)}</textarea></label><label class="settings-field">Текст кнопки на главную<input name="homeLabel" required maxlength="80" value="${K(e.homeLabel||``)}" placeholder="Вернуться на главную"></label><fieldset class="not-found-colors"><legend>Оформление</legend><p class="muted small">По умолчанию используются цвета проекта. Снимите флажок, чтобы задать отдельный цвет.</p>${[[`backgroundColor`,`Фон`,`canvas`],[`textColor`,`Текст`,`ink`],[`buttonColor`,`Кнопка`,`accent`],[`buttonTextColor`,`Текст кнопки`,`ink`]].map(([n,r,i])=>`<div class="not-found-color-row"><label>${r}<input type="color" name="${n}" aria-label="${r}" value="${K(e[n]||t.settings.designTokens[i])}"></label><label class="not-found-inherit"><input type="checkbox" name="inherit_${n}" ${e[n]?``:`checked`}> Цвет проекта</label></div>`).join(``)}</fieldset><div class="settings-form-actions"><button class="primary" type="submit">Сохранить страницу 404</button><span id="not-found-status" class="muted small" role="status"></span></div></form>`}else l=`<div class="settings-notice settings-planned"><span class="settings-notice-icon">◷</span><div><strong>${i[0]===`domain`?`Подключение домена пока недоступно`:`Раздел пока не подключён`}</strong><p>${i[0]===`domain`?`Публичная публикация, DNS-проверка, маршрутизация и выпуск SSL ещё не реализованы. Сайт не будет показан как подключённый без проверки.`:`Для этого раздела пока нет сохранения и backend-интеграции. Форма появится вместе с рабочей серверной поддержкой.`}</p><span class="status-pill">Не реализовано</span></div></div>`;if(Fr.innerHTML=`<div class="dashboard project-dashboard settings-dashboard"><aside class="dash-sidebar"><a class="brand" href="/">${Lr} Juzimder <span>AI</span></a><div class="workspace-label">ПРОЕКТ</div><div class="project-sidebar-title">${K(t.name)}</div><a class="project-side-link" href="${$r(e)}">▦ <span>Страницы</span></a><a class="nav-active" href="${$r(e)}/settings">⚙ <span>Настройки сайта</span></a>${a}<div class="sidebar-note"><span class="status-dot"></span> FOUNDATION<div class="version-label">Версия продукта <strong>${Ir}</strong></div></div><a class="text-button" href="/">← Все проекты</a><button id="logout" class="text-button">Выйти из аккаунта ↗</button></aside><main class="dash-main settings-main"><header class="dash-top"><span><a href="/">Мои проекты</a><span class="slash">/</span><a href="${$r(e)}">${K(t.name)}</a><span class="slash">/</span>Настройки сайта</span><span class="version-label">Версия ${Ir}</span></header><section class="project-intro"><p class="eyebrow">НАСТРОЙКИ ПРОЕКТА</p><h1>Настройки сайта<span class="accent">.</span></h1><p class="muted">Общие параметры проекта и подключённые возможности.</p></section><div class="settings-layout"><section class="settings-content"><div class="section-title-row"><div><p class="eyebrow">${K(i[1].toUpperCase())}</p><h2>${K(i[1])}</h2></div><span id="settings-revision" class="version-label">Проект · ревизия ${t.version}</span></div>${l}</section></div><footer class="dash-footer"><span>YOUR IDEAS, TAKING SHAPE.</span><span>GrapesJS Core · PHP · SQLite</span></footer></main></div><dialog id="confirm-dialog"><form method="dialog"><p id="confirm-message"></p><div class="dialog-actions"><button value="cancel">Отмена</button><button id="confirm-submit" class="primary" value="confirm">Продолжить</button></div></form></dialog>`,i[0]===`backup`){let n=G(`#backup-file`),r=G(`#backup-restore`),i=G(`#backup-status`),a=G(`#backup-passphrase-wrap`),o=G(`#backup-passphrase`),s=null;n.onchange=async()=>{s=null,r.disabled=!0,a.hidden=!0,o.required=!1,o.value=``;let t=n.files?.[0];if(!t)i.textContent=``;else try{if(t.size>33554432)throw Error(`Файл превышает допустимый размер 32 МБ.`);if(s=JSON.parse(await t.text()),s.format!==`juzimder-project-backup`||![1,2,3].includes(s.backupVersion)||s.sourceProjectId!==e)throw Error(`Выберите резервную копию именно этого проекта.`);s.backupVersion===3&&(a.hidden=!1,o.required=!0),r.disabled=!1;let n=s.backupVersion===1?`AI-профили не сохранены в старом формате`:s.backupVersion===3?`переносимые AI-профили`:(s.project?.aiProfiles?.profiles?.length||0)+` AI-профилей старого формата`;i.textContent=`Файл проверен · ${s.project?.document?.data?.pages?.length||0} страниц · ${s.project?.assets?.length||0} изображений · ${n}.`}catch(e){s=null,i.textContent=e.message}},G(`#backup-download`).onclick=async()=>{let n=await ni(`export`);if(n===null)return;let r=G(`#backup-download`);r.disabled=!0,i.textContent=`Формируем защищённую переносимую резервную копию…`;try{await ri(e,n),i.textContent=`Бэкап скачан · ревизия ${t.version}. Пароль-фразу сохраните отдельно.`}catch(e){i.textContent=e.message}finally{r.disabled=!1}},r.onclick=async()=>{if(!s)return;let a=s.backupVersion===3?o.value:null;if(s.backupVersion===3&&a.length<16)i.textContent=`Введите пароль-фразу длиной не менее 16 символов.`,o.focus();else if(await ii(`Восстановление заменит страницы, настройки проекта, медиатеку и Skills данными файла.`+(s.backupVersion===1?` AI-профили отсутствуют в старом файле и останутся без изменений.`:` Будут восстановлены профили AI.`)+` Будет создана новая ревизия. Продолжить?`,`Восстановить проект`)){r.disabled=!0,i.textContent=`Проверяем файл и восстанавливаем проект…`;try{t=await Q(`/projects/${e}/backup`,`POST`,{version:t.version,backup:s,...a===null?{}:{portablePassphrase:a}}),t.slug&&Qr.set(e,t.slug),G(`#settings-revision`).textContent=`Проект · ревизия ${t.version}`,history.replaceState(null,``,`${$r(e)}/settings?section=backup`),s=null,n.value=``,o.value=``,r.disabled=!0,i.textContent=`Проект восстановлен · новая ревизия ${t.version}`}catch(e){i.textContent=e.message}finally{r.disabled=!s}}}}let h=G(`#design-tokens-form`)||G(`#font-tokens-form`);h&&(h.onsubmit=async n=>{n.preventDefault();let r=h.querySelector(`[type="submit"]`),i=G(`#settings-save-status`);r.disabled=!0,i.textContent=`Сохранение…`;try{let n=wn({...t.settings.designTokens,...Object.fromEntries(new FormData(h))});t=await Q(`/projects/${e}/settings`,`PUT`,{version:t.version,designTokens:n}),G(`#settings-revision`).textContent=`Проект · ревизия ${t.version}`,i.textContent=`Сохранено · ревизия ${t.version}`}catch(e){i.textContent=e.message}finally{r.disabled=!1}});let g=G(`#seo-page-select`);g&&(g.onchange=()=>{let e=new URL(location.href);e.searchParams.set(`section`,`seo`),e.searchParams.set(`page`,g.value),location.assign(e)});let _=G(`#seo-settings-form`);_&&(_.onsubmit=async n=>{n.preventDefault();let r=_.querySelector(`[type="submit"]`),i=G(`#seo-save-status`);r.disabled=!0,i.textContent=`Сохранение SEO…`;try{let n=Object.fromEntries(new FormData(_)),r=n.pageId;delete n.pageId,t=await Q(`/projects/${e}/settings`,`PUT`,{version:t.version,seo:{pageId:r,...n}}),G(`#settings-revision`).textContent=`Проект · ревизия ${t.version}`,i.textContent=`SEO сохранено · ревизия ${t.version}`}catch(e){i.textContent=e.message}finally{r.disabled=!1}});let v=G(`#shared-sections-form`);v&&(v.onsubmit=async n=>{n.preventDefault();let r=v.querySelector(`[type="submit"]`),i=G(`#shared-sections-status`);r.disabled=!0,i.textContent=`Сохраняем общие секции…`;try{let n=Object.fromEntries(new FormData(v)),r={};for(let e of t.document.data.pages||[])r[e.id]={header:v.querySelector(`[name="header:${CSS.escape(e.id)}"]`).checked,footer:v.querySelector(`[name="footer:${CSS.escape(e.id)}"]`).checked};t=await Q(`/projects/${e}/settings`,`PUT`,{version:t.version,sharedSections:{headerComponentId:n.headerComponentId,footerComponentId:n.footerComponentId,pages:r}}),G(`#settings-revision`).textContent=`Проект · ревизия ${t.version}`,i.textContent=`Настройки сохранены · ревизия ${t.version}`}catch(e){i.textContent=e.message}finally{r.disabled=!1}});let y=G(`#not-found-form`);if(y&&(y.onsubmit=async n=>{n.preventDefault();let r=y.querySelector(`[type="submit"]`),i=G(`#not-found-status`);r.disabled=!0,i.textContent=`Проверяем и сохраняем страницу 404…`;try{let n=Object.fromEntries(new FormData(y));for(let e of[`backgroundColor`,`textColor`,`buttonColor`,`buttonTextColor`])n[`inherit_${e}`]&&(n[e]=``),delete n[`inherit_${e}`];t=await Q(`/projects/${e}/settings`,`PUT`,{version:t.version,notFound:n}),G(`#settings-revision`).textContent=`Проект · ревизия ${t.version}`,i.textContent=`Страница 404 сохранена · ревизия ${t.version}`}catch(e){i.textContent=e.message}finally{r.disabled=!1}}),i[0]===`code`){let n=G(`#custom-css-form`),r=G(`#custom-css-input`),i=G(`#custom-css-status`),a=G(`#custom-css-preview`),o=G(`#custom-css-preview-frame`),s=()=>{a.disabled=r.value!==(t.settings?.customCss||``)};r.addEventListener(`input`,s),n.onsubmit=async a=>{a.preventDefault();let o=n.querySelector(`[type="submit"]`);o.disabled=!0,i.textContent=`Проверяем и сохраняем CSS…`;try{t=await Q(`/projects/${e}/settings`,`PUT`,{version:t.version,customCss:r.value}),r.value=t.settings.customCss||``,G(`#settings-revision`).textContent=`Проект · ревизия ${t.version}`,i.textContent=`CSS сохранён · ревизия ${t.version}`,s()}catch(e){i.textContent=e.message}finally{o.disabled=!1}},a.onclick=async()=>{if(r.value!==(t.settings?.customCss||``))i.textContent=`Сначала сохраните изменения CSS.`;else{a.disabled=!0,i.textContent=`Загружаем сохранённую страницу…`;try{let t=await Q(`/projects/${e}/preview/static`),n=t.pages?.[0];if(!n)throw Error(`В проекте нет страницы для предпросмотра.`);let r=new DOMParser().parseFromString(n.html,`text/html`),a=r.querySelector(`link[rel="stylesheet"]`);if(a){let e=r.createElement(`style`);e.textContent=t.css,a.replaceWith(e)}o.srcdoc=`<!doctype html>`+r.documentElement.outerHTML,o.hidden=!1,i.textContent=`Изолированный предпросмотр сохранённой ревизии ${t.version}.`}catch(e){i.textContent=e.message}finally{a.disabled=!1}}},s()}if(i[0]===`forms`){let n=G(`#forms-settings-form`),r=G(`#smtp-settings-form`),i=G(`#forms-settings-status`),a=G(`#smtp-settings-status`);n.onsubmit=async r=>{r.preventDefault();let a=n.querySelector(`[type="submit"]`);a.disabled=!0,i.textContent=`Сохраняем настройки писем…`;try{let r=Object.fromEntries(new FormData(n));r.notificationsEnabled=n.elements.notificationsEnabled.checked,r.autoresponderEnabled=n.elements.autoresponderEnabled.checked,r.recipients=r.recipients.split(/[\r\n,;]+/).map(e=>e.trim()).filter(Boolean),t=await Q(`/projects/${e}/settings`,`PUT`,{version:t.version,forms:r}),G(`#settings-revision`).textContent=`Проект · ревизия ${t.version}`,i.textContent=`Настройки писем сохранены · ревизия ${t.version}`}catch(e){i.textContent=e.message}finally{a.disabled=!1}},r.onsubmit=async t=>{t.preventDefault();let n=r.querySelector(`[type="submit"]`);n.disabled=!0,a.textContent=`Сохраняем SMTP…`;try{let t=Object.fromEntries(new FormData(r));t.port=Number(t.port),f=await Q(`/projects/${e}/form-mail`,`PUT`,{version:f.version,...t}),r.elements.password.value=``,r.elements.password.placeholder=`Сохранён · пустое поле оставит его без изменений`,G(`#smtp-test`).disabled=!1,a.textContent=`SMTP сохранён · версия ${f.version}`}catch(e){a.textContent=e.message}finally{n.disabled=!1}},G(`#smtp-test`).onclick=async()=>{let t=G(`#smtp-test`),n=G(`#smtp-test-to`).value.trim();if(!n||!G(`#smtp-test-to`).checkValidity())G(`#smtp-test-to`).reportValidity();else{t.disabled=!0,a.textContent=`Отправляем тестовое письмо…`;try{await Q(`/projects/${e}/form-mail/test`,`POST`,{version:f.version,to:n}),a.textContent=`Тестовое письмо отправлено на ${n}.`}catch(e){a.textContent=e.message}finally{t.disabled=!1}}}}let b=G(`#ai-settings-form`);if(b){let t=b.elements.apiKey,n=b.elements.profileName,r=b.elements.model,i=b.elements.fallbackModel,a=G(`#ai-profile-save`),o=G(`#ai-settings-status`),s=G(`#ai-profile-list`),c=G(`#ai-profile-activate`),l=G(`#ai-profile-delete`),f=u.activeProfileId||u.profiles[0]?.id||``,p=()=>u.profiles.find(e=>e.id===f)||null,m=()=>{let e=p();s.innerHTML=u.profiles.map(e=>`<button type="button" data-ai-profile-id="`+K(e.id)+`" class="ai-profile-card`+(e.id===f?` selected`:``)+`" aria-pressed="`+(e.id===f?`true`:`false`)+`"><span><strong>`+K(e.name)+`</strong><small>`+K(e.model)+(e.fallbackModel?` · запасная: `+K(e.fallbackModel):``)+`</small></span><span class="status-pill">`+(e.active?`Активен`:`Редактировать`)+`</span></button>`).join(``)||`<p class="muted small">Профилей пока нет. Создайте первый профиль справа.</p>`,n.value=e?.name||``,r.value=e?.model||``,i.value=e?.fallbackModel||``,t.value=``,t.required=!e,t.placeholder=e?`Ключ сохранён · пустое поле оставит его без изменений`:`sk-or-v1-…`,a.textContent=e?`Сохранить изменения`:`Создать профиль`,c.hidden=!e||e.active,l.hidden=!e,G(`#ai-profile-test`).disabled=!e,G(`#ai-settings-heading`).textContent=u.configured?`Активный профиль: `+(u.profiles.find(e=>e.id===u.activeProfileId)?.name||`OpenRouter`):`Добавьте профиль OpenRouter`,G(`#ai-settings-intro`).textContent=u.configured?`AI-запросы начинают с выбранного профиля и модели «`+u.model+`»`+(u.fallbackModel?` · запасная модель «`+u.fallbackModel+`».`:`.`):`Сохраните несколько профилей с разными API-ключами и моделями. Один профиль будет активным для AI-запросов.`,o.textContent=`Профили AI · версия `+u.version};s.onclick=e=>{let t=e.target.closest(`[data-ai-profile-id]`);t&&(f=t.dataset.aiProfileId,m())},G(`#ai-profile-add`).onclick=()=>{f=``,m(),n.focus()},b.onsubmit=async s=>{s.preventDefault(),a.disabled=!0,o.textContent=`Сохраняем профиль…`;let c=p(),l=c?`PUT`:`POST`,d=c?`/ai/profiles/`+encodeURIComponent(c.id):`/ai/profiles`;try{u=await Q(`/projects/`+e+d,l,{version:u.version,name:n.value,apiKey:t.value,model:r.value,fallbackModel:i.value}),c||(f=u.activeProfileId),m(),o.textContent=`Профиль сохранён · версия `+u.version}catch(e){o.textContent=e.message}finally{a.disabled=!1}},G(`#ai-profile-test`).onclick=async()=>{let a=p();if(!a)return;if(n.value!==a.name||r.value!==a.model||i.value!==(a.fallbackModel||``)||t.value){o.textContent=`Сначала сохраните изменения профиля.`;return}let s=G(`#ai-profile-test`);s.disabled=!0,o.textContent=`Проверяем «`+a.name+`»…`;try{let t=await Q(`/projects/`+e+`/ai/profiles/`+encodeURIComponent(a.id)+`/test`,`POST`,{version:u.version});f===a.id&&(o.textContent=`«`+a.name+`»: подключение работает · `+t.resolvedModel+` · `+(t.elapsedMs/1e3).toFixed(1)+` с. Это проверка короткого ответа, не полной генерации.`)}catch(e){f===a.id&&(o.textContent=`«`+a.name+`»: `+e.message)}finally{s.disabled=!p()}},c.onclick=async()=>{let t=p();if(t){c.disabled=!0,o.textContent=`Выбираем профиль…`;try{u=await Q(`/projects/`+e+`/ai/profiles/`+encodeURIComponent(t.id)+`/activate`,`POST`,{version:u.version}),m(),o.textContent=`Активный профиль обновлён · версия `+u.version}catch(e){o.textContent=e.message}finally{c.disabled=!1}}},l.onclick=async()=>{let t=p();if(t&&await ii(`Удалить профиль «`+t.name+`»? Его API-ключ будет удалён.`,`Удалить профиль`)){l.disabled=!0,o.textContent=`Удаляем профиль…`;try{u=await Q(`/projects/`+e+`/ai/profiles/`+encodeURIComponent(t.id),`DELETE`,{version:u.version}),f=u.activeProfileId||u.profiles[0]?.id||``,m(),o.textContent=`Профиль удалён · версия `+u.version}catch(e){o.textContent=e.message}finally{l.disabled=!1}}},m();let h=G(`#ai-skill-form`),g=G(`#ai-skill-list`),_=G(`#ai-skill-status`),v=h.elements.skillId,y=h.elements.skillName,x=h.elements.content,S=h.elements.manualChecks,C=G(`#ai-skill-save`),w=G(`#ai-skill-activate`),T=G(`#ai-skill-delete`),E=()=>d.skills.find(e=>e.id===v.value)||null,D=()=>{g.innerHTML=d.skills.map(e=>`<button type="button" data-ai-skill-id="${K(e.id)}" class="ai-profile-card${e.id===v.value?` selected`:``}" aria-pressed="${e.id===v.value}"><span><strong>${K(e.name)}</strong><small>${e.characterCount.toLocaleString(`ru-RU`)} символов · ${e.manualChecks.length} пунктов проверки</small></span><span class="status-pill">${e.active?`Активен`:`Редактировать`}</span></button>`).join(``)||`<p class="muted small">Skills ещё не добавлены. Загрузите Markdown или вставьте текст справа.</p>`;let e=E();w.hidden=!e||e.active,T.hidden=!e,G(`#ai-skills-version`).textContent=`Библиотека · версия ${d.version}`},ee=()=>{ne(),h.reset(),v.value=``,w.hidden=!0,T.hidden=!0,C.textContent=`Сохранить Skill`,D()};g.onclick=async t=>{let n=t.target.closest(`[data-ai-skill-id]`);if(n){ne(),_.textContent=`Загружаем Skill…`;try{let t=await Q(`/projects/${e}/ai/skills/${encodeURIComponent(n.dataset.aiSkillId)}`);v.value=t.id,y.value=t.name,x.value=t.content,S.value=t.manualChecks.join(`
`),C.textContent=`Сохранить изменения`,D(),_.textContent=`Skill загружен · библиотека версии ${d.version}`}catch(e){_.textContent=e.message}}},G(`#ai-skill-add`).onclick=()=>{ee(),y.focus()},G(`#ai-skill-file`).onchange=async e=>{let t=e.target.files?.[0];if(t){ne();try{if(t.size>65536)throw Error(`Размер файла превышает 64 КБ.`);let e=await t.text();if([...e].length>16e3)throw Error(`Файл длиннее 16 000 символов.`);x.value=e,y.value.trim()||(y.value=t.name.replace(/\.(?:md|markdown|txt)$/i,``)),_.textContent=`Файл «${t.name}» прочитан. Нажмите «Сохранить Skill», чтобы добавить его в проект.`}catch(t){_.textContent=t.message,e.target.value=``}}};let te=null,O=G(`#ai-skill-analysis`),ne=()=>{te=null,O.replaceChildren(),O.hidden=!0};x.addEventListener(`input`,ne),S.addEventListener(`input`,ne),G(`#ai-skill-analyze`).onclick=async()=>{let t=G(`#ai-skill-analyze`),n=x.value,r=v.value,i=S.value;t.disabled=!0,ne(),_.textContent=`Разбираем требования Skill через OpenRouter…`;try{let t=await Q(`/projects/${e}/ai/skills/analyze`,`POST`,{version:d.version,content:n});if(x.value!==n||v.value!==r||S.value!==i)throw Error(`Форма изменилась во время разбора. Повторите запрос для текущего текста.`);te={draft:t,source:n,sourceSkillId:r,sourceChecks:i};let a=document.createElement(`h4`);a.textContent=`Проверьте извлечённые требования`,O.append(a);let o=document.createElement(`p`);o.className=`muted small`,o.textContent=`AI мог пропустить или неверно истолковать требования. Сверьте каждую цитату и полноту списка с исходным Skill. Автоматические правила измеряют только объявленные свойства HTML/CSS.`,O.append(o);for(let e of t.items){let t=document.createElement(`article`),n=document.createElement(`strong`),r=document.createElement(`blockquote`);if(n.textContent=`${e.id} · ${e.label} · ${e.mode===`automatic`?`автоматически`:`вручную`}`,r.textContent=e.sourceQuote,t.append(n,r),e.mode===`automatic`){let n=document.createElement(`pre`);n.textContent=e.ruleJson,t.append(n)}O.append(t)}let s=document.createElement(`label`),c=document.createElement(`input`);c.type=`checkbox`,s.append(c,document.createTextNode(`Я сверил полноту и точность разбора с исходным Skill.`));let l=document.createElement(`button`);l.type=`button`,l.textContent=`Перенести черновик в форму`,l.disabled=!0,c.onchange=()=>{l.disabled=!c.checked},l.onclick=()=>{if(!c.checked||!te)return;if(x.value!==n||v.value!==r||S.value!==i){ne(),_.textContent=`Форма изменилась. Повторите разбор.`;return}let e=[...new Set([...i.split(/\r?\n/).map(e=>e.trim()).filter(Boolean),...t.manualChecks])];e.length>12?_.textContent=`Объединённый ручной чек-лист длиннее 12 пунктов. Сократите его и повторите разбор.`:(x.value=t.content,S.value=e.join(`
`),ne(),_.textContent=`Черновик перенесён в форму. Проверьте текст и нажмите «Сохранить Skill».`)},O.append(s,l),O.hidden=!1,_.textContent=`Разбор готов · ${t.items.length} требований · ${t.metadata?.resolvedModel||`модель не указана`}. Ничего не сохранено.`}catch(e){_.textContent=e.message}finally{t.disabled=!1}},h.onsubmit=async t=>{t.preventDefault(),C.disabled=!0,_.textContent=`Сохраняем Skill в проекте…`;let n=E(),r=new Set(d.skills.map(e=>e.id)),i=n?`PUT`:`POST`,a=n?`/ai/skills/${encodeURIComponent(n.id)}`:`/ai/skills`,o=S.value.split(/\r?\n/).map(e=>e.trim()).filter(Boolean);try{if(d=await Q(`/projects/${e}${a}`,i,{version:d.version,name:y.value,content:x.value,manualChecks:o}),!n){let e=d.skills.find(e=>!r.has(e.id));e&&(v.value=e.id)}if(v.value){let t=await Q(`/projects/${e}/ai/skills/${encodeURIComponent(v.value)}`);y.value=t.name,x.value=t.content,S.value=t.manualChecks.join(`
`)}ne(),C.textContent=`Сохранить изменения`,D(),_.textContent=`Skill сохранён · версия ${d.version}`}catch(e){_.textContent=e.message}finally{C.disabled=!1}},w.onclick=async()=>{let t=E();if(t){w.disabled=!0,_.textContent=`Активируем Skill…`;try{d=await Q(`/projects/${e}/ai/skills/${encodeURIComponent(t.id)}/activate`,`POST`,{version:d.version}),D(),_.textContent=`«${t.name}» будет выбран по умолчанию в редакторе · версия ${d.version}`}catch(e){_.textContent=e.message}finally{w.disabled=!1}}},T.onclick=async()=>{let t=E();if(t&&await ii(`Удалить Skill «${t.name}»?`,`Удалить Skill`)){T.disabled=!0,_.textContent=`Удаляем Skill…`;try{d=await Q(`/projects/${e}/ai/skills/${encodeURIComponent(t.id)}`,`DELETE`,{version:d.version}),ee(),_.textContent=`Skill удалён · версия ${d.version}`}catch(e){_.textContent=e.message}finally{T.disabled=!1}}},d.error&&(_.textContent=d.error),D()}G(`#logout`).onclick=async()=>{await Q(`/logout`,`POST`,{}),q=await Q(`/session`),mi()}}async function bi(e,t=null){Y=await Q(`/projects/${e}`),X=!1,Gr=null,Zr=null;try{Zr=(await Q(`/projects/${e}/publication`)).publication}catch{}Kr=!0,Y.slug&&Qr.set(e,Y.slug);let{default:n}=await Pr(async()=>{let{default:e}=await import(`./grapes-CyFkg3WL.js`);return{default:e}},[]);qr=!1,Jr=!1,Z=!1,Xr=void 0,clearTimeout(Yr),Yr=void 0,Fr.innerHTML=`<main class="editor-shell" data-open-panel="none" data-inspector-open="true"><header class="editor-top"><button id="back" class="brand brand-compact" aria-label="К страницам проекта" title="К страницам проекта">${Lr}</button><span id="project-name" class="project-name" role="button" tabindex="0" title="Дважды щёлкните, чтобы изменить название проекта" aria-label="Переименовать проект: ${K(Y.name)}">${K(Y.name)}</span><span class="divider"></span><div id="page-switcher" class="page-switcher"><button id="page-switcher-trigger" type="button" class="page-switcher-trigger" aria-label="Страница" aria-haspopup="listbox" aria-expanded="false" aria-controls="page-menu"><span id="page-switcher-label">Страница</span><span class="page-switcher-chevron" aria-hidden="true">${S(`chevron-down`)}</span></button><div id="page-menu" class="page-switcher-menu" role="listbox" aria-label="Страницы проекта" hidden></div></div><button id="add-page" class="icon-button" title="Добавить страницу">+</button><div class="device-switch" role="group" aria-label="Размер экрана"><button data-device="Desktop" class="active">Desktop</button><button data-device="Tablet">Tablet</button><button data-device="Mobile">Mobile</button></div><div class="top-actions"><button id="undo" title="Отменить (⌘Z / Ctrl+Z)" aria-label="Отменить" aria-keyshortcuts="Control+Z Meta+Z">↶</button><button id="redo" title="Повторить (⌘⇧Z / Ctrl+Shift+Z)" aria-label="Повторить" aria-keyshortcuts="Control+Shift+Z Meta+Shift+Z Control+Y">↷</button><button id="history">История</button><button id="theme" class="icon-button" aria-label="Настройки" title="Настройки страницы"></button><button id="export">Экспорт JSON</button><button id="static-export" title="Скачать все сохранённые страницы, SEO и стили в статическом ZIP">ZIP сайта</button><button id="publish-editor" class="secondary-link" title="Опубликовать сохранённую ревизию проекта">Опубликовать</button><button id="save" class="primary" title="Сохранить (⌘S / Ctrl+S)" aria-keyshortcuts="Control+S Meta+S">Сохранить</button></div></header><nav class="mobile-workspace-tabs" role="group" aria-label="Панели редактора"><button type="button" data-mobile-panel="canvas" aria-pressed="true">Холст</button><button type="button" data-mobile-panel="library" aria-pressed="false">Секции</button><button type="button" data-mobile-panel="inspector" aria-pressed="false">Свойства</button></nav><nav class="editor-floating-tools" aria-label="Инструменты страницы"><button id="toggle-layers" type="button" data-open-panel="layers" aria-label="Слои" title="Слои" aria-pressed="false"><span class="layers-icon" aria-hidden="true">≡</span></button><button id="toggle-library" type="button" data-open-panel="library" aria-label="Добавить секцию" title="Добавить секцию" aria-pressed="false">+</button></nav><aside class="editor-left"><div class="panel-tabs"><button data-panel="library" class="active">Секции</button><button data-panel="layers">Слои</button></div><section id="library"><div class="panel-heading panel-heading-with-close"><div><h2>Библиотека</h2><p>Добавьте секцию на страницу</p></div><button type="button" class="panel-close" data-close-panel aria-label="Закрыть библиотеку">×</button></div><div class="block-list">${Kn.map((e,t)=>`<button data-block="${e.id}" class="block-card" title="${K(e.label+` — `+e.description)}"><div class="block-media" aria-hidden="true">${Dt(e.id)}</div><strong>${e.label}</strong><small>${e.description}</small></button>`).join(``)}</div><div class="library-foot">Структурные компоненты<br>Каждый элемент можно изменить</div></section><section id="layers" hidden><div class="panel-heading panel-heading-with-close"><div><h2>Слои</h2><p>Структура выбранной страницы</p></div><button type="button" class="panel-close" data-close-panel aria-label="Закрыть слои">×</button></div><div id="layer-manager"></div></section></aside><section class="editor-center"><div class="canvas-toolbar"><span id="page-label">ГЛАВНАЯ</span><span id="canvas-size">Адаптивный холст</span><button id="preview">Предпросмотр ↗</button></div><div class="canvas-wrap"><div id="gjs"></div><div class="canvas-empty" id="canvas-empty"><div class="empty-shapes"><i></i><i></i><i></i></div><p>Здесь начинается ваш сайт</p><span>Добавьте первый экран из библиотеки слева</span><button id="start-hero">+ Добавить Hero</button></div></div></section><aside class="editor-right"><div class="panel-heading panel-heading-with-close"><div><p class="eyebrow">ИНСПЕКТОР</p><h2 id="selected-name">Выберите элемент</h2></div><button type="button" id="close-inspector" class="panel-close" aria-label="Закрыть инспектор">×</button></div><div class="inspector-hint" id="selection-hint">Нажмите на элемент в холсте, чтобы изменить его оформление.</div><section id="quick-edit" hidden><div id="text-edit"><label>Текст<textarea id="component-text" rows="3"></textarea></label><button id="apply-text">Применить текст</button></div><div id="photo-credit-edit" class="photo-credit-controls" hidden><label>Копирайт<textarea id="component-photo-credit" rows="2" placeholder="Фото: Автор · лицензия"></textarea></label><p class="muted small">Показывается под фотографией размером 8 px.</p></div><button type="button" id="edit-custom-code" hidden>Изменить HTML, CSS и JavaScript</button><label>Режим компоновки<select id="layout"><option value="block">Обычный поток</option><option value="flex">Flex</option><option value="grid">Grid</option></select></label><p class="muted small">Меняется только display. Остальные настройки сохраняются; доступна отмена.</p><section class="size-controls" aria-label="Адаптивные размеры"><h3>Размер и ограничения</h3><div class="size-control-grid"><label>Ширина<select id="width-mode" aria-label="Режим ширины"><option value="auto">Авто</option><option value="fit-content">Hug</option><option value="100%">Fill</option><option value="custom" disabled>CSS вручную</option></select></label><label>Высота<select id="height-mode" aria-label="Режим высоты"><option value="auto">Hug</option><option value="100%">Fill</option><option value="custom" disabled>CSS вручную</option></select></label></div><div class="size-constraint-grid"><label>Min. ширина<input id="min-width" type="text" inputmode="text" maxlength="32" placeholder="320px" aria-label="Минимальная ширина"></label><label>Max. ширина<input id="max-width" type="text" inputmode="text" maxlength="32" placeholder="80rem" aria-label="Максимальная ширина"></label><label>Min. высота<input id="min-height" type="text" inputmode="text" maxlength="32" placeholder="240px" aria-label="Минимальная высота"></label><label>Max. высота<input id="max-height" type="text" inputmode="text" maxlength="32" placeholder="none" aria-label="Максимальная высота"></label></div><button type="button" id="apply-size-constraints">Применить min/max</button><p class="muted small">Hug следует содержимому; Fill задаёт 100%. Размеры: px, %, rem, em, vw, vh. Пустое поле снимает ограничение.</p></section></section><section id="ai-component-editor" class="ai-component-editor" aria-labelledby="ai-component-title"><p class="eyebrow">AI-ПРАВКА</p><h3 id="ai-component-title">Изменить элемент</h3><p id="ai-component-target" class="muted small">Выберите элемент на холсте.</p><label class="ai-component-prompt-label">Что изменить?<textarea id="ai-component-prompt" rows="3" maxlength="2000" placeholder="Например: сократи текст и сделай заголовок выразительнее"></textarea></label><p class="muted small ai-component-disclosure">В OpenRouter будут отправлены запрос и безопасное описание выбранного элемента с его вложенными элементами. Остальная страница не отправляется. Изменение появится только после вашего подтверждения.</p><button type="button" class="primary" id="ai-component-propose" disabled>Предложить правку</button><p id="ai-component-status" class="muted small" role="status" aria-live="polite">Выберите элемент, чтобы подготовить AI-правку.</p><div id="ai-component-preview" class="ai-component-preview" hidden><h4>Предлагаемые изменения</h4><div id="ai-component-changes" class="ai-component-changes"></div><button type="button" class="primary" id="ai-component-apply">Применить и сохранить</button></div></section><div id="traits"></div><div id="flex-controls" class="flex-controls" hidden>${Ur}</div><div id="styles"></div><section class="ai-plan-panel" aria-labelledby="ai-plan-panel-title"><p class="eyebrow">AI-ПЛАНИРОВАНИЕ</p><h3 id="ai-plan-panel-title">Структура сайта</h3><p>Перед открытием AI незаписанные правки сохраняются. Секции не добавляются до вашего подтверждения.</p><button type="button" id="ai-plan-open" class="primary">Составить план</button><p id="ai-panel-status" class="muted small" role="status">Проверим доступность AI-сервера.</p></section></aside><footer class="editor-status"><span><i class="status-dot"></i> <span id="save-status">Ревизия ${Y.version} · Сохранено на сервере</span></span><span id="notice" role="status"></span><span class="status-actions"><button id="reload-server" hidden>Загрузить версию сервера</button><span class="version-label editor-version" aria-label="Версия продукта ${Ir}">Версия ${Ir}</span></span></footer></main><dialog id="confirm-dialog"><form method="dialog"><p id="confirm-message"></p><div class="dialog-actions"><button value="cancel">Отмена</button><button id="confirm-submit" class="primary" value="confirm">Продолжить</button></div></form></dialog><dialog id="history-dialog"><div class="history-head"><div><p class="eyebrow">СОХРАНЁННЫЕ СОСТОЯНИЯ</p><h2>История проекта</h2><p class="muted">Восстановление создаст новую ревизию. Текущая история останется доступной.</p></div><button id="close-history" aria-label="Закрыть">×</button></div><div id="history-list" class="history-list"></div><p id="history-error" role="status"></p></dialog><dialog id="image-dialog" aria-labelledby="image-dialog-title"></dialog><dialog id="page-dialog"><form id="page-form"><h2>Новая страница</h2><label>Название<input name="name" required maxlength="80"></label><div class="dialog-actions"><button type="button" id="cancel-page">Отмена</button><button class="primary">Добавить</button></div></form></dialog><dialog id="preview-dialog"><div class="preview-head"><strong>Предпросмотр страницы</strong><button id="close-preview">Закрыть</button></div><iframe id="preview-frame" sandbox="" title="Предпросмотр сайта"></iframe></dialog><dialog id="custom-code-dialog" aria-labelledby="custom-code-title"><div class="ai-plan-head"><div><p class="eyebrow">ИЗОЛИРОВАННЫЙ БЛОК</p><h2 id="custom-code-title">Custom Code</h2></div><button type="button" id="close-custom-code" aria-label="Закрыть">×</button></div><p class="muted small">HTML, CSS и JavaScript работают в отдельном sandbox iframe с непрозрачным origin. Код не видит DOM редактора или cookies; CSP ограничивает сетевые запросы.</p><label>HTML<textarea id="custom-code-html" rows="6" spellcheck="false"></textarea></label><label>CSS<textarea id="custom-code-css" rows="5" spellcheck="false"></textarea></label><label>JavaScript<textarea id="custom-code-js" rows="5" spellcheck="false"></textarea></label><div class="dialog-actions"><button type="button" id="custom-code-preview">Проверить в песочнице</button><button type="button" class="primary" id="custom-code-save">Сохранить блок</button></div><iframe id="custom-code-preview-frame" title="Предпросмотр кода в изоляции" style="width:100%;height:260px;border:1px solid var(--line);border-radius:8px;margin-top:18px"></iframe><p id="custom-code-status" role="status" class="muted small"></p></dialog><dialog id="ai-plan-dialog" aria-labelledby="ai-plan-title"><div class="ai-plan-head"><div><p class="eyebrow">AI-ПЛАНИРОВАНИЕ</p><h2 id="ai-plan-title">План сайта</h2></div><button type="button" id="close-ai-plan" aria-label="Закрыть">×</button></div><p class="muted ai-disclosure">На OpenRouter будет отправлено только описание из этого поля. Данные проекта и содержимое страницы не передаются. Незаписанные правки редактора сохраняются перед открытием этой формы; новые AI-секции добавятся только после вашего подтверждения.</p><p id="ai-provider-status" class="muted small" role="status">Проверяем настройки AI проекта…</p><a id="ai-settings-link" class="secondary-link" href="${$r(e)}/settings?section=ai" hidden>Настроить ключ в «Настройки сайта → AI Engine»</a><form id="ai-plan-form"><label for="ai-prompt">Опишите сайт, аудиторию и задачу<textarea id="ai-prompt" name="prompt" rows="4" maxlength="4000" required placeholder="Например: сайт семейной кофейни в Алматы, для жителей района, уютный стиль, цель — рассказать о меню и получить заказы"></textarea></label><div class="dialog-actions"><button type="submit" id="ai-generate" class="primary" disabled>Составить план</button></div></form><p id="ai-plan-status" class="muted small" role="status" aria-live="polite"></p><section id="ai-image-slot-chooser" hidden><div id="ai-image-slot-list"></div></section><button type="button" id="ai-job-cancel" hidden>Отменить генерацию</button><section id="ai-job-diagnostics" hidden aria-label="Диагностика генерации"></section><button type="button" id="ai-job-history">История генераций</button><section id="ai-job-history-list" hidden aria-label="История генераций"></section><button type="button" id="ai-job-resume">Восстановить последнюю задачу</button><section id="ai-plan-preview" class="ai-plan-preview" hidden aria-label="Предпросмотр плана"></section></dialog><dialog id="theme-dialog" aria-labelledby="page-settings-title"><div class="page-settings-heading"><h2 id="page-settings-title">Настройки страницы</h2><button type="button" id="close-page-settings" aria-label="Закрыть настройки">×</button></div><nav class="page-settings-tabs" aria-label="Разделы настроек"><button type="button" data-settings-tab="general">Основные</button><button type="button" data-settings-tab="seo">SEO</button><button type="button" data-settings-tab="social">Соцсети</button><button type="button" data-settings-tab="design">Оформление сайта</button></nav><form id="page-settings-form"><section data-settings-panel="general"><label>Название страницы<input name="name" required maxlength="100"></label><label>Адрес страницы<input name="slug" required maxlength="100" pattern="[a-z0-9]+(?:-[a-z0-9]+)*"></label><p class="muted small">Адрес используется при публикации и в ZIP. Главная страница также открывается в корне сайта.</p></section><section data-settings-panel="seo" hidden><label>Заголовок SEO<input name="title" maxlength="70" placeholder="По умолчанию — название страницы"></label><label>Описание SEO<textarea name="description" maxlength="160" rows="3"></textarea></label><label>Индексация<select name="robots"><option value="index">Разрешить</option><option value="noindex">Запретить</option></select></label></section><section data-settings-panel="social" hidden><p class="muted small">Open Graph и Twitter Card. Пустые заголовок и описание используют SEO.</p><label>Заголовок для соцсетей<input name="socialTitle" maxlength="70"></label><label>Описание для соцсетей<textarea name="socialDescription" maxlength="160" rows="3"></textarea></label><label>Изображение для соцсетей<input name="socialImage" type="url" maxlength="2048" pattern="https://.*" placeholder="https://example.com/photo.jpg"></label></section><div class="dialog-actions"><button class="primary" type="submit">Сохранить настройки страницы</button></div><p id="page-settings-status" role="status" class="muted small"></p></form><form id="theme-form" data-settings-panel="design" hidden><p class="eyebrow">ДИЗАЙН-СИСТЕМА ПРОЕКТА</p><h2 id="theme-title">Глобальные токены</h2><p class="muted">Изменения применятся к готовым секциям на всех страницах.</p><div class="theme-color-grid">${Rr}</div><div class="theme-options"><label>Шрифт заголовков<select name="headingFontFamily">${zr}</select></label><label>Шрифт основного текста<select name="bodyFontFamily">${zr}</select></label><label>Скругление карточек<select name="radius"><option value="0px">0 px</option><option value="4px">4 px</option><option value="8px">8 px</option><option value="12px">12 px</option><option value="16px">16 px</option><option value="24px">24 px</option><option value="32px">32 px</option></select></label></div><p class="muted small">Токены сохраняются в проекте и входят в историю версий.</p><div class="dialog-actions"><button type="button" id="cancel-theme">Отмена</button><button class="primary">Применить</button></div></form></dialog>`,fi(G(`#project-name`)),si(),ci();let r;J=n.init({assetManager:{custom:{open:e=>r?.open(e),close:()=>G(`#image-dialog`).open&&G(`#image-dialog`).close()}},plugins:[Ut],icons:C,container:`#gjs`,height:`100%`,width:`auto`,storageManager:!1,undoManager:{trackSelection:!1},noticeOnUnload:!1,panels:{defaults:[]},allowScripts:!1,canvas:{scripts:[],styles:[]},layerManager:{appendTo:`#layer-manager`},traitManager:{appendTo:`#traits`},selectorManager:{componentFirst:!0},styleManager:{appendTo:`#styles`,sectors:[{name:`Компоновка`,open:!0,properties:[`display`,`flex-direction`,`justify-content`,`align-items`,`flex-wrap`,`gap`,`grid-template-columns`]},{name:`Размеры и отступы`,open:!1,properties:[`padding`,`margin`]},{name:`Типографика`,open:!1,properties:[`font-family`,`font-size`,`font-weight`,`line-height`,`color`,`text-align`]},{name:`Оформление`,open:!1,properties:[`background-color`,`border`,`border-radius`,`opacity`]}]},deviceManager:{devices:[{id:`Desktop`,name:`Desktop`,width:``},{id:`Tablet`,name:`Tablet`,width:`768px`,widthMedia:`992px`},{id:`Mobile`,name:`Mobile`,width:`375px`,widthMedia:`576px`}]}}),G(`#ai-component-editor .ai-component-disclosure`).textContent=`В OpenRouter отправляются запрос и безопасное описание только выбранного элемента: его текст и локальные стили. Остальная страница не отправляется. Изменение появится только после вашего подтверждения.`;let i=tr({editor:J,confirmDelete:ii,notify:$});w(J),un(J,e,Q,$);let a=document.createElement(`a`);a.id=`page-view`,a.className=`secondary-link`,a.title=`Просмотр сохранённой страницы в новом окне`,a.setAttribute(`aria-label`,`Просмотр`),a.target=`_blank`,a.rel=`noopener noreferrer`,a.innerHTML=S(`eye`),G(`#save`).before(a);let o=()=>{let t=J.Pages.getSelected();a.href=`/api/projects/${e}/pages/${encodeURIComponent(t?.get(`id`)||`home`)}/view`};J.on(`page:select`,o),J.on(`load`,o),o(),G(`#ai-plan-open`).textContent=`AI-дизайн`,G(`.ai-plan-panel .eyebrow`).textContent=`AI-ДИЗАЙН`,G(`#ai-plan-panel-title`).textContent=`Сгенерировать страницу`,G(`.ai-plan-panel>p:not(.eyebrow)`).textContent=`Опишите идею — получите HTML и CSS, которые можно редактировать в GrapesJS.`,G(`#ai-plan-title`).textContent=`Дизайн страницы`,G(`#ai-plan-dialog .eyebrow`).textContent=`AI-ГЕНЕРАЦИЯ`,G(`#ai-generate`).textContent=`Создать дизайн`,G(`.ai-disclosure`).textContent=`В OpenRouter отправятся описание из этого поля, инструкции выбранного встроенного профиля и только палитра/типографические настройки проекта. Полные Project Data и содержимое страниц не передаются. Если ответ нарушит формат или проверки профиля, система выполнит одну исправляющую попытку с тем же контекстом; повторный провал остановит генерацию. Изображения подбираются автоматически; применение — отдельной кнопкой.`;let s=document.createElement(`label`);s.className=`ai-skill-profile-field`,s.textContent=`Профиль генерации`;let c=document.createElement(`select`);c.id=`ai-skill-profile`,c.setAttribute(`aria-label`,`Профиль генерации`);for(let[e,t]of[[`taste`,`Taste · выразительный дизайн`],[`standard`,`Стандартный дизайн`]]){let n=document.createElement(`option`);n.value=e,n.textContent=t,c.append(n)}s.append(c),G(`#ai-prompt`).closest(`label`).before(s);let d={version:0,activeSkillId:null,skills:[]},f=!1,p=``,m=()=>{let e=c.value,t;t=e.startsWith(`user:`)?`После нажатия «Создать дизайн» в OpenRouter отправятся описание и полный текст выбранного Skill с его ручным чек-листом.`:e===`taste`?`После нажатия «Создать дизайн» в OpenRouter отправятся описание и инструкции встроенного профиля Taste.`:`После нажатия «Создать дизайн» в OpenRouter отправятся описание и инструкции стандартного профиля.`,t+=` Сохранённые настройки палитры и типографики проекта используются только как визуальные ориентиры; полные Project Data и содержимое страниц не передаются.`,e.startsWith(`user:`)||(t+=` Изображения подбираются автоматически.`),t+=` Генерация выполняется до 10 минут. Сохраняйте вкладку открытой до завершения. При обрыве соединения запрос модели может продолжаться и расходовать токены. Задачу можно восстановить; описание, Skill и результат хранятся приватно до 24 часов. Результат сначала доступен в предпросмотре и применяется только по отдельному действию.`,G(`.ai-disclosure`).textContent=t},h=async()=>{let t=c.value;d=await Q(`/projects/${e}/ai/skills`);for(let e of[...c.options])e.dataset.userSkillId&&e.remove();for(let e of d.skills){let t=document.createElement(`option`);t.value=`user:`+e.id,t.dataset.userSkillId=e.id,t.textContent=`${e.name}${e.active?` · активный`:``}`,c.append(t)}let n=[...c.options].some(e=>e.value===t);!f&&d.activeSkillId?c.value=`user:`+d.activeSkillId:n?c.value=t:c.value=`taste`,f=!0,m()};c.onchange=m,m(),J.Components.addType(`image`,{model:{defaults:{traits:[`alt`,`src`]}}}),Wn(J,{projectId:e,csrf:()=>q.csrf}),Ct(J,{projectId:e,projectSlug:Y.slug,beforeOpen:()=>ui(!1),isClean:()=>!X&&!qr&&!Z,notify:$,onRemote:async t=>{if(t.version<=Y.version)return;if(X||qr||Z){Z=!0,clearTimeout(Yr),G(`#reload-server`).hidden=!1,G(`#save`).disabled=!0,si(),G(`#save-status`).textContent=`Zero Block изменён в другом окне`,$(`Локальные изменения сохранены в редакторе. Экспортируйте их или загрузите серверную версию.`,!0);return}let n=JSON.stringify(J.getProjectData());try{let r=await Q(`/projects/${e}`);if(X||qr||JSON.stringify(J.getProjectData())!==n){Z=!0,clearTimeout(Yr),G(`#reload-server`).hidden=!1,G(`#save`).disabled=!0,si(),$(`Во время синхронизации появились локальные изменения. Разрешите конфликт.`,!0);return}if(!u(Y.document,r.document,t.pageId,t.blockId)||JSON.stringify(Y.settings)!==JSON.stringify(r.settings)){location.reload();return}let i,a=e=>{e.get(`type`)===`zero-block`&&e.getAttributes().id===t.blockId&&(i=e);for(let t of e.components().models)a(t)},o=J.Pages.getAll().find(e=>e.id===t.pageId);if(o&&a(o.getMainComponent()),!i){location.reload();return}Kr=!0,J.UndoManager.skip(()=>i.set(`zeroData`,l(r.document,t.pageId,t.blockId).zeroData)),Y=r,J.clearDirtyCount(),Gr=JSON.stringify(J.getProjectData()),Kr=!1,X=!1,G(`#save-status`).textContent=`Zero Block обновлён · ревизия ${Y.version}`,si()}catch(e){Kr=!1,$(e.message,!0)}}}),qn(J),Wt(J,G(`.block-list`));let g=document.createElement(`div`);g.className=`library-filter`,g.innerHTML=`<label><span class="visually-hidden">Поиск секций и элементов</span><input id="block-search" type="search" placeholder="Поиск секций и элементов" autocomplete="off"></label><div class="library-categories" role="group" aria-label="Категории библиотеки">${[[`all`,`Все`],[`Секции`,`Секции`],[`Элементы`,`Элементы`],[`Компоновка`,`Компоновка`],[`Медиа`,`Медиа`],[`Навигация`,`Навигация`],[`Обложки`,`Обложки`],[`Карточки`,`Карточки`],[`Статьи`,`Статьи`],[`Галереи`,`Галереи`],[`Цены`,`Цены`],[`Команда`,`Команда`],[`Формы`,`Формы`]].map(([e,t],n)=>`<button type="button" data-library-category="${e}" aria-pressed="${n===0}">${t}</button>`).join(``)}</div>`,G(`#library .panel-heading`).after(g);let _=document.createElement(`p`);_.className=`library-empty`,_.textContent=`Ничего не найдено. Измените поиск или категорию.`,_.hidden=!0,G(`.block-list`).after(_);let v=()=>{let e=G(`#block-search`).value.trim().toLocaleLowerCase(`ru`),t=G(`.library-categories [aria-pressed="true"]`)?.dataset.libraryCategory||`all`,n=0;for(let r of document.querySelectorAll(`.block-card`)){let i=t===`all`||r.dataset.category===t,a=!e||r.textContent.toLocaleLowerCase(`ru`).includes(e);r.hidden=!(i&&a),r.hidden||n++}_.hidden=n>0};for(let e of document.querySelectorAll(`.block-card`))e.dataset.category||=Wr(e.dataset.block);G(`#block-search`).oninput=v;for(let e of document.querySelectorAll(`[data-library-category]`))e.onclick=()=>{for(let t of document.querySelectorAll(`[data-library-category]`))t.setAttribute(`aria-pressed`,String(t===e));v()};let y=()=>{let e=J.Pages.getSelected()?.getMainComponent(),t=wn(Y.settings?.designTokens||En(e?.getStyle()||{}));for(let e of vn){let n=G(`#theme-form [name="${e.name}"]`);n&&(n.value=t[e.name])}ve(G(`#theme-form`))},b=null,x=0,E=null,D=null,ee=null,te=null,O=null,ne=()=>{let e=re()||!!b?.photosPending;for(let t of document.querySelectorAll(`#ai-plan-apply, #ai-plan-replace`))t.disabled=e},re=()=>!b||b.baseVersion!==Y.version||b.design.contactAudit?.status!==`passed`,ie=new Map,k=()=>{x++;for(let e of ie.values())URL.revokeObjectURL(e);ie.clear()},ae=async e=>{if(e.kind===`commons`)return e.url;if(ie.has(e.id))return ie.get(e.id);let t=await fetch(e.url,{credentials:`same-origin`});if(!t.ok)throw Error(`Не удалось загрузить изображение из библиотеки проекта.`);let n=URL.createObjectURL(await t.blob());return ie.set(e.id,n),n},oe=e=>{if(e?.displayFit===`contain`)return!0;let t=Number(e?.width),n=Number(e?.height);if(!Number.isFinite(t)||!Number.isFinite(n)||t<=0||n<=0)return!1;let r=t/n;return r<.8||r>2.2},se=(e,t)=>{let n=e.closest(`.ai-hero-background`);return n?(n.style.setProperty(`background-image`,cn(t,`#000000`,.55)),n.style.setProperty(`background-size`,`cover`),n.style.setProperty(`background-position`,`center`),n.style.setProperty(`background-repeat`,`no-repeat`),e.classList.remove(`ai-image-slot`),e.style.display=`none`,!0):!1},ce=async()=>{if(!b)return;let e=G(`#ai-design-preview-frame`);if(!e)return;let t=++x,n=b.design,r=new DOMParser().parseFromString(n.html,`text/html`);for(let e of r.querySelectorAll(`[data-image-slot]`)){let t=b.assets.find(t=>t.id===b.imageAssignments[e.dataset.imageSlot]);if(!t){nr(e);continue}if(e.dataset.imageSlot===`hero`&&e.closest(`.ai-hero-background`)){let n=await ae(t),r=e.closest(`.ai-hero-background`);r.style.backgroundImage=`linear-gradient(rgba(0, 0, 0, 0.55), rgba(0, 0, 0, 0.55)), url("${n}")`,r.style.backgroundSize=`cover`,r.style.backgroundPosition=`center`,e.classList.remove(`ai-image-slot`),e.style.display=`none`,sn(e,t);continue}oe(t)&&e.classList.add(`ai-photo-fit-contain`);let n=r.createElement(`img`);n.src=await ae(t),n.alt=b.imageAlt[e.dataset.imageSlot]||``,e.replaceChildren(n),sn(e,t)}if(t!==x||!e.isConnected)return;let i=J.Pages.getSelected()?.getMainComponent()?.getEl(),a=document.createElement(`div`);if(i){let e=J.Canvas.getWindow().getComputedStyle(i);for(let t of[`font-family`,`font-size`,`font-weight`,`font-style`,`line-height`,`letter-spacing`,`color`])a.style.setProperty(t,e.getPropertyValue(t))}let o=a.style.cssText.replace(/</g,`\\3c `),s=me(),c=document.createElement(`div`);c.style.fontFamily=s.headingFontFamily,c.style.fontWeight=s.headingFontWeight,c.style.lineHeight=s.headingLineHeight;let l=Array.from({length:6},(e,t)=>(c.style.fontSize=s[`fontSizeH${t+1}`],`h${t+1}{${c.style.cssText.replace(/</g,`\\3c `)}}`)).join(``);e.srcdoc=`<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'none'; connect-src 'none'; img-src data: blob: https://upload.wikimedia.org https://thumb.wikimedia.org; font-src 'none'; style-src 'unsafe-inline'; object-src 'none'; base-uri 'none'; form-action 'none'"><style>*,*::before,*::after{box-sizing:border-box}body{margin:0;`+o+`}`+l+n.css+`</style></head><body>`+r.body.innerHTML+`</body></html>`},le=async(t,n)=>{let r=b;if(!r||re())return;r.photoQueries??={},r.photoQueries[t]=n;let i=await Q(`/projects/${e}/stock-photos?q=${encodeURIComponent(n)}`);if(b!==r)return;let a=i.photos||[];for(let e of a)r.assets.some(t=>t.id===e.id)||r.assets.push(e);let o=a.some(e=>e.searchBroadened);a.length&&!o&&(r.imageAssignments[t]=a[0].id,r.imageAlt[t]=n),ue(),await ce(),r.photoNotice=o?`Подходящего фото не найдено. Дизайн подготовлен без этого изображения.`:a.length?`Изображения подобраны автоматически.`:`Подходящее фото не найдено. Дизайн подготовлен без этого изображения.`,G(`#ai-plan-status`).textContent=r.photoNotice},ue=()=>{G(`#ai-image-slot-chooser`).hidden=!0,G(`#ai-image-slot-list`).replaceChildren()},de=(e,t,n=[])=>{O?.disconnect(),O=null;let r=G(`#ai-plan-preview`);r.replaceChildren();let i=document.createElement(`div`);i.className=`ai-plan-facts`;let a=document.createElement(`p`);a.textContent=e.siteType,i.append(a);for(let[t,n]of[[`Аудитория`,e.audience],[`Цель`,e.goal],[`Стиль`,e.style]]){let e=document.createElement(`p`),r=document.createElement(`span`);r.textContent=t,e.append(r,document.createTextNode(n)),i.append(e)}let o=_r(n);if(o){let e=document.createElement(`p`);e.className=`ai-open-design-reference`;let t=document.createElement(`span`);t.textContent=`Внешний референс`,e.append(t,document.createTextNode(hr(o.templateId)+` · `+gr(o.referenceStatus))),i.append(e)}let s=t?.skillProfile===`taste`,c=t?.skillProfile===`user_skill`;if(s&&e.concept){let t=document.createElement(`p`),n=document.createElement(`span`);n.textContent=`Идея`,t.append(n,document.createTextNode(e.concept)),i.append(t)}if(c&&t?.userSkillName){let e=document.createElement(`p`),n=document.createElement(`span`);n.textContent=`Skill`,e.append(n,document.createTextNode(t.userSkillName)),i.append(e)}r.append(i);let l=e.skillAudit,u=Array.isArray(l?.checks)?l.checks:[],d=c&&Array.isArray(l?.humanReviewRequired)?l.humanReviewRequired.filter(e=>typeof e==`string`&&e.trim()!==``):[];if(s&&l?.profile===`taste`||c&&l?.profile===`user_skill`&&(u.length||d.length)){let e=document.createElement(`section`);e.className=`ai-taste-audit`,e.setAttribute(`aria-label`,`Проверки требований Skill`);let t=document.createElement(`h3`);if(t.textContent=c?`Проверка требований Skill`:`Проверки структуры`,e.append(t),u.length){let t=document.createElement(`h4`);t.textContent=`Проверено автоматически`,e.append(t);let n=document.createElement(`ul`);for(let e of u){let t=document.createElement(`li`);if(t.dataset.status=e.status===`passed`?`passed`:`failed`,t.textContent=(e.status===`passed`?`✓ `:`! `)+(e.id?e.id+` · `:``)+e.label,e.evidence){let n=document.createElement(`small`);n.textContent=` · `+JSON.stringify(e.evidence),t.append(n)}n.append(t)}e.append(n)}if(c&&d.length){let t=document.createElement(`div`);t.className=`ai-skill-manual-review`;let n=document.createElement(`h4`);n.textContent=`Требует ручной оценки`,t.append(n);let r=document.createElement(`ul`);for(let e of d){let t=document.createElement(`li`);t.textContent=e,r.append(t)}t.append(r);let i=document.createElement(`p`);i.className=`muted small`,i.textContent=`Эти требования нельзя подтвердить автоматической проверкой. Сверьте их с предпросмотром.`,t.append(i),e.append(t)}if(s){let t=document.createElement(`p`);t.className=`muted small`,t.textContent=`Структура страницы проверена автоматически.`,e.append(t)}r.append(e)}let f=document.createElement(`iframe`);f.id=`ai-design-preview-frame`,f.className=`ai-design-preview-frame`,f.title=`Предпросмотр AI-дизайна`,f.setAttribute(`sandbox`,``);let p=document.createElement(`div`);p.className=`ai-skill-preview-scroll`,p.append(f),r.append(p);let m=0,h=!1,g=()=>{if(!m)return;let e=getComputedStyle(f),t=(Number.parseFloat(e.marginTop)||0)+(Number.parseFloat(e.marginBottom)||0),n=pn(p.clientWidth,m,f.offsetHeight,t),r=h&&n.fitted;f.style.transformOrigin=`top left`,f.style.transform=r?`scale(${n.scale})`:``,p.style.height=r?`${n.wrapperHeight}px`:``,p.style.overflow=r?`hidden`:`auto`,p.dataset.fitted=String(r)};{let e=document.createElement(`p`);e.className=`muted small ai-taste-view-note`,e.textContent=`Предпросмотр на компьютере, планшете и телефоне.`,r.append(e);let t=document.createElement(`div`);t.className=`ai-taste-viewport-controls`,t.setAttribute(`role`,`group`),t.setAttribute(`aria-label`,`Размер предпросмотра`);for(let[e,n]of Object.entries({desktop:1440,tablet:768,mobile:375})){let r=document.createElement(`button`);r.type=`button`,r.dataset.viewport=e,r.textContent=(e===`desktop`?`Desktop`:e===`tablet`?`Tablet`:`Mobile`)+` · `+n+` px`,r.setAttribute(`aria-pressed`,`false`),r.onclick=()=>{m=n,f.style.width=n+`px`,f.style.maxWidth=`none`;for(let e of t.querySelectorAll(`[data-viewport]`))e.setAttribute(`aria-pressed`,String(e===r));g()},t.append(r)}let n=document.createElement(`button`);n.type=`button`,n.dataset.fitPreview=`true`,n.textContent=`Вписать`,n.setAttribute(`aria-label`,`Уместить выбранную ширину предпросмотра в окне`),n.setAttribute(`aria-pressed`,`false`),n.onclick=()=>{h=!h,n.setAttribute(`aria-pressed`,String(h)),g()},t.append(n);let i=document.createElement(`button`);i.type=`button`,i.textContent=`Расширить окно`,i.setAttribute(`aria-pressed`,`false`),i.onclick=()=>{let e=G(`#ai-plan-dialog`).classList.toggle(`ai-preview-expanded`);i.setAttribute(`aria-pressed`,String(e)),i.textContent=e?`Обычное окно`:`Расширить окно`,requestAnimationFrame(g)},t.append(i),r.insertBefore(t,p)}typeof ResizeObserver==`function`&&(O=new ResizeObserver(g),O.observe(p)),ue(),ce().catch(e=>{G(`#ai-plan-status`).textContent=e.message});let _=document.createElement(`p`);_.className=`muted small`,_.textContent=e.contactAudit?.status===`passed`?`Контакты и внешние ссылки проверены автоматически.`:`Контакты этого старого результата автоматически не проверены.`,r.append(_);let v=document.createElement(`p`);v.className=`muted small`,v.textContent=`Секций: `+e.sectionCount+`. Фото подбираются автоматически с сохранением автора и лицензии. Изображения можно изменить в редакторе.`,r.append(v);let y=t?.usage||{},x=[];for(let[e,t]of[[`promptTokens`,`входные токены`],[`completionTokens`,`выходные токены`],[`totalTokens`,`всего токенов`]])Number.isInteger(y[e])&&y[e]>=0&&x.push(t+`: `+y[e]);typeof y.costUsd==`number`&&Number.isFinite(y.costUsd)&&y.costUsd>=0&&x.push(`стоимость: $`+y.costUsd.toFixed(6));let S=t?.photoSelectionUsage;S&&(Number.isInteger(S.totalTokens)&&x.push(`подбор фото: `+S.totalTokens+` токенов`),typeof S.costUsd==`number`&&Number.isFinite(S.costUsd)&&S.costUsd>=0&&x.push(`подбор фото: $`+S.costUsd.toFixed(6)));let C=typeof t?.resolvedModel==`string`?t.resolvedModel:`модель не указана`,w=document.createElement(`p`);w.className=`muted small ai-plan-metadata`,w.textContent=(t?.resolvedProfileName?t.resolvedProfileName+` · `:``)+C+(x.length?` · `+x.join(` · `):``),r.append(w);let T=document.createElement(`div`);T.className=`dialog-actions ai-design-apply-actions`;let E=document.createElement(`button`);E.type=`button`,E.id=`ai-plan-replace`,E.className=`primary`,E.textContent=`Заменить содержимое · `+e.sectionCount+` секций`,E.onclick=()=>pe(`replace`);let D=document.createElement(`button`);D.type=`button`,D.id=`ai-plan-apply`,D.textContent=`Добавить · `+e.sectionCount+` секций`,D.onclick=()=>pe(`append`);for(let e of[E,D])e.disabled=re()||!!b?.photosPending;re()&&(E.textContent=`Заменить · только просмотр`,D.textContent=`Добавить · только просмотр`),T.append(E,D),r.append(T),r.hidden=!1},fe=()=>{let e=new DOMParser().parseFromString(b.design.html,`text/html`);for(let t of e.querySelectorAll(`[data-image-slot]`)){let n=t.dataset.imageSlot,r=b.assets.find(e=>e.id===b.imageAssignments[n]);if(t.removeAttribute(`data-image-slot`),t.replaceChildren(),!r){nr(t);continue}if(n===`hero`&&se(t,r.url)){sn(t,r);continue}oe(r)&&t.classList.add(`ai-photo-fit-contain`);let i=e.createElement(`img`);i.src=r.url,i.alt=b.imageAlt[n]||``,t.append(i),sn(t,r)}return e.body.innerHTML},pe=async(e=`append`)=>{if(!b||b.photosPending)return;if(re()){G(`#ai-plan-status`).textContent=`Версия проекта изменилась или отсутствует проверка контактов. Создайте новую генерацию.`;return}let t=J.Pages.getAll().find(e=>e.get(`id`)===b.pageId);if(!t){$(`Страница предпросмотра больше не существует.`,!0);return}if(J.Pages.getSelected()?.get(`id`)!==b.pageId){G(`#ai-plan-status`).textContent=`Выбрана другая страница. Составьте дизайн заново для текущей страницы.`;return}let n=e===`replace`,r=n?`Заменить содержимое`:`Добавить дизайн`;if(!await ii(n?`Заменить все текущие секции страницы «`+(t.get(`name`)||t.get(`id`))+`» на `+b.design.sectionCount+` сгенерированных секций? Настройки страницы и другие страницы останутся без изменений. Будет создана новая ревизия проекта.`:`Добавить `+b.design.sectionCount+` сгенерированных секций в конец страницы «`+(t.get(`name`)||t.get(`id`))+`»? Текущие секции сохранятся. Будет создана новая ревизия проекта.`,r))return;let i=Array.from(document.querySelectorAll(`#ai-plan-apply, #ai-plan-replace`)),a=J.getProjectData(),o=Y.version;for(let e of i)e.disabled=!0;G(`#ai-plan-status`).textContent=n?`Заменяем содержимое страницы редактируемыми компонентами…`:`Добавляем дизайн редактируемыми компонентами…`;try{Kr=!0;let e=t.getMainComponent(),r=e.components().length;if(n&&e.components().reset(),e.append(fe()),e.components().length!==(n?1:r+1))throw Error(`Редактор не смог разобрать сгенерированную структуру.`);J.addStyle(b.design.css)}catch(e){try{J.loadProjectData(a),J.clearDirtyCount(),X=!1,we(),ge()}catch{G(`#ai-plan-status`).textContent=`Импорт не завершился, а локальное состояние нужно перезагрузить.`;for(let e of i)e.disabled=!1;return}G(`#ai-plan-status`).textContent=e.message;for(let e of i)e.disabled=!1;return}finally{Kr=!1}X=!0,ge(),G(`#save-status`).textContent=`Сохраняем AI-дизайн…`,G(`#ai-plan-status`).textContent=`Сохраняем редактируемую страницу…`;try{await ui(!1),!X&&Y.version>o?(G(`#ai-plan-dialog`).close(),$(`AI-дизайн `+(n?`заменил содержимое страницы`:`добавлен`)+` · ревизия `+Y.version)):(G(`#ai-plan-status`).textContent=`Дизайн импортирован в редактор, но сервер не подтвердил сохранение. Проверьте статус редактора; несохранённые изменения можно отменить.`,$(`AI-дизайн пока не сохранён на сервере.`,!0))}catch(e){G(`#ai-plan-status`).textContent=e.message,$(e.message,!0)}finally{for(let e of i)e.disabled=re()||!!b?.photosPending}},me=()=>wn(Y.settings?.designTokens||En(J.Pages.getSelected()?.getMainComponent()?.getStyle()||{})),he=e=>{let t=wn({...Y.settings.designTokens,...e}),n=Dn(t);Y.settings={...Y.settings,designTokens:t};let r=e=>{let t={},n=String(e.get?.(`tagName`)||``).toLowerCase(),i=e.getStyle?.()||{};for(let[r,i]of Object.entries(e.getStyle?.()||{})){let e=An(r,i,n);e!==i&&(t[r]=e)}let a=n.match(/^h([1-6])$/)?.[1];if(a){let n={"font-family":`var(--juzimder-font-heading, Arial, sans-serif)`,"font-size":M(`fontSizeH${a}`),"font-weight":`var(--juzimder-font-weight-heading, 500)`,"line-height":`var(--juzimder-line-height-heading, 1.15)`};for(let[r,a]of Object.entries(n)){let n=i[r],o=e.getEl?.(),s=o&&J.Css.getAll().some(e=>{let t=e.selectorsToString();if(!t.includes(`.ai-scope-`)||!Object.hasOwn(e.getStyle(),r))return!1;try{return o.matches(t)}catch{return!1}}),c=typeof n==`string`&&(n.includes(`--juzimder-font`)||n.includes(`--juzimder-line-height`));s?c&&e.removeStyle(r):(n===void 0||c)&&(t[r]=a)}}Object.keys(t).length&&e.addStyle(t),e.components?.().forEach(r)};for(let e of J.Pages.getAll()){let t=e.getMainComponent(),i=t.getStyle()||{};for(let[e,t]of Object.entries({"font-family":`var(--juzimder-font-body, Arial, sans-serif)`,"font-size":`var(--juzimder-font-size-base, 16px)`,"font-weight":`var(--juzimder-font-weight-body, 400)`,"line-height":`var(--juzimder-line-height-body, 1.6)`,"letter-spacing":`var(--juzimder-letter-spacing, 0px)`})){let r=i[e];(r===void 0||typeof r==`string`&&/(?:--juzimder-font|--juzimder-line-height|--juzimder-letter-spacing)/.test(r))&&(n[e]=t)}t.addStyle(n),r(t)}y()},ge=()=>{let e=J.Pages.getSelected();G(`#canvas-empty`).hidden=!!e?.getMainComponent()?.components().length},_e=G(`#page-switcher`),A=G(`#page-menu`),ye=G(`#page-switcher-trigger`),be=null,xe=e=>{clearTimeout(be),be=null,A.hidden=!0,ye.setAttribute(`aria-expanded`,`false`),e&&ye.focus()},Se=e=>{A.hidden=!1,ye.setAttribute(`aria-expanded`,`true`),e&&A.querySelector(`[role="option"][aria-selected="true"]`)?.focus()},Ce=e=>{let t=J.Pages.get(e);t&&(xe(),J.Pages.select(t))},we=()=>{let e=J.Pages.getSelected(),t=J.Pages.getAll();G(`#page-switcher-label`).textContent=e?.get(`name`)||`Страница`,G(`#page-label`).textContent=e?.get(`name`)||`Страница`,A.replaceChildren();for(let n of t){let t=document.createElement(`div`),r=document.createElement(`span`);if(t.className=`page-switcher-option`,t.setAttribute(`role`,`option`),t.setAttribute(`aria-selected`,String(n===e)),t.tabIndex=n===e?0:-1,t.dataset.pageId=n.id,r.className=`page-switcher-option-name`,r.textContent=n.get(`name`)||n.id,t.append(r),n===e){let e=document.createElement(`span`);e.className=`page-switcher-current`,e.textContent=`Открыта`,t.append(e)}A.append(t)}ge()},Te=(e,t,n)=>{Kr=!0,J.Pages.get(t)?.set(`name`,n,{silent:!0}),Kr=!1,we(),A.querySelector(`[data-page-id="${CSS.escape(t)}"]`)?.focus()},Ee=async(t,n,r)=>{if(n.dataset.committing===`true`)return;let i=J.Pages.get(t),a=i?.get(`name`)||t,o=n.value.trim();if(i){if(!o)n.setCustomValidity(`Введите название страницы.`),n.reportValidity();else if(n.setCustomValidity(``),o===a)we(),A.querySelector(`[data-page-id="${CSS.escape(t)}"]`)?.focus();else{n.dataset.committing=`true`;for(let e of r.querySelectorAll(`button,input`))e.disabled=!0;try{if(await ui(!1),X||Z)throw Error(`Не удалось сохранить текущие изменения. Разрешите конфликт и повторите переименование.`);Y=await Q(`/projects/${e}/pages/${encodeURIComponent(t)}`,`POST`,{version:Y.version,action:`rename`,name:o}),Kr=!0,J.Pages.get(t)?.set(`name`,o,{silent:!0}),Kr=!1,Gr=JSON.stringify(J.getProjectData()),X=!1,we(),G(`#save-status`).textContent=`Сохранено · ревизия ${Y.version}`,$(`Название страницы сохранено`),A.querySelector(`[data-page-id="${CSS.escape(t)}"]`)?.focus()}catch(e){n.dataset.committing=`false`;for(let e of r.querySelectorAll(`button,input`))e.disabled=!1;let t=r.querySelector(`.page-rename-error`);t||(t=document.createElement(`span`),t.className=`page-rename-error`,t.setAttribute(`role`,`alert`),r.append(t)),t.textContent=e.message,$(e.message,!0),n.focus()}finally{n.dataset.committing===`true`&&delete n.dataset.committing}}}},De=(e,t)=>{let n=J.Pages.get(t);if(!n)return;let r=n.get(`name`)||t;e.replaceChildren(),e.classList.add(`is-renaming`),e.setAttribute(`role`,`group`),e.setAttribute(`aria-label`,`Переименование страницы`),e.removeAttribute(`aria-selected`),e.tabIndex=-1;let i=document.createElement(`input`);i.className=`page-switcher-rename-input`,i.type=`text`,i.required=!0,i.maxLength=100,i.value=r,i.setAttribute(`aria-label`,`Новое название страницы`);let a=document.createElement(`button`),o=document.createElement(`button`);a.type=`button`,a.className=`page-rename-action`,a.setAttribute(`aria-label`,`Сохранить название`),a.title=`Сохранить`,a.innerHTML=`${S(`check`)}`,o.type=`button`,o.className=`page-rename-action`,o.setAttribute(`aria-label`,`Отменить переименование`),o.title=`Отмена`,o.innerHTML=`${S(`x`)}`,a.onpointerdown=o.onpointerdown=e=>e.preventDefault(),a.onclick=()=>void Ee(t,i,e),o.onclick=()=>Te(e,t,r),i.onkeydown=n=>{n.key===`Enter`?(n.preventDefault(),Ee(t,i,e)):n.key===`Escape`&&(n.preventDefault(),Te(e,t,r))},e.append(i,a,o),i.focus(),i.select()};J.on(`load`,()=>{J.loadProjectData(Y.document.data),t&&J.Pages.getAll().some(e=>e.get(`id`)===t)&&J.Pages.select(t),he(me());let e=JSON.stringify(J.getProjectData()),n=nn(J),r=JSON.stringify(J.getProjectData());Kr=!1,J.clearDirtyCount(),Gr=e,X=n>0&&r!==e,X?(G(`#save-status`).textContent=`Обновляем подпись фонового фото…`,li()):Gr=r,si(),we(),y()}),J.on(`project:loaded`,()=>queueMicrotask(si)),J.on(`update`,()=>{if(!Kr){E&&(E=null,G(`#ai-component-preview`).hidden=!0,G(`#ai-component-changes`).replaceChildren(),G(`#ai-component-status`).textContent=`Страница изменилась. Составьте AI-правку заново.`);let e=X;X=Gr!==null&&JSON.stringify(J.getProjectData())!==Gr,X?(G(`#save-status`).textContent=Z?`Версия изменилась в другой вкладке`:`Есть несохранённые изменения`,Z||li()):e&&!qr&&!Z&&(clearTimeout(Yr),Yr=void 0,G(`#save-status`).textContent=`Сохранено · ревизия ${Y.version}`)}si(),ge()});let Oe=()=>{let t=J.Pages.getSelected();t&&history.replaceState({},``,`${$r(e)}/pages/${encodeURIComponent(t.get(`id`))}/edit`)};J.on(`page:select page:add page:remove`,()=>{we(),y(),Oe()});let ke=e=>{let t=e.getStyle(),n=t.width||`auto`,r=t.height||`auto`;G(`#width-mode`).value=[`auto`,`fit-content`,`100%`].includes(n)?n:`custom`,G(`#height-mode`).value=[`auto`,`100%`].includes(r)?r:`custom`;for(let e of[`min-width`,`max-width`,`min-height`,`max-height`])G(`#${e}`).value=t[e]||``},Ae=e=>({"flex-direction":e?.get?.(`type`)===`wrapper`?`column`:`row`,"justify-content":`flex-start`,"align-items":`stretch`,"flex-wrap":`nowrap`}),je=e=>{let t=e?.getStyle?.()||{},n=Ae(e);G(`#flex-controls`).hidden=!e||e.get(`type`)===`zero-block`;for(let e of document.querySelectorAll(`[data-flex-property]`)){let r=e.dataset.flexProperty,i=(t[r]||n[r])===e.dataset.flexValue;e.classList.toggle(`active`,i),e.setAttribute(`aria-pressed`,String(i))}T(document,{...n,...t})},Me=dn,Ne=(e,t)=>{let n=t?.getMainComponent?.(),r=[],i=e;for(;i&&i!==n;){let e=i.parent?.(),t=e?.components?.().indexOf(i);if(!e||!Number.isInteger(t)||t<0)return null;r.unshift(t),i=e}return i===n?r:null},Pe=e=>{E=null,G(`#ai-component-preview`).hidden=!0,G(`#ai-component-changes`).replaceChildren(),e&&(G(`#ai-component-status`).textContent=e)},Fe=e=>{ee=e||null,D=Me(e),Pe();let t=J.Pages.getSelected(),n=e?Ne(e,t):null;te=Array.isArray(n)?n:null;let r=!!e&&![`wrapper`,`zero-block`].includes(e.get(`type`))&&Array.isArray(n)&&n.length>0&&!Z;G(`#ai-component-prompt`).disabled=!r,G(`#ai-component-propose`).disabled=!r,G(`#ai-component-target`).textContent=r?`${e.getName()} · ${D?`стабильный ID ${D}`:`ID будет закреплён при применении`}`:e?`Для AI-правки выберите компонент внутри страницы.`:`Выберите элемент на холсте.`,G(`#ai-component-status`).textContent=r?`Опишите правку. До подтверждения страница не изменится.`:`AI-правка доступна для выбранного вложенного компонента.`},Ie=(e,t,n,r)=>{let i=document.createElement(`article`);i.className=`ai-component-change`;let a=document.createElement(`div`);a.className=`ai-component-change-title`,a.textContent=`${e.getName()} · ${t}`;let o=document.createElement(`div`);o.className=`ai-component-change-values`;for(let[e,t]of[[`Было`,n],[`Будет`,r]]){let n=document.createElement(`div`),r=document.createElement(`small`);r.textContent=e;let i=document.createElement(`span`);i.textContent=t==null||t===``?`—`:String(t),n.append(r,i),o.append(n)}i.append(a,o),G(`#ai-component-changes`).append(i)},Le=(e,t,n,r)=>{if(e?.baseVersion!==Y.version||e?.pageId!==n||e?.requestedComponentId!==r||typeof e?.needsId!=`boolean`||typeof e?.componentId!=`string`||!e.componentId||!Array.isArray(e.operations)||e.operations.length<1||e.operations.length>20)throw Error(`Предложение устарело или имеет неверный формат. Составьте его заново.`);if(e.needsId?r!==``||!/^cmp-[a-f0-9]{24}$/.test(e.componentId):r!==e.componentId)throw Error(`Стабильный ID выбранного элемента изменился. Составьте правку заново.`);let i=new Map([[e.componentId,t]]),a=new Set(`display.flex-direction.justify-content.align-items.flex-wrap.align-self.grid-template-columns.gap.width.height.min-width.max-width.min-height.max-height.padding.padding-top.padding-right.padding-bottom.padding-left.margin.margin-top.margin-right.margin-bottom.margin-left.color.background-color.font-family.font-size.font-weight.line-height.letter-spacing.text-align.text-decoration.border.border-top.border-bottom.border-radius.object-fit.aspect-ratio.opacity`.split(`.`));for(let t of e.operations){let e=i.get(t?.componentId);if(!e)throw Error(`AI предложил изменить компонент за пределами выбранного элемента.`);if(t.operation===`replace_text`){if(![`text`,`textnode`,`link`].includes(e.get(`type`))||typeof t.content!=`string`||/[<>\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]|https?:\/\/|www\./iu.test(t.content))throw Error(`AI предложил недопустимую текстовую правку.`)}else if(t.operation===`update_styles`){if(!t.styles||typeof t.styles!=`object`||Array.isArray(t.styles)||!Object.keys(t.styles).length||Object.keys(t.styles).some(e=>!a.has(e)||typeof t.styles[e]!=`string`))throw Error(`AI предложил недопустимые стили.`)}else throw Error(`AI предложил неподдерживаемое действие.`)}return i};G(`#ai-component-propose`).onclick=async()=>{let t=G(`#ai-component-propose`),n=J.getSelected(),r=J.Pages.getSelected(),i=G(`#ai-component-prompt`).value.trim();if(!n||!r||!i)return;if(Z){G(`#ai-component-status`).textContent=`Сначала загрузите актуальную версию проекта с сервера.`;return}if(n!==ee){Fe(n),G(`#ai-component-status`).textContent=`Выбор элемента обновлён. Проверьте его и повторите запрос.`;return}if(Me(n)!==D&&Fe(n),X){if(await ui(!1),X||Z){G(`#ai-component-status`).textContent=`Не удалось сохранить текущие правки. AI-изменение не запрошено.`;return}if(J.getSelected()!==n||J.Pages.getSelected()?.get(`id`)!==r.get(`id`)){Fe(J.getSelected()),G(`#ai-component-status`).textContent=`Страница или выбор изменились во время сохранения. Проверьте их и повторите запрос.`;return}}let a=r.get(`id`),o=D,s=Ne(n,r),c=te,l=Y.version;if(!Array.isArray(s)||s.length===0||JSON.stringify(s)!==JSON.stringify(c)||n.get(`type`)===`wrapper`){Fe(n),G(`#ai-component-status`).textContent=`Выбор элемента изменился. Проверьте его и повторите запрос.`;return}let u=JSON.stringify(J.getProjectData());t.disabled=!0,Pe(`Отправляем запрос с данными только выбранного элемента…`);try{let t=await Q(`/projects/${e}/ai/edit-component`,`POST`,{prompt:i,pageId:a,componentPath:s,componentId:o,version:l});if(!rr({editor:J,component:n,pageId:a,baseVersion:l,currentVersion:Y.version,snapshot:u,dirty:X,conflicted:Z}))throw Error(`Страница, версия или выбранный элемент изменились во время AI-запроса. Подготовьте правку заново.`);let r=Le(t,n,a,o);E={...t,requestedComponentId:o,componentModel:n,pageId:a,baseVersion:l,editorSnapshot:u};for(let e of t.operations){let t=r.get(e.componentId);if(e.operation===`replace_text`)Ie(t,`Текст`,t.getEl()?.textContent||t.get(`content`)||``,e.content);else for(let[n,r]of Object.entries(e.styles))Ie(t,n,t.getStyle()?.[n]||``,r)}G(`#ai-component-preview`).hidden=!1,G(`#ai-component-status`).textContent=`Предложено операций: ${t.changeCount||t.operations.length}. Проверьте каждое изменение перед применением.`}catch(e){Pe(e.message),$(e.message,!0)}finally{let e=J.getSelected(),n=J.Pages.getSelected();t.disabled=!e||e.get(`type`)===`wrapper`||!Array.isArray(Ne(e,n))||Z}},G(`#ai-component-apply`).onclick=async()=>{let e=E;if(!e)return;if(Z||Y.version!==e.baseVersion){Pe(`Версия проекта изменилась. Составьте правку заново.`);return}let t=J.getSelected(),n=J.Pages.getSelected();if(!ir({proposal:e,currentProposal:E,editor:J,component:t,componentId:Me(t),pageId:n?.get(`id`),currentVersion:Y.version,conflicted:Z})){Pe(`Версия проекта или выбранный элемент изменились. Составьте правку заново.`);return}if(!await ii(`Применить ${e.operations.length} AI-изменений к «${t.getName()}» и сохранить новую ревизию?`,`Применить AI-правку`))return;if(!ir({proposal:e,currentProposal:E,editor:J,component:J.getSelected(),componentId:Me(J.getSelected()),pageId:J.Pages.getSelected()?.get(`id`),currentVersion:Y.version,conflicted:Z})){Pe(`Версия проекта или выбранный элемент изменились. Составьте правку заново.`);return}let r=G(`#ai-component-apply`),i=J.getProjectData(),a=new Map([[e.componentId,t]]),o=e.baseVersion;r.disabled=!0,G(`#ai-component-status`).textContent=`Применяем проверенные изменения и сохраняем ревизию…`;try{Kr=!0,e.needsId&&t.addAttributes({id:e.componentId});for(let t of e.operations){let e=a.get(t.componentId);if(!e)throw Error(`Компонент больше не найден.`);t.operation===`replace_text`?e.get(`type`)===`textnode`?e.set(`content`,t.content):e.components(K(t.content)):e.addStyle(t.styles)}}catch(e){J.loadProjectData(i),J.clearDirtyCount(),we(),ge(),G(`#ai-component-status`).textContent=e.message,r.disabled=!1,Kr=!1;return}finally{Kr=!1}X=JSON.stringify(J.getProjectData())!==JSON.stringify(Y.document.data),X?(G(`#save-status`).textContent=`Сохраняем AI-правку…`,await ui(!1),!X&&Y.version>o?(Fe(t),G(`#component-text`).value=t.getEl()?.textContent||t.get(`content`)||``,Pe(`Изменения сохранены · ревизия ${Y.version}.`),$(`AI-правка сохранена · ревизия ${Y.version}`)):(G(`#ai-component-status`).textContent=`Редактор подготовил изменение, но сервер не подтвердил сохранение. Проверьте статус проекта; при конфликте загрузите актуальную версию.`,$(`AI-правка не подтверждена сервером.`,!0)),r.disabled=!1):(Pe(`AI не предложил изменений, отличающихся от текущих значений. Ревизия не создана.`),r.disabled=!1)};let Re=e=>{let t=e;for(;t;){let e=t.components?.().models||[];if(t.get?.(`tagName`)===`figure`){let n=e.find(e=>e.get(`type`)===`image`);if(n)return{figure:t,image:n,caption:e.find(e=>e.get(`tagName`)===`figcaption`)||null}}if(t.get?.(`type`)===`image`)return{figure:null,image:t,caption:null};t=t.parent?.()}return null},ze=e=>{let t=G(`#photo-credit-edit`),n=G(`#component-photo-credit`),r=Re(e);t.hidden=!r,n.value=r?.caption?.get(`content`)||``};G(`#component-photo-credit`).addEventListener(`change`,()=>{let e=Re(J.getSelected());if(!e)return;let t=on(G(`#component-photo-credit`).value);if(e.figure){t?e.caption?e.caption.set(`content`,t):e.figure.components().add(rn(t)):e.caption?.remove();return}if(!t)return;let n=e.image.replaceWith(an(e.image.toJSON(),t));n?.[0]&&J.select(n[0])}),J.on(`component:selected`,e=>{G(`#selected-name`).textContent=e.get(`type`)===`wrapper`?`Body · Корень страницы`:e.getName(),G(`#selection-hint`).hidden=!0,G(`#quick-edit`).hidden=!1,G(`#quick-edit`).dataset.zero=String(e.get(`type`)===`zero-block`),document.querySelector(`.editor-shell`).dataset.zeroSelected=String(e.get(`type`)===`zero-block`);let t=[`text`,`link`,`textnode`].includes(e.get(`type`));G(`#text-edit`).hidden=!t,G(`#component-text`).disabled=!t,G(`#apply-text`).disabled=!t,G(`#component-text`).value=t&&(e.getEl()?.textContent||e.get(`content`))||``,G(`#edit-custom-code`).hidden=e.get(`type`)!==`custom-code`,G(`#layout`).value=e.getStyle().display||`block`,ke(e),je(e),Fe(e),ze(e),ei(`inspector`)}),J.on(`component:deselected`,()=>{J.getSelected()||(document.querySelector(`.editor-shell`).dataset.zeroSelected=`false`,G(`#selected-name`).textContent=`Выберите элемент`,G(`#selection-hint`).hidden=!1,G(`#quick-edit`).hidden=!0,je(null),Fe(null),ze(null))}),J.on(`component:update:style`,e=>{J.getSelected()===e&&(ke(e),je(e))});let Be=null,Ve=()=>({html:G(`#custom-code-html`).value,css:G(`#custom-code-css`).value,js:G(`#custom-code-js`).value}),He=e=>{if(new TextEncoder().encode(e.html).length+new TextEncoder().encode(e.css).length+new TextEncoder().encode(e.js).length>65536||new TextEncoder().encode(e.html).length>32768||new TextEncoder().encode(e.css).length>16384||new TextEncoder().encode(e.js).length>16384)throw Error(`Размер блока превышен: HTML до 32 КБ, CSS и JavaScript до 16 КБ каждый.`);if(/<\/style\s*>/i.test(e.css))throw Error(`В CSS нельзя закрывать тег style.`)},Ue=t=>{Be=t;let n=zn(t.get(`content`));G(`#custom-code-html`).value=n.html,G(`#custom-code-css`).value=n.css,G(`#custom-code-js`).value=n.js,G(`#custom-code-status`).textContent=`Изменения попадут на страницу только после сохранения блока.`,G(`#custom-code-dialog`).showModal(),Vn({iframe:G(`#custom-code-preview-frame`),projectId:e,csrf:q.csrf,kind:`custom-code`,payload:n})};G(`#edit-custom-code`).onclick=()=>{let e=J.getSelected();e?.get(`type`)===`custom-code`&&Ue(e)},G(`#custom-code-preview`).onclick=()=>{try{let t=Ve();He(t),G(`#custom-code-status`).textContent=`Проверка выполняется в отдельном sandbox iframe.`,Vn({iframe:G(`#custom-code-preview-frame`),projectId:e,csrf:q.csrf,kind:`custom-code`,payload:t})}catch(e){G(`#custom-code-status`).textContent=e.message}},G(`#custom-code-save`).onclick=()=>{try{if(!Be||Be.get(`type`)!==`custom-code`)throw Error(`Блок больше не выбран. Выберите его заново.`);let e=Ve();He(e);let t=Rn(e);Be.set(`content`,t),G(`#custom-code-status`).textContent=`Блок сохранён в Project Data; проект сохранится обычным автосохранением.`,G(`#custom-code-dialog`).close(),J.select(Be),ge()}catch(e){G(`#custom-code-status`).textContent=e.message}},G(`#close-custom-code`).onclick=()=>G(`#custom-code-dialog`).close(),G(`#custom-code-dialog`).addEventListener(`close`,()=>{Be=null,Hn(G(`#custom-code-preview-frame`))});let We=e=>{if(e===`image`){r.open();return}let t=Kn.find(t=>t.id===e),n=J.addComponents(t.content());J.select(n[0]),e===`custom-code`&&Ue(n[0]),ge()};for(let e of document.querySelectorAll(`[data-block]`))e.onclick=()=>We(e.dataset.block);r=Ot({editor:J,projectId:e,api:Q,csrf:()=>q.csrf,notify:$,insert:(e,t)=>{let n=Kn.find(e=>e.id===`image`).content();n.src=e,n.attributes={alt:t};let r=J.addComponents(n);J.select(r[0]),ge()}}),G(`#start-hero`).onclick=()=>We(`hero`);for(let e of document.querySelectorAll(`[data-panel]`))e.onclick=()=>ei(e.dataset.panel);for(let e of document.querySelectorAll(`.editor-floating-tools [data-open-panel]`))e.onclick=()=>ei(G(`.editor-shell`).dataset.openPanel===e.dataset.openPanel?`none`:e.dataset.openPanel);for(let e of document.querySelectorAll(`[data-close-panel]`))e.onclick=()=>ei(`none`);G(`#close-inspector`).onclick=()=>{G(`.editor-shell`).dataset.inspectorOpen=`false`};for(let e of document.querySelectorAll(`.mobile-workspace-tabs [data-mobile-panel]`))e.onclick=()=>ei(e.dataset.mobilePanel);for(let e of document.querySelectorAll(`[data-flex-property]`))e.onclick=()=>{let t=J.getSelected();t&&(t.addStyle({[e.dataset.flexProperty]:e.dataset.flexValue}),je(t))};for(let e of document.querySelectorAll(`[data-device]`))e.onclick=()=>{J.setDevice(e.dataset.device);for(let t of document.querySelectorAll(`[data-device]`))t.classList.toggle(`active`,t===e);G(`#canvas-size`).textContent=e.dataset.device===`Mobile`?`375 px`:e.dataset.device===`Tablet`?`768 px`:`Адаптивный холст`};let Ge,Ke=e=>{for(let t of document.querySelectorAll(`[data-settings-panel]`))t.hidden=t.dataset.settingsPanel!==e;for(let t of document.querySelectorAll(`[data-settings-tab]`))t.setAttribute(`aria-pressed`,String(t.dataset.settingsTab===e));G(`#page-settings-form`).hidden=e===`design`};for(let e of document.querySelectorAll(`[data-settings-tab]`))e.onclick=()=>Ke(e.dataset.settingsTab);G(`#close-page-settings`).onclick=()=>G(`#theme-dialog`).close(),G(`#theme`).onclick=()=>{let e=J.Pages.getSelected();if(!e)return;Ge=e.id;let t=Y.settings.pages[e.id],n=G(`#page-settings-form`);for(let[r,i]of Object.entries({name:e.get(`name`),slug:t.slug,...t.seo}))n.elements.namedItem(r)&&(n.elements.namedItem(r).value=i);G(`#page-settings-status`).textContent=``,y(),Ke(`general`),G(`#theme-dialog`).showModal()},G(`#page-settings-form`).addEventListener(`invalid`,e=>{let t=e.target.closest(`[data-settings-panel]`);t&&Ke(t.dataset.settingsPanel)},!0),G(`#page-settings-form`).onsubmit=async t=>{t.preventDefault();let n=t.target.querySelector(`[type="submit"]`);n.disabled=!0;try{if(await ui(!1),X||Z)throw Error(`Сначала сохраните изменения страницы и разрешите конфликт версий.`);let{name:n,slug:r,...i}=Object.fromEntries(new FormData(t.target));Y=await Q(`/projects/${e}/settings`,`PUT`,{version:Y.version,page:{pageId:Ge,name:n,slug:r},seo:{pageId:Ge,...i}}),Kr=!0,J.Pages.get(Ge)?.set(`name`,n.trim(),{silent:!0}),Kr=!1,we(),G(`#page-settings-status`).textContent=`Сохранено · ревизия ${Y.version}`,G(`#save-status`).textContent=`Сохранено · ревизия ${Y.version}`}catch(e){G(`#page-settings-status`).textContent=e.message}finally{n.disabled=!1}},G(`#cancel-theme`).onclick=()=>G(`#theme-dialog`).close(),G(`#theme-form`).onsubmit=e=>{e.preventDefault();try{he(Object.fromEntries(new FormData(e.target))),G(`#theme-dialog`).close(),$(`Тема применена ко всем страницам`)}catch(e){$(e.message,!0)}},G(`#close-ai-plan`).onclick=()=>G(`#ai-plan-dialog`).close(),G(`#ai-plan-dialog`).addEventListener(`close`,()=>{O?.disconnect(),O=null,G(`#ai-plan-dialog`).classList.remove(`ai-preview-expanded`),G(`#ai-job-diagnostics`).hidden=!0,Je++,b=null,k(),G(`#ai-image-slot-chooser`).hidden=!0,G(`#ai-image-slot-list`).replaceChildren(),G(`#ai-plan-preview`).replaceChildren()}),G(`#ai-plan-open`).onclick=async()=>{let t=G(`#ai-plan-open`);t.disabled=!0;try{if(Z)throw Error(`Сначала загрузите актуальную версию проекта с сервера.`);if(X&&(await ui(!1),X||Z))throw Error(`Не удалось сохранить текущие изменения. План не применён.`);b=null,k(),G(`#ai-image-slot-chooser`).hidden=!0,G(`#ai-image-slot-list`).replaceChildren(),G(`#ai-plan-preview`).replaceChildren(),G(`#ai-plan-preview`).hidden=!0,G(`#ai-plan-status`).textContent=``,G(`#ai-provider-status`).textContent=`Проверяем настройку AI-сервера…`,G(`#ai-generate`).disabled=!0,G(`#ai-plan-dialog`).showModal();let t=(e,t,n)=>new Promise((r,i)=>{let a=setTimeout(()=>i(Error(n)),t);e.then(e=>{clearTimeout(a),r(e)},e=>{clearTimeout(a),i(e)})}),[n,r]=await Promise.all([t(Q(`/projects/${e}/ai/settings`),1e4,`Настройки AI не ответили за 10 секунд. Проверьте соединение и повторите.`),t(h(),5e3,`Библиотека Skills не ответила за 5 секунд. Можно продолжить без пользовательского Skill.`).then(()=>``,e=>e.message)]);p=r,n.configured===!0?(G(`#ai-generate`).disabled=!1,G(`#ai-settings-link`).hidden=!0,G(`#ai-provider-status`).textContent=`OpenRouter настроен для проекта${n.model?` · ${n.model}`:``}. Запрос будет отправлен только после нажатия «Создать дизайн».${p?` Библиотека Skills недоступна: `+p:``}`,G(`#ai-panel-status`).textContent=`AI настроен для проекта.`):(G(`#ai-settings-link`).hidden=!1,G(`#ai-provider-status`).textContent=`AI не настроен. Описание останется на этой странице и не будет отправлено.`,G(`#ai-panel-status`).textContent=`Задайте ключ в «Настройки сайта → AI Engine».`)}catch(e){G(`#ai-settings-link`).hidden=!1,G(`#ai-provider-status`).textContent=e.message,G(`#ai-panel-status`).textContent=e.message,$(e.message,!0)}finally{t.disabled=!1}};let qe=!1,Je=0,Ye=null,Xe=e=>{let t=G(`#ai-job-diagnostics`);t.replaceChildren(),t.hidden=!1;let n=document.createElement(`h3`);if(n.textContent=`Диагностика задачи`,t.append(n),!e.diagnostics){let e=document.createElement(`p`);e.className=`muted small`,e.textContent=`Для этой задачи подробная диагностика не сохранена.`,t.append(e);return}let r={queued:`Задача в очереди`,running:`Генерация выполняется`,launcher:`Не удалось запустить worker`,expired:`Истёк срок выполнения задачи`,succeeded:`Дизайн прошёл серверную проверку`,response_received:`Ответ модели получен`,timeout:`Таймаут ответа`,rate_limited:`Ограничение запросов · HTTP 429`,unavailable:`Сетевая ошибка или временный отказ`,credentials:`Отказ доступа к модели`,invalid_output:`Результат не прошёл безопасную проверку`,invalid_component_edit:`Правка элемента не прошла проверку`,invalid_response:`Модель не вернула структурированный JSON`,invalid_schema:`Неверный формат дизайна`,invalid_markup:`HTML не прошёл проверку`,invalid_css:`CSS не прошёл проверку`,copy_quality:`Проверка текста не пройдена`,contrast_quality:`Проверка контраста не пройдена`,hero_alignment:`Проверка композиции Hero не пройдена`,contact_requirements:`Контакт отсутствует в описании`,skill_requirements:`Не выполнены правила Skill`,cancelled:`Задача отменена`,project_changed:`Версия проекта изменилась`,internal:`Внутренняя ошибка`,provider:`Отказ провайдера`},i=document.createElement(`p`);i.textContent=r[e.diagnostics.outcome]||`Запрос не завершён`,t.append(i);let a={exec_unavailable:`Хостинг отключил запуск фоновых процессов PHP.`,cli_binary_unavailable:`На сервере не найден доступный PHP CLI.`,launch_failed:`Хостинг не смог запустить PHP worker.`};if(e.diagnostics.outcome===`launcher`&&a[e.diagnostics.launchCode]){let n=document.createElement(`p`);n.className=`muted small`,n.textContent=a[e.diagnostics.launchCode],t.append(n)}if(e.diagnostics.stage&&[`queued`,`running`,`cancelling`].includes(e.status)){let n=document.createElement(`p`);n.className=`muted small`,n.textContent=`Текущий этап: `+pr(e.diagnostics.stage),t.append(n)}if(e.diagnostics.failureStage){let n=document.createElement(`p`);n.className=`muted small`,n.textContent=(e.status===`running`?`Проблема на этапе: `:`Остановка на этапе: `)+pr(e.diagnostics.failureStage),t.append(n)}if(e.diagnostics.validationRule){let n=document.createElement(`p`);n.className=`muted small`,n.textContent=e.diagnostics.outcome===`copy_quality`?`Проверка текста: `+br(e.diagnostics.validationRule):e.diagnostics.outcome===`invalid_css`?`Проверка CSS: `+xr(e.diagnostics.validationRule):`Проверка HTML: `+yr(e.diagnostics.validationRule),t.append(n)}let o=vr(e.diagnostics.events);if(o.length){let e=document.createElement(`ol`);e.className=`ai-generation-timeline`,e.setAttribute(`aria-label`,`Этапы генерации`);for(let t of o){let n=document.createElement(`li`),r=[pr(t.stage),mr(t.state)];if(Number.isInteger(t.attempt)&&t.attempt>1&&r.push(`попытка `+t.attempt),Number.isFinite(t.durationMs)&&r.push((t.durationMs/1e3).toFixed(1)+` с`),t.templateId){let e=hr(t.templateId);e&&r.push(e)}let i=Er(t.pipelineStage);i&&r.push(i),t.revision&&/^[a-f0-9]{40}$/.test(t.revision)&&r.push(t.revision.slice(0,8)),t.stage===`open_design_pipeline`&&typeof t.genericDefaults==`boolean`&&r.push(t.genericDefaults?`общие defaults`:`без общих defaults`);let a=gr(t.referenceStatus);if(a&&r.push(a),t.decision===`repair_available`&&r.push(`будет повторная попытка`),t.decision===`no_repair_rule`&&r.push(`исправление не предусмотрено`),t.decision===`safe_fallback`&&r.push(`применена безопасная раскладка`),n.textContent=r.join(` · `),t.validationRule){let e=document.createElement(`span`);e.className=`muted small`;let r=wr(t);e.textContent=` — `+Cr(t)+(r?` (${r})`:``),n.append(e)}e.append(n)}t.append(e)}let s=document.createElement(`p`);s.className=`muted small`,s.textContent=`Показываются только этапы, длительность и фиксированные коды проверок. Промпт, ответы модели, тексты страницы и ключи не записываются в диагностику.`,t.append(s);for(let n of e.diagnostics.attempts||[]){let e=document.createElement(`p`);e.className=`muted small`,e.textContent=n.profileName+` · `+n.model+` · `+(r[n.outcome]||`Отказ провайдера`)+` · `+(n.elapsedMs/1e3).toFixed(1)+` с`,t.append(e)}};G(`#ai-job-cancel`).onclick=async()=>{let t=Ye;if(!t)return;let n=G(`#ai-job-cancel`);n.disabled=!0;try{let n=await Q(`/projects/${e}/ai/generation-jobs/${t}/cancel`,`POST`,{});G(`#ai-plan-status`).textContent=n.status===`cancelling`?`Отменяем запрос. Уже потраченные токены могут быть учтены провайдером.`:n.error}catch(e){G(`#ai-plan-status`).textContent=e.message}finally{n.disabled=!1}},G(`#ai-job-history`).onclick=async()=>{if(qe){G(`#ai-plan-status`).textContent=`Закройте окно ожидания и откройте AI-дизайн снова, чтобы просмотреть историю.`;return}let t=G(`#ai-job-history`),n=G(`#ai-job-history-list`),r=J.Pages.getSelected();if(r){t.disabled=!0,n.hidden=!1,n.replaceChildren();try{let t=await Q(`/projects/${e}/ai/generation-jobs/history?pageId=${encodeURIComponent(r.get(`id`))}`),i=document.createElement(`p`);i.className=`muted small`,i.textContent=t.items.length?`Последние 20 задач этой страницы за 24 часа. Открытие не отправляет новый запрос в OpenRouter.`:`Для этой страницы пока нет задач за последние 24 часа.`,n.append(i);let a={queued:`В очереди`,running:`Выполняется`,cancelling:`Отменяется`,cancelled:`Отменена`,succeeded:`Готово`,failed:`Ошибка`};for(let e of t.items){let t=document.createElement(`div`);t.className=`ai-job-history-row`;let r=e.templateReference?hr(e.templateReference.templateId)+` · `+gr(e.templateReference.referenceStatus):``,i=document.createElement(`p`);i.textContent=new Date(e.createdAt*1e3).toLocaleString(`ru-RU`)+` · `+(a[e.status]||e.status)+` · профиль `+e.skillName+(r?` · референс `+r:``)+` · ревизия `+e.baseVersion+` — `+e.promptExcerpt;let o=document.createElement(`button`);o.type=`button`,o.className=`secondary-link`,o.textContent=e.hasResult?`Посмотреть результат`:`Открыть задачу`,o.onclick=()=>G(`#ai-plan-form`).onsubmit({preventDefault(){},resumeJob:!0,jobId:e.id}),t.append(i,o),n.append(t)}}catch(e){n.textContent=e.message}finally{t.disabled=!1}}},G(`#ai-job-resume`).onclick=()=>G(`#ai-plan-form`).onsubmit({preventDefault(){},resumeJob:!0}),G(`#ai-plan-form`).onsubmit=async t=>{if(t.preventDefault(),qe||!t.resumeJob&&G(`#ai-generate`).disabled)return;let n=G(`#ai-prompt`).value.trim();if(!n&&!t.resumeJob)return;qe=!0,$(``,!1);let r=G(`#ai-generate`);r.disabled=!0,G(`#ai-job-diagnostics`).hidden=!0,b=null,k(),G(`#ai-image-slot-chooser`).hidden=!0,G(`#ai-plan-preview`).replaceChildren(),G(`#ai-plan-preview`).hidden=!0,G(`#ai-plan-status`).textContent=`Создаём дизайн страницы. Проект пока не меняется.`;let i=Je;try{let r=J.Pages.getSelected();if(!r)throw Error(`Выберите страницу проекта.`);let a=G(`#ai-skill-profile`).value,o=a.startsWith(`user:`)?a.slice(5):null,s=o?`standard`:a,l=t.resumeJob?await Q(t.jobId?`/projects/${e}/ai/generation-jobs/${encodeURIComponent(t.jobId)}`:`/projects/${e}/ai/generation-jobs?pageId=${encodeURIComponent(r.get(`id`))}`):await Q(`/projects/${e}/ai/generation-jobs`,`POST`,{prompt:n,skillProfile:s,...o?{skillId:o}:{},pageId:r.get(`id`),version:Y.version});if(!l)throw Error(`Для этой страницы пока нет задачи.`);for(l.status===`queued`&&Q(`/projects/${e}/ai/generation-jobs/${l.id}/execute`,`POST`,{}).catch(()=>{i===Je&&G(`#ai-plan-dialog`)?.open&&(G(`#ai-plan-status`).textContent=`Соединение с обработчиком прервано. Проверяем сохранённое состояние задачи; повторный запрос модели не отправляется.`)}),Ye=l.id,G(`#ai-job-cancel`).hidden=![`queued`,`running`,`cancelling`].includes(l.status),o=l.request.skillId,s=l.request.skillProfile,G(`#ai-prompt`).value=l.request.prompt,c.value=o?`user:`+o:s,m();[`queued`,`running`,`cancelling`].includes(l.status);){Xe(l);let t=l.diagnostics?.stage?` · `+pr(l.diagnostics.stage):``;if(G(`#ai-plan-status`).textContent=(l.status===`cancelling`?`Отменяем генерацию`:l.status===`queued`?`Задача в очереди`:`Генерация выполняется`)+t+` · `+Math.max(0,Math.floor(Date.now()/1e3-l.createdAt))+` с. Сохраняйте вкладку открытой до завершения. Лимит задачи — 10 минут.`,await new Promise(e=>setTimeout(e,2e3)),!G(`#ai-plan-dialog`)?.open||i!==Je)return;l=await Q(`/projects/${e}/ai/generation-jobs/${l.id}`)}if(!G(`#ai-plan-dialog`)?.open||i!==Je)return;if(Xe(l),l.status!==`succeeded`)throw Error(l.error||`Генерация не завершилась.`);if(l.pageId!==r.get(`id`))throw Error(`Задача относится к другой странице.`);let u=l.result;if(!u.design||typeof u.design.html!=`string`||typeof u.design.css!=`string`)throw Error(`AI вернул неполный дизайн. Попробуйте уточнить описание.`);if(s===`taste`&&(u.metadata?.skillProfile!==`taste`||u.design.skillAudit?.profile!==`taste`||!Array.isArray(u.design.skillAudit.checks)||u.design.skillAudit.checks.some(e=>e.status!==`passed`)))throw Error(`Ответ не подтвердил обязательные проверки Taste. Дизайн не применён.`);if(o&&(u.metadata?.skillProfile!==`user_skill`||u.metadata?.userSkillId!==o||u.design.skillAudit?.profile!==`user_skill`||!Array.isArray(u.design.skillAudit.humanReviewRequired)||!u.design.skillAudit.humanReviewRequired.length))throw Error(`Ответ не содержит чек-лист выбранного Skill. Дизайн не применён.`);let d=[],f=``;try{d=await Q(`/projects/${e}/assets`)}catch(e){f=` Не удалось загрузить библиотеку изображений: `+e.message}let p=u.design.imageSlots||[];if(b={baseVersion:l.baseVersion,design:u.design,metadata:u.metadata,pageId:r.get(`id`),photosPending:!0,photoNotice:u.design.photoSelection?.status===`unavailable`?`Подбор фото временно недоступен. Дизайн готов без изображений.`:u.design.photoSelection?.status===`no_matches`?`Подходящих фото не найдено. Дизайн готов без изображений.`:u.design.photoSelection?.photos?.length?`Изображения подобраны автоматически.`:``,assets:[...d,...u.design.photoSelection?.photos||[]],imageAssignments:u.design.photoSelection?.assignments||{},imageAlt:Object.fromEntries(p.map(e=>[e.id,e.label]))},de(u.design,u.metadata,l.diagnostics?.events),!u.design.photoSelection&&!re()){for(let e of u.design.imageSlots||[])if(e.query)try{await le(e.id,e.query)}catch(e){b&&(b.photoNotice=e.message,G(`#ai-plan-status`).textContent=e.message)}}if(!G(`#ai-plan-dialog`)?.open||i!==Je)return;if(b.photosPending=!1,ne(),re()){G(`#ai-image-slot-chooser`).hidden=!0;for(let e of G(`#ai-plan-preview`).querySelectorAll(`input`))e.disabled=!0}G(`#ai-plan-status`).textContent=u.design.contactAudit?.status===`passed`?l.baseVersion===Y.version?`Проверьте предпросмотр. Страница изменится только после отдельного подтверждения. `+(b.photoNotice||``):`Результат ревизии `+l.baseVersion+` доступен только для просмотра: текущая ревизия `+Y.version+`. Для применения создайте новую генерацию.`:`Старый результат без проверки контактов: только просмотр. Создайте новую генерацию.`,f&&(G(`#ai-plan-status`).textContent+=f)}catch(e){G(`#ai-plan-status`).textContent=e.message,$(e.message,!0)}finally{qe=!1,Ye=null,G(`#ai-job-cancel`).hidden=!0,r.disabled=!1}},ye.onclick=()=>A.hidden?Se(!0):xe(!1),ye.onkeydown=e=>{[`ArrowDown`,`Enter`,` `].includes(e.key)&&(e.preventDefault(),Se(!0))},A.addEventListener(`click`,e=>{let t=e.target.closest(`[role="option"]`);t&&!e.target.closest(`input,button`)&&(t.focus(),clearTimeout(be),be=setTimeout(()=>Ce(t.dataset.pageId),500))}),A.addEventListener(`dblclick`,e=>{let t=e.target.closest(`[role="option"]`);t&&!e.target.closest(`input,button`)&&(e.preventDefault(),clearTimeout(be),be=null,De(t,t.dataset.pageId))}),A.addEventListener(`keydown`,e=>{if(e.target.closest(`input,button`))return;let t=e.target.closest(`[role="option"]`);if(!t)return;let n=[...A.querySelectorAll(`[role="option"]:not(.is-renaming)`)],r=n.indexOf(t);e.key===`ArrowDown`||e.key===`ArrowUp`?(e.preventDefault(),n[(r+(e.key===`ArrowDown`?1:-1)+n.length)%n.length]?.focus()):e.key===`Home`||e.key===`End`?(e.preventDefault(),n[e.key===`Home`?0:n.length-1]?.focus()):e.key===`Enter`?(e.preventDefault(),Ce(t.dataset.pageId)):e.key===`F2`&&(e.preventDefault(),De(t,t.dataset.pageId))}),document.addEventListener(`pointerdown`,e=>{!_e.contains(e.target)&&!A.hidden&&(A.querySelector(`.is-renaming`)&&we(),xe(!1))}),document.addEventListener(`keydown`,e=>{e.key===`Escape`&&!e.defaultPrevented&&!A.hidden&&(A.querySelector(`.is-renaming`)&&we(),xe(!0))}),G(`#add-page`).onclick=()=>G(`#page-dialog`).showModal(),G(`#cancel-page`).onclick=()=>G(`#page-dialog`).close(),G(`#page-form`).onsubmit=e=>{e.preventDefault();let t=J.Pages.add({id:crypto.randomUUID(),name:new FormData(e.target).get(`name`),component:Dr(Dn(me()))});J.Pages.select(t),G(`#page-dialog`).close(),e.target.reset()},G(`#undo`).onclick=()=>J.UndoManager.undo(),G(`#redo`).onclick=()=>J.UndoManager.redo(),G(`#layout`).onchange=e=>{let t=J.getSelected();if(!t)return;let n=t.getStyle()||{},r={display:e.target.value};t.get(`type`)===`wrapper`&&e.target.value===`flex`&&!n[`flex-direction`]&&(r[`flex-direction`]=`column`),t.addStyle(r),je(t)},G(`#width-mode`).onchange=e=>J.getSelected()?.addStyle({width:e.target.value}),G(`#height-mode`).onchange=e=>J.getSelected()?.addStyle({height:e.target.value}),G(`#apply-size-constraints`).onclick=()=>{let e=J.getSelected();if(!e)return;let t={},n=[];for(let e of[`min-width`,`max-width`,`min-height`,`max-height`]){let r=G(`#${e}`),i=r.value.trim();if(!i)n.push(e);else{if(!(/^(?:\d+(?:\.\d+)?(?:px|%|rem|em|vw|vh)|auto|none)$/i.test(i)&&(e.startsWith(`min-`)?i.toLowerCase()!==`none`:i.toLowerCase()!==`auto`))){r.focus(),$(`Укажите размер с единицей: например 320px, 60% или 40rem.`,!0);return}t[e]=i}}for(let t of n)e.removeStyle(t);Object.keys(t).length&&e.addStyle(t),ke(e),$(`Ограничения размеров применены`)},G(`#apply-text`).onclick=()=>{let e=J.getSelected();e&&(e.components(K(G(`#component-text`).value)),$(`Текст изменён`))},G(`#save`).onclick=()=>ui(!1),G(`#publish-editor`).onclick=async()=>{let t=G(`#publish-editor`);t.disabled=!0;try{if(Z)throw Error(`Сначала разрешите конфликт версий.`);if(X&&await ui(!1),X||qr||Z)throw Error(`Сначала сохраните изменения и разрешите конфликт версий.`);let t=Y.version;if(!await ii(`Будет опубликована сохранённая ревизия ${t}. Сайт станет доступен без входа на отдельном публичном адресе. Продолжить?`,`Опубликовать`))return;let n=await Q(`/projects/${e}/publish`,`POST`,{version:t});Zr=n.publication,Y.version=n.publication.sourceProjectVersion,ci(),$(`Опубликована ревизия ${n.publication.sourceProjectVersion}: ${n.publicUrl}`)}catch(e){$(e.message,!0)}finally{t.disabled=!1}},G(`#reload-server`).onclick=async()=>{if(await ii(`Локальные несохранённые изменения будут заменены серверной версией. Сначала можно скачать их через «Экспорт JSON». Продолжить?`,`Загрузить версию`))try{let e=J.Pages.getSelected()?.get(`id`),t=await Q(`/projects/${Y.id}`);Y=t,Kr=!0,J.loadProjectData(t.document.data),e&&J.Pages.getAll().some(t=>t.get(`id`)===e)&&J.Pages.select(e),J.clearDirtyCount(),Gr=JSON.stringify(J.getProjectData()),X=!1,Kr=!1,Z=!1,G(`#reload-server`).hidden=!0,G(`#save`).disabled=!1,we(),y(),G(`#save-status`).textContent=`Ревизия ${Y.version} · Загружено с сервера`,$(`Серверная версия загружена`)}catch(e){Kr=!1,$(e.message,!0)}};let Ze=async()=>{G(`#history-dialog`).showModal(),G(`#history-list`).textContent=`Загрузка истории…`,G(`#history-error`).textContent=``;try{let e=await Q(`/projects/${Y.id}/revisions`),t=G(`#history-list`);if(t.replaceChildren(),!e.length){t.textContent=`Сохранённых ревизий пока нет.`;return}for(let n of e){let e=document.createElement(`div`);e.className=`history-row`;let r=document.createElement(`div`),i=document.createElement(`strong`);i.textContent=`Ревизия ${n.version}${n.version===Y.version?` · текущая`:``}`;let a=document.createElement(`time`);if(a.textContent=new Date(`${n.created_at.replace(` `,`T`)}Z`).toLocaleString(`ru-KZ`,{dateStyle:`medium`,timeStyle:`short`}),r.append(i,a),e.append(r),n.version!==Y.version){let t=document.createElement(`button`);t.className=`restore-revision`,t.textContent=`Восстановить`,t.onclick=async()=>{if(await ii(`Восстановить ревизию ${n.version}? Это действие создаст новую ревизию, сохранив текущее состояние в истории.`,`Восстановить`))try{if(X&&(await ui(!1),X||Z))throw Error(`Текущие изменения не сохранены. Разрешите конфликт и попробуйте снова.`);let e=J.Pages.getSelected()?.get(`id`),t=await Q(`/projects/${Y.id}/revisions/restore`,`POST`,{currentVersion:Y.version,targetVersion:n.version});Y=t,Kr=!0,J.loadProjectData(t.document.data),e&&J.Pages.getAll().some(t=>t.get(`id`)===e)&&J.Pages.select(e),J.clearDirtyCount(),Gr=JSON.stringify(J.getProjectData()),Kr=!1,X=!1,Z=!1,G(`#reload-server`).hidden=!0,G(`#save`).disabled=!1,we(),y(),G(`#save-status`).textContent=`Восстановлена ревизия ${n.version} · новая ревизия ${Y.version}`,G(`#history-dialog`).close(),$(`Ревизия восстановлена`)}catch(e){Kr=!1,e.status===409&&(Z=!0,G(`#reload-server`).hidden=!1,G(`#save`).disabled=!0,G(`#save-status`).textContent=`Версия изменилась в другой вкладке`),$(e.message,!0)}},e.append(t)}t.append(e)}}catch(e){G(`#history-list`).textContent=``,G(`#history-error`).textContent=e.message}};G(`#history`).onclick=Ze,G(`#close-history`).onclick=()=>G(`#history-dialog`).close(),G(`#export`).onclick=()=>ti(`juzimder-project.json`,JSON.stringify({schemaVersion:1,engine:`grapesjs`,data:J.getProjectData()},null,2)),G(`#static-export`).onclick=async()=>{let e=G(`#static-export`);e.disabled=!0;try{if(X&&!Z&&await ui(!1),X||Z)throw Error(`Сначала сохраните изменения и разрешите конфликт версий.`);let e=await fetch(`/api/projects/${Y.id}/export/static`,{headers:{"X-CSRF-Token":q.csrf}});if(!e.ok){let t=`Не удалось собрать ZIP сайта.`;try{t=(await e.json()).error||t}catch{}throw Error(t)}ti(`juzimder-static-site.zip`,await e.blob(),`application/zip`),$(`Статический ZIP сайта скачан`)}catch(e){$(e.message,!0)}finally{e.disabled=!1}},G(`#back`).onclick=async()=>{X&&!Z&&await ui(!1),(!X||await ii(Z?`Не удалось объединить изменения с сервером. Можно скачать их через «Экспорт JSON». Всё равно выйти?`:`Изменения не сохранены. Всё равно выйти?`,`Всё равно выйти`))&&(clearTimeout(Yr),Yr=void 0,i.destroy(),J.destroy(),J=null,X=!1,location.assign($r(e)))},G(`#preview`).onclick=()=>{let e=J.getHtml(),t=J.getCss();G(`#preview-frame`).srcdoc=`<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><style>body{margin:0}${t}</style></head><body>${e}</body></html>`,G(`#preview-dialog`).showModal()},G(`#close-preview`).onclick=()=>G(`#preview-dialog`).close()}document.addEventListener(`keydown`,e=>{if(!J||e.defaultPrevented||document.querySelector(`dialog[open]`))return;if(e.key===`Escape`){let e=G(`.editor-shell`);if(e.dataset.openPanel!==`none`){ei(`none`);return}if(e.dataset.inspectorOpen===`true`){e.dataset.inspectorOpen=`false`;return}}if(!(e.metaKey||e.ctrlKey)||e.altKey||e.target instanceof Element&&e.target.closest(`input,textarea,select,[contenteditable]:not([contenteditable="false"])`))return;let t=e.key.toLowerCase();t===`s`&&!e.shiftKey?(e.preventDefault(),ui(!1)):t===`z`?(e.preventDefault(),e.shiftKey?J.UndoManager.redo():J.UndoManager.undo()):t===`y`&&e.ctrlKey&&(e.preventDefault(),J.UndoManager.redo())}),window.addEventListener(`beforeunload`,e=>{X&&(e.preventDefault(),e.returnValue=``)}),(async()=>{try{if(q=await Q(`/session`),!q.user){mi();return}let e=location.pathname,t=e.match(/^\/projects\/([^/]+)(.*)$/);if(t){let n=t[1],r=t[2],i=/^[a-f0-9]{24}$/.test(n)?await Q(`/projects/${n}`):await Q(`/projects/resolve/${encodeURIComponent(n)}`);Qr.set(i.id,i.slug),e=`/projects/${i.id}${r}`,n!==i.slug&&history.replaceState({},``,`${$r(i.id,r)}${location.search}${location.hash}`)}let n=e.match(/^\/projects\/([a-f0-9]{24})\/pages\/([A-Za-z0-9_-]{1,128})\/zero\/([A-Za-z][A-Za-z0-9_-]{0,127})\/edit$/);if(n){let{openZeroEditor:e}=await Pr(async()=>{let{openZeroEditor:e}=await import(`./app-pjZ6-8AA.js`);return{openZeroEditor:e}},__vite__mapDeps([0,1]));await e({projectId:n[1],pageId:n[2],blockId:n[3],api:Q,session:q,app:Fr});return}let r=e.match(/^\/projects\/([a-f0-9]{24})\/pages\/([A-Za-z0-9_-]{1,128})\/edit$/);if(r){await bi(r[1],decodeURIComponent(r[2]));return}if(r=e.match(/^\/projects\/([a-f0-9]{24})\/settings$/),r){await yi(r[1]);return}if(r=e.match(/^\/projects\/([a-f0-9]{24})$/),r){await vi(r[1]);return}await _i()}catch(e){Fr.innerHTML=`<main class="boot-error"><h1>Не удалось открыть пространство</h1><p></p><button onclick="location.reload()">Повторить</button></main>`,G(`.boot-error p`).textContent=e.message}})();export{se as A,Ie as C,Ae as D,Le as E,oe as M,S as N,De as O,Ue as S,We as T,qe as _,lt as a,Be as b,je as c,Ce as d,Ee as f,ze as g,Re as h,St as i,he as j,Ge as k,Ve as l,Fe as m,Ot as n,Xe as o,be as p,j as r,Ye as s,Or as t,Je as u,Pe as v,He as w,Me as x,xe as y};